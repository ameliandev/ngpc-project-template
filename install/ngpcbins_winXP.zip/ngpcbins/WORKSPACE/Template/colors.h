#define RED	0x000f
#define GREEN	0x00f0
#define BLUE	0x0f00
#define YELLOW	0x00ff
#define CYAN	0x0ff0
#define MAGENTA	0x0f0f
#define BLACK	0x0000
#define WHITE	0x0fff