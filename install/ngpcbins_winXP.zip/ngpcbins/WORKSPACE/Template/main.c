#if 1					// header files

#include "ngpc.h"		// required
#include "carthdr.h"	// required
#include "library.h"	// NGPC routines
#include <stdlib.h>		// std C routines
#include <stdio.h>

#endif

#define P1_PAL1 0

void main()
{
	InitNGPC();
	SysSetSystemFont();

	ClearScreen(SCR_1_PLANE);
	ClearScreen(SCR_2_PLANE);

	SetBackgroundColour(RGB(13,13,13));

	SetPalette(SCR_1_PLANE, P1_PAL1, 0, 0, 0, RGB(0,0,15));
	
	PrintString(SCR_1_PLANE, P1_PAL1, 2, 8, "Hello World!");

	// never fall out of main!!!
	while(1)
	{		
	} 
}