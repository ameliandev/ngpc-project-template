/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _ultoa.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:09:44 $	*/

#include <stdlib.h>

char * __CDECL ultoa(unsigned long val, char *s, int radix)
{
	int u;
	char buf[sizeof(long) * 8 + 1];
	char *p;
	char *q = s;

	if ((radix < 2) || (radix > 36))
	{
		s[0] = 0;
		return (s);
	}

	buf[sizeof(buf) - 1] = 0;
	p = &buf[sizeof(buf) - 2];
	while (1) {
		*p = (val % radix) + '0';
		if (*p > '9')	*p += 'a'-'0'-10;
		if ((val /= radix) == 0)	break;
		p--;
	}
	memcpy(q, p, &buf[sizeof(buf)] - p);
	return (s);
}
