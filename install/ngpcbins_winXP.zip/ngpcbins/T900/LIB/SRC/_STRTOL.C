/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strtol.c $	*/
/*	$Revision: 1.2.1.1 $	*/
/*	$Date: 1995/01/31 13:23:27 $	*/

#include <stdlib.h>
#include <ctype.h>
#include <errno.h>

long __CDECL strtol(const char *nptr, char **endptr, int base) {
	long val;
	int sign = 0,over = 0;
	int c;
	char *bak_ptr,chk_ch,stop_alpha;

	bak_ptr = (char *)nptr;
	while (isspace(*nptr))	++nptr;
	if(base < 0 || base > 36) {
NOT:
		if(*endptr) {
			*endptr = bak_ptr;
			return (long)0;
		}
	}
	chk_ch = *nptr;
	if(isalpha(chk_ch)) {
		if(base < 11) goto NOT;
		stop_alpha = 'A' + (base-11);
		if(toupper(chk_ch) > stop_alpha)
			goto NOT;
	}
	else if(!isdigit(chk_ch) && chk_ch != '+' && chk_ch != '-')	goto NOT;
	if (*nptr == '-')	++nptr,sign = 1;
	else if (*nptr == '+')	++nptr;
	if (base == 0) {
		base = 10;
		if (*nptr == '0') {
			++nptr,base = 8;
			if (*nptr == 'X' || *nptr == 'x')
				++nptr,base = 16;
		}
	}
	else if (base == 16 && nptr[0] == '0' && (nptr[1] == 'x' || nptr[1] == 'X'))
		nptr += 2;
	for (val=0;;) {
		c = *nptr++;
		if (c == '\0')	break;
		if (isdigit(c))	c = c - '0';
		else if (islower(c))	c = c - 'a' + 10;
		else if (isupper(c))	c = c - 'A' + 10;
		else	break;
		if (c >= base)	break;
		val = val*base + c;
		if (val < 0)	over = 1;
	}
	if (over)	val = 0x7fffffff,errno = ERANGE;
	if (sign)	val = -val;
	if (endptr)	*endptr = (void *)(nptr-1);
	return (val);
}
