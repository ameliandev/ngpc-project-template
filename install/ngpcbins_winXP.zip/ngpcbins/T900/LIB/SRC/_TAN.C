/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _tan.c $	*/
/*	$Revision: 1.2.1.1 $	*/
/*	$Date: 1995/01/31 21:30:35 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL tan(double  x)
{
	unsigned short* p;
	double	ret;

	p=(unsigned short*)&x;

#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
	if(LMTPOW<=(p[3]&0x7ff0)) {
#else
	if(LMTPOW<=(p[0]&0x7ff0)) {
#endif
		errno=ERANGE;		/* TLOSS error */
		return(0.0);
	}
	ret = sin(x) / cos(x);
	return(ret);
}
