/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _ispunct.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:03:35 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL ispunct(int c)
{
	return (isascii(c) && !isalnum(c) && !iscntrl(c) && c != 0x20);
}
