/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _log10.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:23:39 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define LOG10E	0.43429448190325182000

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static	DBLBIT	s_log10tbl={0x0e,0xe5,0x26,0x15,0x7b,0xcb,0xdb,0x3f} ;

#define	LOG10E	s_log10tbl.val

#endif

double __CDECL log10(double  x)
{
	return( log(x)*LOG10E );
}
