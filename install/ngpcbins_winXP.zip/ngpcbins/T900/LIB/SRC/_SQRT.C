/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _sqrt.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:25:44 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define	C1	0.41731
#define	C2	0.59016
#define	C3	0.70710678118654752440

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static DBLBIT s_sqrttbl[]={
	{0xf7,0xcc,0x92,0x00,0x35,0xb5,0xda,0x3f},
	{0x18,0x09,0x6d,0x39,0x97,0xe2,0xe2,0x3f},
	{0xcd,0x3b,0x7f,0x66,0x9e,0xa0,0xe6,0x3f}
};

#define	C1	s_sqrttbl[0].val
#define	C2	s_sqrttbl[1].val
#define	C3	s_sqrttbl[2].val

#endif

double __CDECL sqrt(double  x)
{
	double	f, y;
	int	n;
	
	if (x == 0.0)
		return x;
	if (x < 0.0) {
		errno = EDOM;
		return 0.0;
	}
	f = frexp(x, &n);
	y = C1 + C2 * f;
	y = (y + f/y);
	y = ldexp(y,-2) + f/y;	/* fast calculation of y2 */
	y = ldexp(y + f/y, -1);
	y = ldexp(y + f/y, -1);
	
	if (n&1) {
		y *= C3;
		++n;
	}
	return ldexp(y,n/2);
}
