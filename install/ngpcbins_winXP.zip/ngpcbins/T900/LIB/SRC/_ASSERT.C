/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _assert.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:01:35 $	*/

/*
#include <stdio.h>
*/
#include <stdlib.h>
#include <assert.h>

void __CDECL _assert(const char *expression, const char *filename, unsigned int line)
{
/*	Dummy
	fprintf(stderr, "Assertion failed: %s, %s, %u\n", expression, filename, line);
*/
	abort();
}

