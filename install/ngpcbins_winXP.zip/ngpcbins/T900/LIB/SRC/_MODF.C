/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _modf.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:23:22 $	*/

#include <float.h>
#include <math.h>

double __CDECL	_fint(double dbl);

double __CDECL modf(double x, double *nptr)
{
	double  ret;

	ret = 0.0;
	*nptr = _fint(x);
	ret = x - *nptr;

	return(ret);
}
