/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MEMCHR.C $	*/
/*	$Revision: 1.3.1.2 $	*/
/*	$Date: 1996/02/27 14:42:28 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
void * __CDECL memchr(const void *s, int c, size_t n)
{
const	unsigned char	*p = s;

	while (n--) {
		if (*p == (unsigned char)c)
			return ((void *)p);
		p++;
	}
	return (NULL);
}
#elif defined(__900__)
void *memchr(const void *s1,int c, size_t n) {
	__ASM("		;; @(#)memchr.s	1.1 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void *memchr(const void *s1, int c, size_t n)");
	__ASM("		;; RET	:		find position or NULL");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+10");
	__ASM("		;; ");
	__ASM("		ld		XHL,0");
	__ASM("		ld		BC,(XSP+10)		; n");
	__ASM("		cp		BC,0");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		ld		XHL,(XSP+4)		; s1");
	__ASM("		ld		WA,(XSP+8)		; c");
	__ASM("		;; ");
	__ASM("		cpir	A,(XHL+)");
	__ASM("		dec		1,XHL			; adjust address");
	__ASM("		ret		z");
	__ASM("		ld		XHL,0			; return NULL");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif defined(__90__)
void *memchr(const void *s1,int c, size_t n) {
	__ASM("		;; @(#)memchr.s	1.1 95/12/11");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; void *memchr(const void *s, int c, size_t n)");
	__ASM("		;; RET	:		find position or NULL");
	__ASM("		;; s	:		SP+0x2");
	__ASM("		;; c	:		SP+0x4");
	__ASM("		;; n	:		SP+0x6");
	__ASM("		;; ");
	__ASM("		ld		BC,(SP+0x6)		; n");
	__ASM("		ld		HL,BC");
	__ASM("		cp		HL,0");
	__ASM("		ld		HL,0			; return NULL");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		ld		HL,(SP+0x2)		; s");
	__ASM("		ld		A,(SP+0x4)		; c");
	__ASM("		;; ");
	__ASM("		cpir");
	__ASM("		dec		HL			; adjust address");
	__ASM("		ret		z");
	__ASM("		ld		HL,0			; return NULL");
	__ASM("		;; ret");
	return (void *)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *memchr(const void *s1,int c, size_t n) {
	__ASM("		;; @(#)memchr.s 1.1 95/12/01");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *memchr(const void *s, int c, size_t n)");
	__ASM("		;; RET	:		find position or NULL");
	__ASM("		;; s	:		SP+0x4");
	__ASM("		;; c	:		SP+0x7");
	__ASM("		;; n	:		SP+0x9");
	__ASM("		;;	");
	__ASM("		ld		BC,		(SP+0x9);	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__SetNull;	");
	__ASM("		ld		WA,		(SP+0x7);	");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;	");
	__ASM("__ByteComp:");
	__ASM("		cmp		A,		(IY)	;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		inc		IY				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__ByteComp;	");
	__ASM("		;						;	");
	__ASM("__SetNull:");
	__ASM("		ld		IY,		0x0		;	");
	__ASM("__End:");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#elif defined(__870X__)
void *memchr(const void *s1,int c, size_t n) {
	__ASM("		;; @(#)memchr.s 1.1 95/10/26");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *memchr(const void *s1, int c, size_t n)");
	__ASM("		;; RET	:		find position or NULL");
	__ASM("		;; s1	:		SP+0x6");
	__ASM("		;; s2	:		SP+0x8");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;; ");
	__ASM("		push	HL				;	");
	__ASM("		ld		BC,		(SP+0xa);	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__SetVal;	");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("		ld		WA,		(SP+0x8);	");
	__ASM("		;						;	");
	__ASM("__ByteComp:");
	__ASM("		cmp		A,		(HL+)	;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__ByteComp;	");
	__ASM("		;						;	");
	__ASM("__SetVal:");
	__ASM("		ld		HL,		0x1		;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		dec		HL				;	");
	__ASM("		ld		BC,		HL		;	");
	__ASM("		pop		HL				;	");
	__ASM("		;						;ret");
	return (void *)__BC;
}
#endif
