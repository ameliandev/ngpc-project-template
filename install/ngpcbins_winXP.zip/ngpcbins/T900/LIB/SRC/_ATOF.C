/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _atof.c $	*/
/*	$Revision: 1.1.1.3 $	*/
/*	$Date: 1995/07/24 15:17:00 $	*/

#include <stdlib.h>
#include <ctype.h>

#ifdef FLOAT
char __CDECL	_afcnv(int (*fnc)(), int prec, char *val, int width);
#endif

static void __CDECL	_setstrchar(char *s);
static int __CDECL	_getstrchar(void);

static char	*str_p;

double __CDECL atof(const char* str)
{
        double  val;
        
        while (isspace(*str)) str++;
        _setstrchar((char *)str);
        _afcnv(_getstrchar, 8, (char*)&val, -1);
        return (val);
}

static void __CDECL	_setstrchar(char *s)
{
        str_p = s ;
}

static int __CDECL	_getstrchar(void)
{
	return ((int)*str_p++);
}
