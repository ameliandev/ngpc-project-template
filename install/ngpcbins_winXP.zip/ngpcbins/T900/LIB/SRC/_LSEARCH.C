/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _lsearch.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:15:31 $	*/

#include <stdlib.h>

void * __CDECL	_lsearch(const void *key, void *base, size_t *nmemb, size_t size, int (*compar)(const void *, const void *), int flag);

void * __CDECL lsearch(const void *key, void *base, size_t *nmemb, size_t size, int (*compar)(const void *, const void *))
{
        return(_lsearch(key, base, nmemb, size, compar, 1));
}
