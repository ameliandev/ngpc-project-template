/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _stricmp.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:11:50 $	*/

#include <ctype.h>
#include <string.h>

int __CDECL stricmp(const char *s1, const char *s2)
{
	char c1, c2;

	while ((c1 = toupper(*s1)) == (c2 = toupper(*s2))) {
		if(!c1)		return (0);
		s1++;		s2++;
	}
	return (c1 - c2);
}
