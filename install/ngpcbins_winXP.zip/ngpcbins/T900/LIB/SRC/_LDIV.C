/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _ldiv.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:08:28 $	*/

#include <stdlib.h>

ldiv_t	ldiv(long int numer,long int denom)
{
	ldiv_t dv;

	if(denom) {
		dv.quot = numer / denom;
		dv.rem = numer % denom;
	}
	return (dv);
}
