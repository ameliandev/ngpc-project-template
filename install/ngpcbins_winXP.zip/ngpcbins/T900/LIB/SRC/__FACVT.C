#include <string.h>
#include <stdlib.h>
/*	$RCSfile: __facvt.c $	*/
/*	$Revision: 1.1.1.5 $	*/
/*	$Date: 1995/01/31 17:54:43 $	*/

typedef union   {
        double		d;
        long double	ld;
        unsigned char	c[10];
} dc;

#define LOG2		301
#define FUL8B		0xff
#define SHIFT8		8
#define	LONGDOUBLE	0x80
#define	ISLONGDOUBLE(x)	(x & LONGDOUBLE)

static  char	buf[32];
static  unsigned short	nn1[32];
static  unsigned short	ftbl[32];

static int sftlog(short e);
static int normlz(register unsigned short* a, register x);
static void div10(unsigned short *t);
static void sft_r(register unsigned short* a, register y, register x);
static void mlt10(unsigned short *t);
static int normlz2(register unsigned short *a, register x);
static void frccal(unsigned short frc, int p);
static void sft_l(register unsigned short* a, register x, register y);
static void mul10(void);
static void bufcal(unsigned short f,int i);

char * __CDECL _facnv( char* dbl, unsigned char* s, int flag, int* e, int* sgn )
{
	dc	d;
	dc	d1;
	short	exp=0;
	int	i,j;
	int	sft;
	int	seido=15;
	int	kasu_len=8;
	int	round;
	int	flg;

	memset(buf,0,32);
	for (i = 0;i < 32; i++) ftbl[i] = nn1[i] = 0;
	if( ISLONGDOUBLE(flag) ) {
		seido=18;
		kasu_len=10;
	}
	for( i=0; i<kasu_len; i++ ) {
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
		d.c[i] = (unsigned char)dbl[(kasu_len-1)-i];
#else
		d.c[i] = dbl[i];
#endif
	}
	if (d.c[0] & 0x80)
		*sgn = 1;
	else	*sgn = 0;
        
	if( ISLONGDOUBLE(flag) && (d.c[0] || d.c[1]) ) {
		exp = ((short)(d.c[0] & 0x7f) << 8)  + (short)d.c[1] - 16384;
	}
	else if( d.c[0] || d.c[1] ) {
		exp = ((short)(d.c[0] & 0x7f) << 4) + ((short)(d.c[1] & 0xf0) >> 4) - 1024;
	}
	sft = sftlog(exp);
	if (exp < 0)	sft--;
	if( ISLONGDOUBLE(flag) ) {
		for (i = 2;i < 10 ;i++) nn1[i-2] = d.c[i] & 0xff;
	}
	else {
		flg=0;
		for (i = 0;i < 8;i++) {
			if( d.c[i] ) {
				flg=1;
				break;
			}
		}
		d.c[1] &= 0xf;
		for (i = 1;i < 8;i++) nn1[i-1] = d.c[i] & 0xff;
		if( flg ) nn1[0] |= 0x10;
	}
	normlz(nn1,kasu_len);
	if (exp > 0) {
		for(i = 0;i<sft;i++) {
			div10(nn1);
			exp -= normlz(nn1,kasu_len);
		}
			sft_r(nn1,8-exp-2,seido);
	}
        else {
		for(i = 0;i< -sft;i++) {
			mlt10(nn1);
			exp += normlz2(nn1,kasu_len);
		}
		sft_r(nn1,8-exp-2,seido);
	}
	for (i = 1;i < 9 ;i++) {
		frccal(nn1[i], i);
	}
	j = 0;
	if (nn1[0] > 9) {
		s[j++] = (unsigned char)(nn1[0] / 10);
		sft++;
	}
	s[j++] = (unsigned char)(nn1[0] % 10);
	sft++;
	for (i=1;i<seido+2;i++)
		s[j++] = buf[i];
        
	if (s[seido+1] >= 5)
		s[seido]++;
	s[seido+1] = '\0';
        
	for (i = seido;i && s[i] > 9;i--) {
		s[i-1]++;
		s[i] = 0;
	}

	for (i = 0;i < seido+1;i++)
		s[i] |= '0';
	*e = sft;
	return ((char*)s);
}

static void sft_r(register unsigned short* a, register y, register x)
{
	register i , mask;

	for (i = 0, mask = 0; i < y; i++) {
		mask <<= 1;
		mask |= 0x1;
	}
	for(i = x-1; 0 < i; i--) {
		a[i] >>= y;
		a[i] |= (a[i-1]&mask) << (8 - y);
	}
	a[0] >>= y;
}

static void sft_l(register unsigned short* a, register x,  register y)
{
	register i;

	a[0] &= FUL8B;
	for(i = 1; i < (x*2) ; i++) {
		a[i] <<= y;
		a[i-1] += a[i] >> SHIFT8;	/* overup1(&a[i]) */
		a[i] &= FUL8B;
	}
}

static void frccal(unsigned short frc, int p)
{
	int     i;
	for (i = 0; i < 9; i++)
		ftbl[i] = 0;
	ftbl[8] = frc;
	i = 0;
	for (;;) {
		if (i > 32)
			return;
		if (ftbl[0] == 0 &&
			ftbl[1] == 0 &&
			ftbl[2] == 0 &&
			ftbl[3] == 0 &&
			ftbl[4] == 0 &&
			ftbl[5] == 0 &&
			ftbl[6] == 0 &&
			ftbl[7] == 0 &&
			ftbl[8] == 0)
			break;
		while (ftbl[8-p] == 0) {
			i++;
			mul10();
		}
		bufcal(ftbl[8-p],i);
		ftbl[8-p] = 0;
	}
}

static void bufcal(unsigned short f,int i)
{
	if (i < 32)
		buf[i] += (unsigned char)f;
	while (i >= 32) i--;
	while(buf[i] >= 10 && i > 0) {
		buf[i-1]++;
		buf[i--] -= 10;
	}
}

static void div10(unsigned short *t)
{
	int     i;
        
	for (i = 0;i < 9;i++) {
		t[i+1] += t[i] % 10 * 256;
		t[i] /= 10;
	}
}

static void mlt10(unsigned short *t)
{
	int     i,j;
        
	for (i = 0;i < 16;i++) {
		t[i] *= 10;
		if (i) {
			for(j=i;j > 0 && t[j] > 255;j--) {
				t[j-1] += t[j] >> SHIFT8;
				t[j] &= FUL8B;
			}
		}
	}
	if ((t[15] & 0x80) != 0)
		t[14]++;
	t[15] = 0;
}

static void mul10(void)
{
	int     i;
        
	for (i = 0;i < 10;i++) {
		if (ftbl[i] == 0)
			continue;
		ftbl[i] *= 10;
	}
	for (i = 9;i > 0;i--) {
		if (ftbl[i] >= 256) {
			ftbl[i-1] += (ftbl[i] >> 8);
			ftbl[i] &= 0xff;
		}
	}
}

static  int normlz(register unsigned short* a, register x)
{
	register i, j;
        
	for (j = 0; j<x; j++) {
		if( a[j] ) break;
	}
	if( j==x ) return(0);
	for (i = 0; !(a[0]&0x80); i += j) {
		for (j = 0; !(a[0]&0x80) && j < 8; j++)
			a[0] <<= 1;
		if (j)
			sft_l(a,x,j);
	}
	return (i);
}

static int normlz2(register unsigned short *a, register x)
{
	register	j;
	unsigned	b;

	for (j = 0; j<x; j++) {
		if( a[j] ) break;
	}
	if( j==x ) return(0);
	b = a[0];
	for (j = 0; (b&0xff00) && j < 8; j++)
		b >>= 1;
	if (j)
		sft_r(a,j,x);
	return (j);
}

static int sftlog(short e)
{
	long    we;
	
	we = (long)e * (long)LOG2;
	we = (we<0 ? -we : we);
	if( we%1000L > 980L ) {
		we /= 1000L;
		we++;
	}
	else if( we && (we%1000L < 20L) ) {
		we /= 1000L;
		we--;
	}
	else {
		we /= 1000L;
	}
	we = (e<0 ? -we:we);
	
	return((int) we);
}
