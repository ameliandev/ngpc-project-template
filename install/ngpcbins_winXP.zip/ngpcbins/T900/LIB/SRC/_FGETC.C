/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fgetc.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:05:40 $	*/

#include <stdio.h>

int __CDECL fgetc(FILE *stream)
{
	if (stream->flag & __UNGETC) {
		stream->flag &= ~__UNGETC;
		return (stream->unget);
	}
	else	return ((*stream->in)());
}
