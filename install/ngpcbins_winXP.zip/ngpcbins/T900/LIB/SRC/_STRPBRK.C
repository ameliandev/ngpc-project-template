/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strpbrk.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:13:24 $	*/

#include <string.h>

char * __CDECL strpbrk(const char *s1, const char *s2)
{
        const char *s;

        for ( ; *s1; ++s1)
                for (s = s2; *s; ++s)
                        if (*s1 == *s)	return ((char *)s1);
	return (0);
}
