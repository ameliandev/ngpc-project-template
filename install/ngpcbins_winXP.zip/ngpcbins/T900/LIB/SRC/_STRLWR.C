/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strlwr.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:12:00 $	*/

#include <string.h>
#include <ctype.h>

char * __CDECL strlwr(char *s)
{
	char *s0 = s;

	while (*s) {
		*s = (char)tolower(*s);
		++s;
	}
	return (s0);
}
