/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: __fint.c $	*/
/*	$Revision: 1.1.1.2 $	*/
/*	$Date: 1995/01/31 17:49:26 $	*/

#include <math.h>

/*
   1) e==2047  && f!=0 : NaN
   2) e==2047  && f==0 : (-1)^s * Infinity
   3) 0<e<2047         : (-1)^s * 2^(e-1023) * (1.f)
   4) e==0     && f!=0 : (-1)^s * 2^(-1022)  * (0.f)
   5) e==0     && f==0 : (-1)^s 0
*/

double _fint(double dbl)
{
	unsigned short maru[4] = { 0x0000,0x0000,0x0000,0x0000};
	/* define union */
	union {
		double  d;
		unsigned char	uc[8];
		unsigned short	us[4];
	} d;
	int	i,pos;
	int	e;
	unsigned short be;
	unsigned char msk,work[7];
	int	sft;

	d.d = dbl;
	/* get index part */
	e = ( d.us[3] & 0x7ff0 ) >> 4;
	if(e==0 || e==2047)	return 0.0;
	be = (unsigned short) e;
	e -= 1023;
	
	/* make round */
	if(e<40) {
		maru[0] = 0x000f;
		maru[3] = d.us[3] & 0xfff0;
		d.d += *(double *)maru;
		maru[0] = 0x0000;
		d.d -= *(double *)maru;
		e = ( d.us[3] & 0x7ff0 ) >> 4;
		be = (unsigned short) e;
		e -= 1023 ;
	}

	/* if e is minus, there is no interal part */
	if(e<0)	return 0.0;
	/* if e is grater or equal than 52, return it */
	if(e>=52) return dbl;
	/* set mask position */
	pos = e/8;	/* byte */
	sft = e % 8;	/* fraction bit */

	/* unpack */
	for(i=6; i>0; i--) {
		unsigned char mk;

		mk = (d.uc[i] << 4) | (d.uc[i-1] >> 4);
		work[6-i] = mk;
	}
	work[6] = d.uc[0] << 4;

	/* initialize floating */
	for(i=6; i>pos; i--) work[i]=0;
	/* manupulate fraction */
	if(sft) {
		msk = 0xff << (8-sft);
		work[pos] &= msk;
	}
	else	work[pos] = 0;

	/* pack */
	for(i=6; i>0; i--) {
		unsigned char mk;

		mk = (work[i] >> 4) | (work[i-1] << 4);
		d.uc[6-i] = mk;
	}
	d.uc[6] = work[0] >> 4;
	
	/* assign sign & index */
	d.us[3] &= ~(0x7ff0);
	d.us[3] |= (be << 4);

	return(d.d);
}
