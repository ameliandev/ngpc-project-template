/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _rand.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:09:18 $	*/

#include <stdlib.h>

static unsigned long int Seed = 1;

int __CDECL rand(void)
{
        Seed = Seed * 1103515245 + 12345;
	return (int)(Seed % RAND_MAX);
}

void __CDECL srand(unsigned int seed)
{
	Seed = seed;
}
