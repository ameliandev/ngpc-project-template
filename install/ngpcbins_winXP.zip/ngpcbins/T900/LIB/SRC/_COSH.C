/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _cosh.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:20:55 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define	C1	0.69316101074218750000

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static DBLBIT s_coshtbl={0x00,0x00,0x00,0x00,0x60,0x2e,0xe6,0x3f} ;

#define	C1	s_coshtbl.val

#endif

double __CDECL cosh(double  x)
{
	double  ret=1.0;

	if(x==0.0)	return(ret);
	if( fabs(x)-C1 > LN_DBLMAX ) {
		errno=ERANGE;
		return(HUGE_VAL);
	}
	ret = (exp(x)+exp(-x)) / 2;
	return(ret);
}
