/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _cos.c $	*/
/*	$Revision: 1.2.1.1 $	*/
/*	$Date: 1995/01/31 21:31:03 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL _trig(double x, double y, int sign );

double __CDECL cos(double  x)
{
	return( _trig(x, fabs(x) + PAI5, 0) );
}
