/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _qsort.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:09:10 $	*/

#include <stdlib.h>
#include <string.h>

void __CDECL qsort(void *base, size_t nmemb, size_t size, int (*compar)(const void *, const void *))
{
	char *key ;
	char *first,*last,*max ;

	last = max = (char *)base + (nmemb - 1) * size ;
	first = base ;
	key = (char *)base + size * (nmemb >> 1) ;
	do {
		while ((*compar)(first, key) < 0) first += size ;
		while ((*compar)(key, last) < 0) last -= size ;
		if (first <= last) {
			if (first != last) {
				memswap(first, last, size) ;
				if (first == key) key = last ;
				else if (last == key) key = first ;
			}
			first += size ;
			last -= size ;
		}
	} while (first <= last) ;
	if (base < last)	qsort(base, (size_t)((last-(char*)base)/size+1), size, compar);
	if (first < max)	qsort(first, (size_t)((max-first)/size+1), size, compar);
}
