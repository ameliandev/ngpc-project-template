/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: __afcnv.c $	*/
/*	$Revision: 1.2.1.2 $	*/
/*	$Date: 1995/01/31 17:53:24 $	*/

#include        <stdio.h>
#include        <stdlib.h>
#include        <ctype.h>

#define SIZE_D	8
#define SIZE_LD	10
#define MAXID	1024
#define MINID	-1024
#define MAXTOP	11
#define MINTOP	0
#define F_PLUS	1
#define F_MINUS	-1
#define SHIFT	16
#define FUL16B	0xFFFF
#define INT(x)	(x-'0')
#define OFF	0
#define ON	1

typedef struct {
	long	exp;			/* exponent     */
	unsigned long    frc[8];	/* fraction     */
} IEEETYP;

static void overups(register unsigned long* pp, register unsigned long* p);
static void ieeefmt(register IEEETYP* p, register int y);
static void round(register IEEETYP* p, register int x, register unsigned int y);
static void ldbl_set(register IEEETYP* p, register char* b, register int sign);
static void dbl_set(register IEEETYP* p, register char* b, register int sign);
static void sgl_set(register IEEETYP* p, register char* b, register int sign);
static void mltint(register unsigned long* a,register unsigned long* b, register unsigned long* c);
static void shift_l(register unsigned long* a, register int x, register int y);
static void normalize(register unsigned long* a, register int x, register IEEETYP* p);
static void shift_r(register unsigned long* a, register int y);

static  IEEETYP  normtab[] = {

/* beki      |expo |---------  fraction  ---------|*/
/* -1024*/  {-3529, 0xA2A6, 0x82A5, 0xDA57, 0xC0BD,
                    0x87A6, 0x0158, 0x6BD3, 0xF698},

/* -512 */  {-1828, 0x9049, 0xEE32, 0xDB23, 0xD21C,
                    0x7132, 0xD332, 0xE3F2, 0x04D5},

/* -256 */  { -978, 0xC031, 0x4325, 0x637A, 0x1939,
                    0xFA91, 0x1155, 0xFEFB, 0x5309},

/* -128 */  { -553, 0xDDD0, 0x467C, 0x64BC, 0xE4A0,
                    0xAC7C, 0xB3F6, 0xD05D, 0xDBDE},

/* -64  */  { -340, 0xA87F, 0xEA27, 0xA539, 0xE9A5,
                    0x3F23, 0x98D7, 0x47B3, 0x6224},

/* -32  */  { -234, 0xCFB1, 0x1EAD, 0x4539, 0x94BA,
                    0x67DE, 0x18ED, 0xA581, 0x4AF2},

/* -16  */  { -181, 0xE695, 0x94BE, 0xC44D, 0xE15B,
                    0x4C2E, 0xBE68, 0x7989, 0xA9B4},

/* -8   */  { -154, 0xABCC, 0x7711, 0x8461, 0xCEFC,
                    0xFDC2, 0x0D2B, 0x36BA, 0x7C3D},

/* -4   */  { -141, 0xD1B7, 0x1758, 0xE219, 0x652B,
                    0xD3C3, 0x6113, 0x404E, 0xA4A9},

/* -2   */  { -134, 0xA3D7, 0x0A3D, 0x70A3, 0xD70A,
                    0x3D70, 0xA3D7, 0x0A3D, 0x70A4},

/* -1   */  { -131, 0xCCCC, 0xCCCC, 0xCCCC, 0xCCCC,
                    0xCCCC, 0xCCCC, 0xCCCC, 0xCCCC},

/* 1024 */  {3274,  0xC976, 0x7586, 0x8175, 0x0C17,
                    0x650D, 0x3D28, 0xF18B, 0x50CE},

/*  512 */  {1573,  0xE319, 0xA0AE, 0xA60E, 0x91C6,
                    0xCC65, 0x5C54, 0xBCA0, 0x58F9},

/*  256 */  { 723,  0xAA7E, 0xEBFB, 0x9DF9, 0xDE8D,
                    0xDDBB, 0x901B, 0x98FE, 0xEAB8},

/*  128 */  { 298,  0x93BA, 0x47C9, 0x80E9, 0x8CDF,
                    0xC66F, 0x336C, 0x36B1, 0x0137},

/*  64  */  {  85,  0xC278, 0x1F49, 0xFFCF, 0xA6D5,
                    0x3CBF, 0x6B71, 0xC76B, 0x25FB},

/*  32  */  { -21,  0x9DC5, 0xADA8, 0x2B70, 0xB59D,
                    0xF020,      0,      0,      0},

/*  16  */  { -74,  0x8E1B, 0xC9BF, 0x0400,      0,
                         0,      0,      0,      0},

/*   8  */  {-101,  0xBEBC, 0x2000,      0,      0,
                         0,      0,      0,      0},

/*   4  */  {-114,  0x9C40,      0,      0,      0,
                         0,      0,      0,      0},

/*   2  */  {-121,  0xC800,      0,      0,      0,
                         0,      0,      0,      0},

/*   1  */  {-124,  0xA000,      0,      0,      0,
                         0,      0,      0,      0}
} ;  /* normtab ended */

char* str_p;			/* string top pointer */
int dec_point_char='.';		/* decimal point character */

char __CDECL _afcnv(int (*fnc)(), int prec, char *val, int width)
{
	IEEETYP  ieeedat;
	register int intgsign, point, indexsign;
	register int i, flocnt;
	register int indexin = OFF;
	register int zerodata = OFF;
	register int n;
	register long   index;
	register char   c;

	index = flocnt = 0;
	intgsign = indexsign = point = OFF;
	ieeedat.exp = 0;
	for (i=0; i<prec; i++)	val[i] = 0;		/* buffer init */
	for (i=0; i<8; i++)	ieeedat.frc[i] = 0L;

	while (c = (*fnc)()) {				/* input data check */
		if (!(width--))	break;
		if (isdigit(c)) {
			if (indexsign==OFF) {
				if (!(ieeedat.frc[0] & 0xF000)) {
					for(i=0; i<8; i++)	ieeedat.frc[i] *= 10;
					overups(ieeedat.frc, &ieeedat.frc[7]);
					if (INT(c)) {
						ieeedat.frc[7] += INT(c);
						overups(ieeedat.frc, &ieeedat.frc[7]);
					}
				}
				else	flocnt--;
				if (point==ON)	flocnt++;
			} else {
				n =index * indexsign - flocnt;
				if (-4932 < n && n < 4933) {
					index *= 10;
					index += INT(c);
					indexin = ON;
				}
			}
		} else if (c == 'e' || c == 'E') {
			if (indexsign)	break;
			indexsign = F_PLUS;
		} else if (c == 'f' || c == 'F') {
			continue ;
		} else if (c == 'l' || c == 'L') {
			continue ;
		} else if (c == '+') {
			if (intgsign == OFF)	intgsign = F_PLUS;
			else	indexsign = F_PLUS;
		} else if (c == '-') {
			if (intgsign == OFF && !indexsign)	intgsign = F_MINUS;
			else	indexsign = F_MINUS;
		} else if (c == dec_point_char) {
			point = ON;
		} else {
			break;
		}
	}
        
	if (indexsign && !indexin)	return(c);

	for (i=0; i<8; i++)		/* zero data check      */
		if (ieeedat.frc[i])	break;
	if (i < 8)	ieeefmt(&ieeedat,(int)((index*(long)indexsign)-(long)flocnt));
	else	zerodata = ON;

	if (prec == SIZE_D) {
		if (! zerodata) {
			round(&ieeedat,3,0x400);
			dbl_set(&ieeedat,val,intgsign);
		}
	} else if (prec == SIZE_LD) {
		if (! zerodata) {
			round(&ieeedat,4,0x4000);
			ldbl_set(&ieeedat,val,intgsign);
		}
	} else {
		if (! zerodata) {
			round(&ieeedat,1,0x80);
			sgl_set(&ieeedat, val,intgsign);
		}
	}
	return(c);
}	/* ieeetrs */

static void overups(register unsigned long* pp, register unsigned long* p)
{
	do {
		*(p-1) += *p >> SHIFT;
		*p &= FUL16B;
	} while (pp < --p);
}

static void mltint(register unsigned long* a,register unsigned long* b, register unsigned long* c)
{
	register int i, j, scnt;
	register int addflag = OFF;

	for (i = 0; i < 8; i++) {
		c[i] = a[i];
		c[i+8] = 0;
	}
	for (i = 0; i < 128; ) {
		scnt = 0;
		do {
			i++;
			if (c[0] & (0x8000 >> scnt++)) {
				addflag = ON;
				break;
			}
		} while (scnt < 16 && i < 128);
		c[0] <<= scnt;
		c[0] &= FUL16B;
		for (j = 1; j < 16; j++) {
			c[j] <<= scnt;
			c[j-1] += c[j] >> SHIFT;
			c[j] &= FUL16B;		/* overup1(&c[j]) */
		}
		if (addflag) {
			for (j = 0; j < 8; j++)	c[j+8] += b[j];
			overups(c,&c[15]);
			addflag = OFF;
		}
	}
}	/* mltint */

static void shift_r(register unsigned long* a, register int y)
{
	register int i, mask;

	for (i = 0, mask = 0; i < y; i++) {
		mask <<= 1;
		mask |= 0x1;
	}
	for(i = 7; 0 < i; i--) {
		a[i] += (a[i-1]&mask) << SHIFT;
		a[i] >>= y;
	}
	a[0] >>= y;
}

static void shift_l(register unsigned long* a, register int x, register int y)
{
	register int i;

	a[0] &= FUL16B;
	for(i = 1; i < x; i++) {
		a[i] <<= y;
		a[i-1] += a[i] >> SHIFT;	/* overup1(&a[i]) */
		a[i] &= FUL16B;
	}
}

static void normalize(register unsigned long* a, register int x, register IEEETYP* p)
{
	register int i, j;

	for (i = 0; !(a[0]&0x8000); i += j) {
		for (j = 0; !(a[0]&0x8000) && j < 16; j++)
			a[0] <<= 1;
		if (j)
			shift_l(a,x,j);
	}
	p->exp += (x==16?128L:0L) - i;
	for (i=0; i<8; i++)
		p->frc[i] = a[i];
}

static void ieeefmt(register IEEETYP* p, register int y)
{
	unsigned long wkl[16];
	register int h, k, i;

	if (y<0) {
		k = MINID;
		h = MINTOP;
	} else if (0<y) {
		k = MAXID;
		h = MAXTOP;
	} else {
		normalize(p->frc,8,p);
		return;
	}

	for (i=h; i<MAXTOP+h; i++) {
		while (y/k) {
			mltint(p->frc,normtab[i].frc,wkl);
			p->exp += normtab[i].exp;
			normalize(wkl,16,p);
			y -= k;
		}
		if (y == 0)
			break;
		k >>= 1;
	}
}	/* ieeefmt */

static void round(register IEEETYP* p, register int x, register unsigned int y)
{
	if (p->frc[x]&y) {
		if (y<<1) {
			p->frc[x] += y<<1;
			overups(p->frc,&p->frc[x]);
		}
	}
	while (FUL16B < p->frc[0]) {
		shift_r(p->frc,1);
		p->exp++;
	}
}

static void ldbl_set(register IEEETYP* p, register char* b, register int sign)
{
	p->exp += 16383L + 127L;
	if (p->exp < 0) {
		memset(b,0xff,10);
		return;
	} else if (32767L <= p->exp) {
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
		b[9] = 127;
		b[9] |= ((char)sign==F_MINUS ? 0x80 : 0);
		b[8] = -15;
		b[7] =
		b[6] =
		b[5] =
		b[4] =
		b[3] =
		b[2] =
		b[1] =
		b[0] = 0;
#else
		b[0] = 127;
		b[0] |= ((char)sign==F_MINUS ? 0x80 : 0);
		b[1] = -15;
		b[2] =
		b[3] =
		b[4] =
		b[5] =
		b[6] =
		b[7] =
		b[8] =
		b[9] = 0;
#endif
	} else {
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
		b[9] = (char)((p->exp >> 8) & 0x0000007f);
		b[9] |= (sign==F_MINUS ? 0x80 : 0);
		b[8] = (char)(p->exp  & 0x000000ff);
		b[7] = (char)(p->frc[0] >> 8 );
		b[6] = (char)(p->frc[0] & 0x000000ff);
		b[5] = (char)(p->frc[1] >> 8);
		b[4] = (char)(p->frc[1] & 0x000000ff);
		b[3] = (char)(p->frc[2] >> 8);
		b[2] = (char)(p->frc[2] & 0x000000ff);
		b[1] = (char)(p->frc[3] >> 8);
		b[0] = (char)(p->frc[3] & 0x000000ff);
#else
		b[0] = (char)((p->exp >> 8) & 0x0000007f);
		b[0] |= (sign==F_MINUS ? 0x80 : 0);
		b[1] = (char)(p->exp  & 0x000000ff);
		b[2] = (char)(p->frc[0] >> 8 );
		b[3] = (char)(p->frc[0] & 0x000000ff);
		b[4] = (char)(p->frc[1] >> 8);
		b[5] = (char)(p->frc[1] & 0x000000ff);
		b[6] = (char)(p->frc[2] >> 8);
		b[7] = (char)(p->frc[2] & 0x000000ff);
		b[8] = (char)(p->frc[3] >> 8);
		b[9] = (char)(p->frc[3] & 0x000000ff);
#endif
	}
}	/* ldbl_set */

static void dbl_set(register IEEETYP* p, register char* b, register int sign)
{
	p->exp += 1023L + 127L;
	if (p->exp <= 0) {
		memset(b,0xff,8);
		return;
	} else if (2047L <= p->exp) {
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
		b[7] = 127;
		b[7] |= ((char)sign==F_MINUS ? 0x80 : 0);
		b[6] = -15;
		b[5] =
		b[4] =
		b[3] =
		b[2] =
		b[1] =
		b[0] = 0;
#else
		b[0] = 127;
		b[0] |= ((char)sign==F_MINUS ? 0x80 : 0);
		b[1] = -15;
		b[2] =
		b[3] =
		b[4] =
		b[5] =
		b[6] =
		b[7] = 0;
#endif
	} else {
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
		b[7] = (char)((p->exp >> 4) & 0x0000007f);
		b[7] |= (sign==F_MINUS ? 0x80 : 0);
		b[6] = (char)((p->exp << 4) & 0x000000ff);
		shift_r(p->frc,3) ;
		b[6] |= (char)((p->frc[0] >> 8) &0x0000000F);
		b[5] = (char)(p->frc[0] & 0x000000ff);
		b[4] = (char)(p->frc[1] >> 8);
		b[3] = (char)(p->frc[1] & 0x000000ff);
		b[2] = (char)(p->frc[2] >> 8);
		b[1] = (char)(p->frc[2] & 0x000000ff);
		b[0] = (char)(p->frc[3] >> 8);
#else
		b[0] = (char)((p->exp >> 4) & 0x0000007f);
		b[0] |= (sign==F_MINUS ? 0x80 : 0);
		b[1] = (char)((p->exp << 4) & 0x000000ff);
		shift_r(p->frc,3) ;
		b[1] |= (char)((p->frc[0] >> 8) &0x0000000F);
		b[2] = (char)(p->frc[0] & 0x000000ff);
		b[3] = (char)(p->frc[1] >> 8);
		b[4] = (char)(p->frc[1] & 0x000000ff);
		b[5] = (char)(p->frc[2] >> 8);
		b[6] = (char)(p->frc[2] & 0x000000ff);
		b[7] = (char)(p->frc[3] >> 8);
#endif
	}
}	/* dbl_set */

static void sgl_set(register IEEETYP* p, register char* b, register int sign)
{
	union { short	sh[3];
		char	ch[6];
	} wk;

	p->exp += 127L + 127L;
	if (p->exp <= 0) {
		memset(b,0xff,4);
		return;
	} else if (255L <= p->exp) {
		wk.sh[0] = 255 << 7;
		wk.sh[1] = wk.sh[2] = 0;
	} else {
		wk.ch[0] = (char)(p->exp>>1);
		wk.ch[1] = (char)(p->exp<<7);
		wk.ch[2] = (char)(p->frc[0]>>8);
		wk.ch[3] = (char)(p->frc[0]);
		wk.ch[4] = (char)(p->frc[1]>>8);
		wk.ch[5] = (char)(p->frc[1]);
	}

#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
						/* fugo set     */
	b[3] = (sign==F_MINUS ? 0x80 : 0);
						/* bias set     */
	b[3] |= wk.ch[0]&0x7F;
	b[2] = wk.ch[1];
						/* fraction set */
	b[2] |= wk.ch[2]&0x7F;
	b[1] = wk.ch[3];
	b[0] = wk.ch[4];
#else
						/* fugo set     */
	b[0] = (sign==F_MINUS ? 0x80 : 0);
						/* bias set     */
	b[0] |= wk.ch[0]&0x7F;
	b[1] = wk.ch[1];
						/* fraction set */
	b[1] |= wk.ch[2]&0x7F;
	b[2] = wk.ch[3];
	b[3] = wk.ch[4];
#endif
}	/* sgl_set */
