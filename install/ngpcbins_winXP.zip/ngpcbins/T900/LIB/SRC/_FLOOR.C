/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _floor.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:20:10 $	*/

#include <float.h>
#include <math.h>

double __CDECL	_fint(double dbl);

double __CDECL floor(double  x)
{
	double  xx, k, w1, w2;

	xx= x;
	k = _fint(xx);
	w1= xx - k;
	w2= k - 1.0;
	if(w1<0.)	return(w2);
	else		return(k);
}
