/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _itoa.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:08:16 $	*/

#include <stdlib.h>
#include <string.h>

char * __CDECL itoa(int val, char *s, int radix)
{
	unsigned int u;
	char buf[1 + sizeof(val) * 8 + 1];
	char *p;
	int sign = 0;

	if ((radix < 2) || (radix > 36)) {
		s[0] = 0;
		return (s);
	}

	u = val;				/* assume positive */
	buf[sizeof(buf) - 1] = 0;
	p = &buf[sizeof(buf) - 2];		/* last character position */
	if (radix == 10 && (int) u < 0) {
		sign++;
		u = -u;
	}
	while (1) {
		*p = (u % radix) + '0';
		if (*p > '9')	*p += 'a'-'0'-10;
		if ((u /= radix) == 0)	break;
		p--;
	}
	if (sign)	*--p = '-';
	return (memcpy(s,p,(size_t)(&buf[sizeof(buf)] - p)));
}
