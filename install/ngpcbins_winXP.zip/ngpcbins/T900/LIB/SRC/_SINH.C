/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _sinh.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:22:26 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define	C1	0.69316101074218750000

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static DBLBIT s_sinhtbl={0x00,0x00,0x00,0x00,0x60,0x2e,0xe6,0x3f} ;

#define	C1	s_sinhtbl.val

#endif

double __CDECL sinh(double x)
{
	double	ret=0.0;

	if(x==0.0)	return(ret);
	if( x-C1 > LN_DBLMAX ) {
		errno=ERANGE;
		return(HUGE_VAL);
	}
	if( x<LN_DBLMIN ) {
		return(-HUGE_VAL);
	}
	ret = (exp(x)-exp(-x)) / 2.0;
	return(ret);
}
