/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _STRCMP.C $	*/
/*	$Revision: 1.4 $	*/
/*	$Date: 1997/03/12 13:48:10 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
int __CDECL strcmp(const char *s1, const char *s2)
{
	while (*s1 == *s2) {
		if (!*s1)	return(0);
		++s1; ++s2;
	}
	return (*s1 - *s2);
}
#elif defined(__900__)
int __CDECL strcmp(const char *s1, const char *s2) {
	register size_t	len1;

#if 1 /* 1997/03/12 */
	len1 = strlen(s1) + 1;
#else
	len1 = strlen(s1);
#endif
	return memcmp((const void *)s1,(const void *)s2,len1);
}
#elif defined(__90__)
int __CDECL strcmp(const char *s1, const char *s2) {
	__ASM("		;; @(#)strcmp.s	1.3 95/12/26");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; int __CDECL strcmp(const char *s1, const char *s2)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		SP+0x2");
	__ASM("		;; s2	:		SP+0x4");
	__ASM("		;; ");
	__ASM("		ld		HL,(SP+0x2)		; s1");
	__ASM("		ld		BC,(SP+0x4)		; s2");
	__ASM("		j		__SCMP3");
	__ASM("__SCMP1:");
	__ASM("		cp		(HL),0");
	__ASM("		j		ne,__SCMP2		; *s1 != NULL ?");
	__ASM("		ld		HL,0			; return NULL");
	__ASM("		ret");
	__ASM("__SCMP2:						; *s1 != NULL");
	__ASM("		inc		HL			; s1+1");
	__ASM("		inc		BC			; s2+1");
	__ASM("__SCMP3:");
	__ASM("		ld		A,(HL)			; *s1");
	__ASM("		sub		A,(BC)			; *s1-*s2");
	__ASM("		j		eq,__SCMP1		; *s1==*s2 ?");
	__ASM("		ld		L,A			; ");
	__ASM("		ld		H,0			; return");
	__ASM("		bit		7,L");
	__ASM("		j		z,__SCMP4");
	__ASM("		dec		H");
	__ASM("__SCMP4:");
	__ASM("		;; ret");
	return (int)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
int __CDECL strcmp(const char *s1, const char *s2) {
	__ASM("		;;	@(#)strcmp.s 1.1 95/12/19");
	__ASM("		;;	(C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;;	");
	__ASM("		;;	int __CDECL strcmp(const char *s1, const char *s2)");
	__ASM("		;;	RET		:	s1");
	__ASM("		;;	s1		:	SP+0x4");
	__ASM("		;;	s2		:	SP+0x7");
	__ASM("		;;	");
	__ASM("		ld		IY,		(SP+0x7);	");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("__ByteCmp:");
	__ASM("		ld		W,		(IX)	;	");
	__ASM("		j		z,		__End	;	");
	__ASM("		ld		A,		(IY)	;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IY				;	");
	__ASM("		sub		W,		A		;	");
	__ASM("		j		z,		__ByteCmp;	");
	__ASM("		;						;	");	
	__ASM("__End:");
	__ASM("		sext	BC,		W		;	");
	return( (int)__BC );
}
#elif defined(__870X__)
int __CDECL strcmp(const char *s1, const char *s2) {
	__ASM("		;;	@(#)strcmp.s 1.1 95/12/19");
	__ASM("		;;	(C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;;	");
	__ASM("		;;	int __CDECL strcmp(const char *s1, const char *s2)");
	__ASM("		;;	RET		:	int");
	__ASM("		;;	s1		:	SP+0x6");
	__ASM("		;;	s2		:	SP+0x8");
	__ASM("		;;	");
	__ASM("		push	HL				;	");
	__ASM("		ld		HL,		(SP+0x8);	");
	__ASM("		ld		DE,		(SP+0x6);	");
	__ASM("		ld		A,		0x0		;	");
	__ASM("__ByteCmp:");
	__ASM("		ld		A,		(DE)	;	");
	__ASM("		j		z,		__End	;	");
	__ASM("		inc		DE				;	");
	__ASM("		sub		A,		(HL+)	;	");
	__ASM("		j		z,		__ByteCmp;	");	
	__ASM("__End:");
	__ASM("		sext	BC,		A		;	");
	__ASM("		pop		HL				;	");
	return( (int)__BC );
}
#endif
