/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _atan2.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:17:39 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

int __CDECL	_sign(double x);

double __CDECL atan2(double y, double xy)
{
	double  x, x2, ret=0.0;

	if(xy==0.0 && y==0.0) {
		errno = EDOM ;
		return(y);
	}
	else if(xy==0.0) 
		return(_sign(y)*PAI5);
	else if(xy> 0.0) {
		x = y / xy;
		if(x==0.0)	return(ret);
		ret = atan(x);
	}
	else if(xy< 0.0) {
		x = fabs(y/xy);
		if(x==0.0)	return(PAI);
		x2 = atan(x);
		ret = _sign(y) * (PAI-x2);
	}

	return(ret);
}
