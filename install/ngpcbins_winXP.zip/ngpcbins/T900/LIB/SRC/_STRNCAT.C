/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strncat.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:12:31 $	*/

#include <string.h>

char * __CDECL strncat(char *s1, char *s2, size_t n)
{
	char *s = s1;

	while (*s1) s1++;
	while (n--) {
		*s1 = *s2;
		if (!*s1)	return (s);
		s1++;
		s2++;
	}
	*s1 = 0;
	return (s);
}
