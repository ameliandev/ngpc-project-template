/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMMOVE.C $	*/
/*	$Revision: 1.2.1.3 $	*/
/*	$Date: 1996/02/27 14:36:56 $	*/

#include <string.h>

#if defined(__9000__)
void * __CDECL __fmemmove(void *s1, const void *s2, unsigned long n)
{
	void		*s = s1;
	unsigned char	*p1 = s1;
const	unsigned char	*p2 = s2;


	if (p1 < p2) {
		while (n--)
			*p1++ = *p2++;
	}
	else {
		p1 += n - 1;
		p2 += n - 1;
		while (n--)
			*p1-- = *p2--;
	}
	return (s);
}

#elif defined(__900__)
void *__fmemmove(void *s1, const void *s2, unsigned long n) {
	__ASM("		;; @(#)fmemmove.s	1.2 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void	*__fmemmove(void *s1, const void *s2, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;;");
	__ASM("		ld		XHL,(XSP+4)");
	__ASM("		ld		XBC,(XSP+12)");
	__ASM("		and		XBC,0x00ffffff");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		ld		XIX,XHL			; s1");
	__ASM("		ld		XIY,(XSP+8)		; s2");
	__ASM("		;;");
	__ASM("		cp		XIX,XIY			; check overlap");
	__ASM("		ret		eq				; same address");
	__ASM("		j		ult,__ULT		; XIX < XIY");
	__ASM("		;;");
	__ASM("		;; use LDDR");
	__ASM("__UGT:						; XIX > XIY");
	__ASM("		dec		1,XBC");
	__ASM("		add		XIX,XBC			; destination start address");
	__ASM("		add		XIY,XBC			; source start address");
	__ASM("		inc		1,XBC");
	__ASM("		bit		0,IX			; 2m+1 ?");
	__ASM("		j		nz,__Skip1");
	__ASM("		lddb	(XIX-),(XIY-)");
	__ASM("		j		ov,__Skip1");
	__ASM("		cp		QBC,0");
	__ASM("		ret		z			; move end");
	__ASM("__Skip1:");
	__ASM("		dec		1,XIX");
	__ASM("		dec		1,XIY");
	__ASM("		srl		1,XBC			; XBC/=2");
	__ASM("		scc		c,E			; set rest to E");
	__ASM("		ld		WA,QBC");
	__ASM("		inc		1,WA");
	__ASM("		j		z,__Skip2");
	__ASM("__LoopLDDR:		");
	__ASM("		lddrw	(XIX-),(XIY-)");
	__ASM("		djnz	WA,__LoopLDDR		");
	__ASM("		inc		1,XIX");
	__ASM("		inc		1,XIY");
	__ASM("__Skip2:");
	__ASM("		cp		E,0");
	__ASM("		ret		eq			; rest ?");
	__ASM("		lddb	(XIX-),(XIY-)");
	__ASM("		ret");
	__ASM("		;; ");
	__ASM("		;; use LDIR");
	__ASM("__ULT:						; XIX < XIY");
	__ASM("		bit		0,IX");
	__ASM("		j		z,__Skip3		; 2m+0 ?");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		j		ov,__Skip3");
	__ASM("		cp		QBC,0");
	__ASM("		ret		z			; move end");
	__ASM("__Skip3:");
	__ASM("		srl		1,XBC");
	__ASM("		scc		c,E");
	__ASM("		ld		WA,QBC");
	__ASM("		inc		1,WA");
	__ASM("		j		z,__Skip4");
	__ASM("__LoopLDIR:		");
	__ASM("		ldirw	(XIX+),(XIY+)");
	__ASM("		djnz	WA,__LoopLDIR");
	__ASM("__Skip4:");
	__ASM("		cp		E,0");
	__ASM("		ret		eq			; rest ?");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *__fmemmove(void *s1, const void *s2, unsigned long n) {
	__ASM("		;; @(#)fmemmove.s	1.1 95/12/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void	*__fmemmove(void *s1, const void *s2, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;; ");
	__ASM("		ld		WA,		(SP+0xa);	");
	__ASM("		ld		BC,		(SP+0xc);	");
	__ASM("		cmp		BC,		0x10	;	");
	__ASM("		j		p,		__End	;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		f,		__JmpSet;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__JmpSet:");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("		cmp		IX,		(SP+0x7);	");
	__ASM("		j		p,		__Init2	;	");
	__ASM("__Init1:");
	__ASM("		ld		IY,		(SP+0x7);	");
	__ASM("__ByteMove1:");
	__ASM("		ld		L,		(IY)	;	");
	__ASM("		ld		(IX),	L		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__ByteMove1;");
	__ASM("		;						;	");
	__ASM("		ld		WA,		0xffff	;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		f,		__ByteMove1;");
	__ASM("		j		__End			;	");
	__ASM("		;						;	");
	__ASM("__Init2:");
	__ASM("		ld		HL,		WA		;	");
	__ASM("		dec		HL				;	");
	__ASM("		ld		IX,		HL		;	");
	__ASM("		ld		IY,		HL		;	");
	__ASM("		add		IX,		(SP+0x4);	");
	__ASM("		add		IY,		(SP+0x7);	");
	__ASM("__ByteMove2:");
	__ASM("		ld		L,		(IY)	;	");
	__ASM("		ld		(IX),	L		;	");
	__ASM("		dec		IY				;	");
	__ASM("		dec		IX				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__ByteMove2;");
	__ASM("		;						;	");
	__ASM("		ld		WA,		0xffff	;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		f,		__ByteMove2;");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#endif
