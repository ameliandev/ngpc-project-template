/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _tanh.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1995/01/20 22:00:56 $	*/

#include <float.h>
#include <math.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define	C1	1.164153218e-010

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static DBLBIT	s_tanhtbl={0x74,0x33,0xe0,0xff,0xff,0xff,0xdf,0x3d} ;

#define	C1	s_tanhtbl.val

#endif

double __CDECL tanh(double  x)
{
	double  ret=1.0, xx;

	xx=fabs(x);
	if(xx==0.0)	return(x);
	if( 0.0<xx && C1>xx ) {
		return(x);
	}
	if( xx>32.0 ) {
		if( x<0.0 ) {
			return(-ret);
		}
		return(ret);
	}
	ret = (exp(x)-exp(-x)) / (exp(x)+exp(-x));

	return(ret);
}
