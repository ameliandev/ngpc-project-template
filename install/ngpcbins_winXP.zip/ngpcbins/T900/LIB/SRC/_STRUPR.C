/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strupr.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:14:04 $	*/

#include <ctype.h>
#include <string.h>

char * __CDECL strupr(char *s)
{
	char *s0 = s;

	while (*s) {
		*s = (char)toupper(*s);
		++s;
	}
	return (s0);
}
