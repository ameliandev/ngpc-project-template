/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _isalnum.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:02:40 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL isalnum(int c)
{
	return ((c>='a' && c<='z') ||
		(c>='A' && c<='Z') ||
		(c>='0' && c<='9'));
}
