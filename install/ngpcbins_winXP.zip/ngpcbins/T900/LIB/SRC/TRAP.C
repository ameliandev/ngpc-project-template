/* Copyright(C) 1996 TOSHIBA Corporation All Rights Reseved */
/* $RCSfile: TRAP.C $ */
/* $Revision: 1.3 $ */
/* $Date: 1997/01/13 14:47:44 $ */

#include <stdio.h>

void (*_FloatErrorHandle)() = NULL;
