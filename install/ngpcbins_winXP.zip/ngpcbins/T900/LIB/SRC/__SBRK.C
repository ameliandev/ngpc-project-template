/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: __SBRK.C $	*/
/*	$Revision: 1.1.1.4 $	*/
/*	$Date: 1996/02/27 14:22:45 $	*/

#if defined (__9000__) || defined (__900__) || (defined(__870X__) && defined(__LARGE__))

extern unsigned long	SBRK_break,SBRK_size;

void * __adecl sbrk(unsigned long size) {

#else

extern unsigned int	SBRK_break,SBRK_size;

void * __adecl sbrk(unsigned int size) {

#endif

	void *addr;

	/* size==0 : return free size */
	if(!size) return (void *)SBRK_size;

	/* enough memory ? */
	if(SBRK_size < size) return (void *)-1L;

	/* allocate */
	addr = (void *)SBRK_break;
	SBRK_break += size;	/* inclease break address */
	SBRK_size  -= size;	/* decrease free size     */
	return addr;
}
