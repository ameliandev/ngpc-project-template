/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strrchr.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:13:30 $	*/

#include <string.h>

char * __CDECL strrchr(const char *s, int c)
{
	const char *s0;
	int i;

	for (i = strlen(s)+1, s0 = s+i; i; --i)
	        if (*(--s0) == (char)c)  return ((char *)s0);
	return (NULL);
}
