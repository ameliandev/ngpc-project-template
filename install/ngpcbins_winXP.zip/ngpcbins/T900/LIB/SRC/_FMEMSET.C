/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMEMSET.C $	*/
/*	$Revision: 1.2.1.3 $	*/
/*	$Date: 1996/02/27 14:37:25 $	*/
#include <string.h>

#if defined(__9000__)
void * __CDECL __fmemset(void *s, int c, unsigned long n)
{
	void *s0 = s;
	unsigned char	*p = (unsigned char *)s;

	while (n--) {
		*p++ = (unsigned char)c;
	}
	return (s0);
}

#elif defined(__900__)
void *__fmemset(void *s, int c, unsigned long n) {
	__ASM("		;; @(#)fmemset.s	1.1 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void *__fmemset(void *s, int c, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s	:		XSP+4");
	__ASM("		;; c	:		XSP+8");
	__ASM("		;; n	:		XSP+10");
	__ASM("		;; ");
	__ASM("		ld		XBC,(XSP+10)		; n");
	__ASM("		ld		XHL,(XSP+4)		; s");
	__ASM("		and		XBC,0x00ffffff	; 16M Byte");
	__ASM("		ret		z");
	__ASM("		ld		XIX,XHL");
	__ASM("		ld		WA,(XSP+8)		; c");
	__ASM("		;;");
	__ASM("		ld		DE,IX");
	__ASM("		neg		DE");
	__ASM("		and		DE,0x3			; 4m+0?");
	__ASM("		jr		z,__LongSet");
	__ASM("		;;");
	__ASM("__ByteSet1:");
	__ASM("		ld		(XIX+),A");
	__ASM("		sub		XBC,0x1");
	__ASM("		ret		z");
	__ASM("		djnz	DE,__ByteSet1");
	__ASM("		;;");
	__ASM("__LongSet:		");
	__ASM("		ld		DE,BC");
	__ASM("		srl		2,XBC");
	__ASM("		jr		z,__ByteSet2");
	__ASM("		ld		W,A");
	__ASM("		ld		QWA,WA");
	__ASM("		ld		IY,QBC");
	__ASM("		inc		1,IY");
	__ASM("__LongLoop:");
	__ASM("		ld		(XIX+),XWA");
	__ASM("		djnz	BC,__LongLoop");
	__ASM("		djnz	IY,__LongLoop");
	__ASM("__ByteSet2:		");
	__ASM("		and		DE,0x3");
	__ASM("		ret		z");
	__ASM("__ByteLoop2:");
	__ASM("		ld		(XIX+),A");
	__ASM("		djnz	DE,__ByteLoop2");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *__fmemset(void *s, int c, unsigned long n) {
	__ASM("		;; @(#)fmemset.s	1.1 95/12/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *__fmemset(void *s, int c, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s	:		SP+0x4");
	__ASM("		;; c	:		SP+0x7");
	__ASM("		;; n	:		SP+0x9");
	__ASM("		;; ");
	__ASM("		ld		WA,		(SP+0x9);	");
	__ASM("		ld		BC,		(SP+0xb);	");
	__ASM("		cmp		BC,		0x10	;	");
	__ASM("		j		p,		__End	;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		f,		__Init	;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		ld		DE,		(SP+0x7);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("__ByteSet:");
	__ASM("		ld		(IY),	E		;	");
	__ASM("		inc		IY				;	");
	__ASM("		;						;	");
	__ASM("__Div2:");
	__ASM("		shrc	B				;	");
	__ASM("		rorc	C				;	");
	__ASM("		rorc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		ld		D,		E		;	");
	__ASM("		cmp		WA,		0x0		;	");	
	__ASM("		j		f,		__WordSet;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordSet:");
	__ASM("		ld		(IY),	DE		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IY				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordSet;	");
	__ASM("		;						;	");
	__ASM("		ld		WA,		0xffff	;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		f,		__WordSet;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#endif
