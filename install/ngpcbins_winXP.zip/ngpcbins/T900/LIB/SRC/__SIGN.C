/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: __sign.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 19:01:26 $	*/

#include <math.h>

int __CDECL _sign(double  x)
{
	if(x==0.0)	return(0);
	if(x >0.0)	return(1);
	return(-1);
}
