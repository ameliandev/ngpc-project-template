/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MEMMOVE.C $	*/
/*	$Revision: 1.3.1.3 $	*/
/*	$Date: 1996/02/27 14:41:21 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
void * __CDECL memmove(void *s1, const void *s2, size_t n)
{
	void		*s = s1;
	unsigned char	*p1 = s1;
const	unsigned char	*p2 = s2;


	if (p1 < p2) {
		while (n--)
			*p1++ = *p2++;
	}
	else {
		p1 += n - 1;
		p2 += n - 1;
		while (n--)
			*p1-- = *p2--;
	}
	return (s);
}
#elif defined(__900__)
void *memmove(void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memmove.s	1.2 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void	*memmove(void *s1, const void *s2, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;;");
	__ASM("		ld		XHL,(XSP+4)");
	__ASM("		ld		BC,(XSP+12)");
	__ASM("		cp		BC,0");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		ld		XIX,XHL			; s1");
	__ASM("		ld		XIY,(XSP+8)		; s2");
	__ASM("		;;");
	__ASM("		cp		XIX,XIY			; check overlap");
	__ASM("		ret		eq				; same address");
	__ASM("		j		ult,__ULT		; XIX < XIY");
	__ASM("		;;");
	__ASM("		;; use LDDR");
	__ASM("__UGT:						; XIX > XIY");
	__ASM("		extz	XBC");
	__ASM("		dec		1,XBC");
	__ASM("		add		XIX,XBC			; destination start address");
	__ASM("		add		XIY,XBC			; source start address");
	__ASM("		inc		1,XBC");
	__ASM("		bit		0,IX			; 2m+1 ?");
	__ASM("		j		nz,__Skip1");
	__ASM("		lddb	(XIX-),(XIY-)");
	__ASM("		ret		nov			; BC==0 ?");
	__ASM("__Skip1:");
	__ASM("		srl		1,BC");
	__ASM("		j		z,__Skip2");
	__ASM("		dec		1,XIX");
	__ASM("		dec		1,XIY");
	__ASM("		lddrw	(XIX-),(XIY-)");
	__ASM("		inc		1,XIX");
	__ASM("		inc		1,XIY");
	__ASM("__Skip2:");
	__ASM("		ret		nc			; rest ?");
	__ASM("		lddb	(XIX-),(XIY-)");
	__ASM("		ret");
	__ASM("		;; ");
	__ASM("		;; use LDIR");
	__ASM("__ULT:						; XIX < XIY");
	__ASM("		bit		0,IX");
	__ASM("		j		z,__Skip3		; 2m+0 ?");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		ret		nov			; BC==0");
	__ASM("__Skip3:");
	__ASM("		srl		1,BC");
	__ASM("		j		z,__Skip4");
	__ASM("		ldirw	(XIX+),(XIY+)");
	__ASM("__Skip4:");
	__ASM("		ret		nc			; rest ?");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif defined(__90__)
void *memmove(void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memmove.s	1.1 95/12/11");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; void	*memmove(void *s1, const void *s2, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x2");
	__ASM("		;; s2	:		SP+0x4");
	__ASM("		;; n	:		SP+0x6");
	__ASM("		;;");
	__ASM("		ld		BC,(SP+0x6)		; n");
	__ASM("		ld		HL,BC");
	__ASM("		cp		HL,0");
	__ASM("		ld		HL,(SP+0x2)		; return s1");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		;;");
	__ASM("		ld		DE,(SP+0x4)		; s2");
	__ASM("		cp		HL,DE");
	__ASM("		ret		eq			; s1==s2 ?");
	__ASM("		j		ult,__ULT		; s1 < s2 ?");
	__ASM("		;;");
	__ASM("		;; use LDDR");
	__ASM("__UGT:						; s1 > s2");
	__ASM("		ld		IX,HL			; s1");
	__ASM("		dec		BC			; n-1");
	__ASM("		ld		HL,DE			; s2");
	__ASM("		add		HL,BC			; source start address");
	__ASM("		ld		DE,HL");
	__ASM("		ld		HL,IX			; s1");
	__ASM("		add		HL,BC			; destination start address");
	__ASM("		inc		BC			; n+1");
	__ASM("		ex		DE,HL			; s2<->s1");
	__ASM("		lddr");
	__ASM("		ld		HL,IX			; return s1");
	__ASM("		ret");
	__ASM("		;; ");
	__ASM("		;; use LDIR");
	__ASM("__ULT:						; s1 < s2");
	__ASM("		ld		IX,HL			; s1");
	__ASM("		ex		DE,HL			; s2<->s1");
	__ASM("		ldir");
	__ASM("		ld		HL,IX			; return s1");
	__ASM("		;; ret");
	return (void *)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *memmove(void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memmove.s	1.1 95/12/01");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void	*memmove(void *s1, const void *s2, size_t n)");
	__ASM("		;; RET	:		s1	");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;;	");
	__ASM("		ld		BC,		(SP+0xa);	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("		cmp		IX,		(SP+0x7);	");
	__ASM("		j		p,		__Init2	;	");
	__ASM("__Init1:");
	__ASM("		ld		IY,		(SP+0x7);	");
	__ASM("__ByteMove1:");
	__ASM("		ld		A,		(IY)	;	");
	__ASM("		ld		(IX),	A		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__ByteMove1;");
	__ASM("		j		__End			;	");
	__ASM("		;						;	");
	__ASM("__Init2:");
	__ASM("		ld		HL,		BC		;	");
	__ASM("		dec		HL				;	");
	__ASM("		ld		IX,		HL		;	");
	__ASM("		ld		IY,		HL		;	");
	__ASM("		add		IX,		(SP+0x4);	");
	__ASM("		add		IY,		(SP+0x7);	");
	__ASM("__ByteMove2:");
	__ASM("		ld		A,		(IY)	;	");
	__ASM("		ld		(IX),	A		;	");
    __ASM("     dec     IY              ;   ");
	__ASM("		dec		IX				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__ByteMove2;");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#elif defined(__870X__)
void *memmove(void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memmove.s	1.1 95/11/30");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh`TSE");
	__ASM("		;; ");
	__ASM("		;; void	*memmove(void *s1, const void *s2, size_t n)");
	__ASM("		;; RET	:		s1	");
	__ASM("		;; s1	:		SP+0x6");
	__ASM("		;; s2	:		SP+0x8");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;;");
	__ASM("		push	HL				;	");
	__ASM("		ld		BC,		(SP+0xa);	");
	__ASM("		cmp		BC,		0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		WA,		(SP+0x6);	");
	__ASM("		ld		DE,		(SP+0x8);	");
	__ASM("		;						;	");
	__ASM("		cmp		WA,		DE		;	");
	__ASM("		j		p,		__Init2	;	");
	__ASM("		;						;	");
	__ASM("__Init1:");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("__ByteMove1:");
	__ASM("		ld		(HL),	(DE)	;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		DE				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__ByteMove1	");
	__ASM("		j		__End			;	");
	__ASM("		;						;	");
	__ASM("__Init2:");
	__ASM("		add		WA,		BC		;	");
	__ASM("		dec		WA				;	");
	__ASM("		ld		HL,		WA		;	");
	__ASM("		ld		WA,		DE		;	");
	__ASM("		add		WA,		BC		;	");
	__ASM("		dec		WA				;	");
	__ASM("		ld		DE,		WA		;	");
	__ASM("__ByteMove2:");
	__ASM("		ld		(HL),	(DE)	;	");
	__ASM("		dec		HL				;	");
	__ASM("		dec		DE				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__ByteMove2;");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		BC,		(SP+0x6);	");
	__ASM("		pop		HL				;	");
	__ASM("		;						;ret");
	return (void *)__BC;
}
#endif
