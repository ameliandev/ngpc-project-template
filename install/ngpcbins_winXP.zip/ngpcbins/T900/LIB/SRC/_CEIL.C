/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _ceil.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:21:39 $	*/

#include <float.h>
#include <math.h>

double __CDECL	_fint(double dbl);

double __CDECL ceil(double  x)
{
	double  xx, k, w1, w2;

	xx= x;
	k = _fint(xx);
	w1= xx - k;
	w2= k + 1.0;
	if(w1<=0.)	return(k);
	else		return(w2);
}
