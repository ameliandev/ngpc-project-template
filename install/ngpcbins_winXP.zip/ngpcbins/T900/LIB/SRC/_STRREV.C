/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strrev.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:13:36 $	*/

#include <string.h>


char * __CDECL strrev(char *s)
{
	char tmp,*p,*q;

	p = s;
	for (q = p+strlen(p)-1; p < q; ++p, --q) {
		tmp = *p;
		*p = *q;
		*q = tmp;
	}
	return (s);
}
