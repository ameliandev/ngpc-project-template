/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _lfind.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:15:50 $	*/

#include <stdlib.h>

void * __CDECL	_lsearch(const void *key, void *base, size_t *nmemb, size_t size, int (*compar)(const void *, const void *), int flag);

void * __CDECL lfind(const void *key, const void *base, size_t *nmemb, size_t size, int (*compar)(const void *, const void *))
{
        return(_lsearch(key, (void *)base, nmemb, size, compar, 0));
}
