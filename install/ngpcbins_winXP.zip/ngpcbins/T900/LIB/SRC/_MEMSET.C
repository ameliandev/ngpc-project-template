/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MEMSET.C $	*/
/*	$Revision: 1.3.1.2 $	*/
/*	$Date: 1996/02/27 14:40:54 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
void * __CDECL memset(void *s, int c, size_t n)
{
	void *s0 = s;
	unsigned char	*p = (unsigned char *)s;

	while (n--) {
		*p++ = (unsigned char)c;
	}
	return (s0);
}
#elif defined(__900__)
void *memset(void *s, int c, size_t n) {
	__ASM("		;; @(#)memset.s	1.1 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void *memset(void *s, int c, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s	:		XSP+4");
	__ASM("		;; c	:		XSP+8");
	__ASM("		;; n	:		XSP+10");
	__ASM("		;; ");
	__ASM("		ld		BC,(XSP+10)		; n");
	__ASM("		ld		XHL,(XSP+4)		; s");
	__ASM("		cp		BC,0");
	__ASM("		ret		z");
	__ASM("		ld		XIX,XHL");
	__ASM("		ld		WA,(XSP+8)		; c");
	__ASM("		;;");
	__ASM("		ld		DE,IX");
	__ASM("		neg		DE");
	__ASM("		and		DE,0x3			; 4m+0?");
	__ASM("		jr		z,__LongSet");
	__ASM("		;;");
	__ASM("__ByteSet1:");
	__ASM("		ld		(XIX+),A");
	__ASM("		sub		BC,0x1");
	__ASM("		ret		z");
	__ASM("		djnz	DE,__ByteSet1");
	__ASM("		;;");
	__ASM("__LongSet:		");
	__ASM("		ld		DE,BC");
	__ASM("		srl		2,BC");
	__ASM("		jr		z,__ByteSet2");
	__ASM("		ld		W,A");
	__ASM("		ld		QWA,WA");
	__ASM("__LongLoop:");
	__ASM("		ld		(XIX+),XWA");
	__ASM("		djnz	BC,__LongLoop");
	__ASM("__ByteSet2:		");
	__ASM("		and		DE,0x3");
	__ASM("		ret		z");
	__ASM("__ByteLoop2:");
	__ASM("		ld		(XIX+),A");
	__ASM("		djnz	DE,__ByteLoop2");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif defined(__90__)
void *memset(void *s, int c, size_t n) {
	__ASM("		;; @(#)memset.s	1.2 95/12/25");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; void *memset(void *s, int c, size_t n)");
	__ASM("		;; RET	:		s");
	__ASM("		;; s	:		SP+0x2");
	__ASM("		;; c	:		SP+0x4");
	__ASM("		;; n	:		SP+0x6");
	__ASM("		;; ");
	__ASM("		ld		BC,(SP+0x6)		; n");
	__ASM("		ld		HL,BC");
	__ASM("		cp		HL,0");
	__ASM("		ld		HL,(SP+0x2)		; return s");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		;;");
	__ASM("		ld		IX,HL			; s");
	__ASM("		ld		A,(SP+0x4)		; c");
	__ASM("		;;");
	__ASM("		bit		0,C");
	__ASM("		jr		z,__WordSet		; n==even ?");
	__ASM("		;;");
	__ASM("		ld		(IX),A			; *p=c");
	__ASM("		inc		IX			; p+1");
	__ASM("		djnz		BC,__WordSet		; n-1,n!=0 ?");
	__ASM("		ret");
	__ASM("		;;");
	__ASM("__WordSet:					; n==even");
	__ASM("		ld		D,A");
	__ASM("		ld		E,A");
	__ASM("		srl		B			;");
	__ASM("		rr		C			; n/2");
	__ASM("__WordSetLoop:");
	__ASM("		ld		(IX),DE			; *p=*(p+1)=c");
	__ASM("		inc		IX			; p+1");
	__ASM("		inc		IX			; p+1");
	__ASM("		djnz		BC,__WordSetLoop	; n-1,n!=0 ?");
	__ASM("		;; ret");
	return (void *)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *memset(void *s, int c, size_t n) {
	__ASM("		;; @(#)memset.s 1.1 95/12/01");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *memset(void *s, int c, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s	:		SP+0x4");
	__ASM("		;; c	:		SP+0x7");
	__ASM("		;; n	:		SP+0x9");
	__ASM("		;;	");
	__ASM("		ld		WA,		(SP+0x9);	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		ld		BC,		(SP+0x7);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("__ByteSet:");
	__ASM("		ld		(IY),	C		;	");
	__ASM("		inc		IY				;	");
	__ASM("		;						;	");
	__ASM("__Div2:");
	__ASM("		shrc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		B,		C		;	");
	__ASM("		;						;	");
	__ASM("__WordSet:");
	__ASM("		ld		(IY),	BC		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IY				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordSet;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#elif defined(__870X__)
void *memset(void *s, int c, size_t n) {
	__ASM("		;; @(#)memset.s 1.1 95/10/26");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *memset(void *s, int c, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s	:		SP+0x6");
	__ASM("		;; c	:		SP+0x8");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		push	HL				;	");
	__ASM("		ld		WA,		(SP+0xa);	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("		ld		BC,		(SP+0x8);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Init	;	");
	__ASM("		;						;	");
	__ASM("__ByteSet:");
	__ASM("		ld		(HL+),	C		;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		shrc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		B,		C		;	");
	__ASM("__WordSet:");
	__ASM("		ld		(HL),	BC		;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		HL				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordSet;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		BC,		(SP+0x6);	");
	__ASM("		pop		HL				;	");
	__ASM("		;						;ret");
	return (void *)__BC;
}
#endif

