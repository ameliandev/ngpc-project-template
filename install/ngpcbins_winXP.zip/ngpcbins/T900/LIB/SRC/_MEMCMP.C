/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MEMCMP.C $	*/
/*	$Revision: 1.4.1.2 $	*/
/*	$Date: 1996/02/27 14:42:10 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
int __CDECL memcmp(const void *s1, const void *s2, size_t n)
{
	char	*cS1,*cS2;

	if(!n)
		return 0;
	cS1 = (char *)s1;
	cS2 = (char *)s2;
	/* odd ? */
	if(n & 1) {
		int diff;

		if((diff=(int)*cS1 - (int)*cS2))
			return diff;
		*cS1++; *cS2++;
	}
	/* div 2 */
	if( (n >>= 1) ) {
		do {
			int diff;

			diff=(int)*cS1 - (int)*cS2;
			if(diff)
				return diff;
			cS1++; cS2++;
			diff=(int)*cS1 - (int)*cS2;
			if(diff)
				return diff;
			cS1++; cS2++;
		}while(--n);
	}
	return (0);
}
#elif defined(__900__)
int __CDECL memcmp(const void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memcmp.s	1.6 95/08/21");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; int memcmp(const void *s1,const  void *s2, size_t n)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;; ");
	__ASM("		ld		BC,(XSP+12)		; n");
	__ASM("		ld		HL,0");
	__ASM("		cp		BC,0");
	__ASM("		ret		z				; check size");
	__ASM("		;; ");
	__ASM("		ld		XIX,(XSP+4)		; s1");
	__ASM("		ld		XIY,(XSP+8)		; s2");
	__ASM("		cp		XIX,XIY");
	__ASM("		ret		eq");
	__ASM("		ld		DE,IX");
	__ASM("		neg		DE");
	__ASM("		and		DE,0x3			; check address");
	__ASM("		jr		z,__MAIN");
	__ASM("		;; ");
	__ASM("__ByteCmp:		");
	__ASM("		ld		L,(XIX+)");
	__ASM("		extz	HL");
	__ASM("		ld		A,(XIY+)");
	__ASM("		extz	WA");
	__ASM("		sub		HL,WA");
	__ASM("		ret		nz				; *s1 != *s2");
	__ASM("		sub		BC,1");
	__ASM("		ret		z				; end ?");
	__ASM("		djnz	DE,__ByteCmp");
	__ASM("__MAIN:");
	__ASM("		ld		DE,BC");
	__ASM("		srl		2,BC			; / 4");
	__ASM("		jr		z,__SkipLong");
	__ASM("__LongCmp:");
	__ASM("		ld		XHL,(XIX+)");
	__ASM("		ld		XWA,(XIY+)");
	__ASM("		cp		XHL,XWA");
	__ASM("		j		z,__SkipCalc");
	__ASM("		cp		HL,WA");
	__ASM("		j		nz,__Cmp");
	__ASM("		ld		HL,QHL");
	__ASM("		ld		WA,QWA");
	__ASM("		;; compare HL & WA");
	__ASM("__Cmp:	");
	__ASM("		cp		L,A");
	__ASM("		jr		nz,__Calc");
	__ASM("		ld		L,H");
	__ASM("		ld		A,W");
	__ASM("__Calc:	");
	__ASM("		extz	HL");
	__ASM("		extz	WA");
	__ASM("		sub		HL,WA");
	__ASM("		ret");
	__ASM("__SkipCalc:");
	__ASM("		djnz	BC,__LongCmp");
	__ASM("		ld		HL,0				");
	__ASM("		;;");
	__ASM("__SkipLong:		");
	__ASM("		and		DE,0x3");
	__ASM("		ret		z		");
	__ASM("__ByteCmp2:");
	__ASM("		ld		L,(XIX+)");
	__ASM("		extz	HL");
	__ASM("		ld		A,(XIY+)");
	__ASM("		extz	WA");
	__ASM("		sub		HL,WA");
	__ASM("		ret		nz				; *s1 != *s2");
	__ASM("		djnz	DE,__ByteCmp2");
	__ASM("		;; ret");
	return (int)__HL;
}
#elif defined(__90__)
int __CDECL memcmp(const void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memcmp.s	1.3 95/12/21");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; int memcmp(const void *s1,const  void *s2, size_t n)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		SP+0x2");
	__ASM("		;; s2	:		SP+0x4");
	__ASM("		;; n	:		SP+0x6");
	__ASM("		;; ");
	__ASM("		ld		BC,(SP+0x6)		; n");
	__ASM("		ld		HL,BC");
	__ASM("		cp		HL,0");
	__ASM("		ld		HL,0			; return NULL");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		;;");
	__ASM("		ld		IX,(SP+0x2)		; s1");
	__ASM("		ld		IY,(SP+0x4)		; s2");
	__ASM("		ld		HL,IX");
	__ASM("		cp		HL,IY");
	__ASM("		ld		HL,0			; return NULL");
	__ASM("		ret		eq			; s1==s2 ?");
	__ASM("		;;");
	__ASM("		bit		0,C");
	__ASM("		jr		z,__WordCmp		; n==even ?");
	__ASM("		;;");
	__ASM("		ld		L,(IX)			;");
	__ASM("		ld		H,0			; *cS1");
	__ASM("		ld		E,(IY)			;");
	__ASM("		ld		D,0			; *cS2");
	__ASM("		sub		HL,DE			; *cS1-*cS2");
	__ASM("		ret		nz			; *cS1-*cS2!=0 ?");
	__ASM("		inc		IX			; cS1+1");
	__ASM("		inc		IY			; cS2+1");
	__ASM("		djnz		BC,__WordCmp		; n-1,n!=0 ?");
	__ASM("		ret");
	__ASM("		;;");
	__ASM("__WordCmp:					; n==even");
	__ASM("		ld		HL,(IX)			; *cS1");
	__ASM("		ld		DE,(IY)			; *cS2");
	__ASM("		cp		HL,DE");
	__ASM("		jr		nz,__Cmp		; *cS1-*cS2!=0 ?");
	__ASM("		inc		IX			; cS1+1");
	__ASM("		inc		IX			; cS1+1");
	__ASM("		inc		IY			; cS2+1");
	__ASM("		inc		IY			; cS2+1");
	__ASM("		dec		BC			; n-1");
	__ASM("		djnz		BC,__WordCmp		; n-1,n!=0 ?");
	__ASM("		ld		HL,0			; return NULL");
	__ASM("		ret");
	__ASM("__Cmp:	");
	__ASM("		ld		A,L			; *cS1");
	__ASM("		cp		A,E");
	__ASM("		jr		nz,__Calc		; *cS1-*cS2!=0 ?");
	__ASM("		ld		L,H			; *(cS1+1)");
	__ASM("		ld		E,D			; *(cS2+1)");
	__ASM("__Calc:	");
	__ASM("		ld		H,0");
	__ASM("		ld		D,0");
	__ASM("		sub		HL,DE			; *cS1-*cS2");
	__ASM("		;; ret");
	return (int)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
int __CDECL memcmp(const void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memcmp.s	1.1 95/12/01");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; int memcmp(const void *s1,const  void *s2, size_t n)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;;	");
	__ASM("		ld		BC,		(SP+0xa);	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		ld		IX,		(SP+0x7);	");
	__ASM("		test	C.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("		;						;	");
	__ASM("__ByteCmp:");
	__ASM("		ld		A,		(IX)	;	");
	__ASM("		xor		A,		(IY)	;	");
	__ASM("		j		f,		__Calc	;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		;						;	");
	__ASM("__Div2:");
	__ASM("		shrc	B				;	");
	__ASM("		rorc	C				;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordCmp:");
	__ASM("		ld		WA,		(IX)	;	");
	__ASM("		xor		WA,		(IY)	;	");
	__ASM("		j		f,		__Chk	;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__WordCmp;	");
	__ASM("		j		__End			;	");
	__ASM("		;						;	");
	__ASM("__Chk:");
	__ASM("		cmp		A,		0x0		;	");
	__ASM("		j		f,		__Calc	;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("__Calc:");
	__ASM("		sext	BC,		(IY)	;	");
	__ASM("		sext	WA,		(IX)	;	");
	__ASM("		sub		BC,		WA		;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		;						;ret");
	return (int)__BC;
}
#elif defined(__870X__)
int __CDECL memcmp(const void *s1, const void *s2, size_t n) {
	__ASM("		;; @(#)memcmp.s	1.6 95/10/26");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; int memcmp(const void *s1,const  void *s2, size_t n)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		SP+0x6");
	__ASM("		;; s2	:		SP+0x8");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;;");
	__ASM("		push	HL				;	");
	__ASM("		ld		BC,		(SP+0xa);	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("		ld		DE,		(SP+0x8);	");
	__ASM("		test	C.0				;	");
	__ASM("		j		t,		__Init	;	");
	__ASM("		;						;	");
	__ASM("__ByteComp:");
	__ASM("		ld		A,		(HL)	;	");
	__ASM("		xor		A,		(DE)	;	");
	__ASM("		j		f,		__Calc	;	");
	__ASM("		inc		DE				;	");
	__ASM("		inc		HL				;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		shrc	B				;	");
	__ASM("		rorc	C				;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordComp:");
	__ASM("		ld		WA,		(HL)	;	");
	__ASM("		xor		WA,		(DE)	;	");
	__ASM("		j		f,		__Chk	;	");
	__ASM("		inc		DE				;	");
	__ASM("		inc		DE				;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		HL				;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		nz,		__WordComp;	");
	__ASM("		j		__End			;	");
	__ASM("		;						;	");
	__ASM("__Chk:");
	__ASM("		cmp		A,		0x0		;	");
	__ASM("		j		f,		__Calc	;	");
	__ASM("		inc		DE				;	");
	__ASM("		inc		HL				;	");
	__ASM("__Calc:");
	__ASM("		sext	BC,		(HL)	;	");
	__ASM("		sext	WA,		(DE)	;	");
	__ASM("		sub		BC,		WA		;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		pop		HL				;	");
	__ASM("		;						;ret");
	return (int)__BC;
}
#endif

#if 0
/* Original Source Code */
int __CDECL memcmp(const void *s1, const void *s2, size_t n)
{
	int		diff;
const	unsigned char	*p1 = s1;
const	unsigned char	*p2 = s2;

	while (n--) {
		diff = (int)*p1 - (int)*p2;
		if (diff) {
			return (diff);
		}
		p1++;
		p2++;
	}
	return (0);
}
#endif
