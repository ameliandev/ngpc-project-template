/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _pow.c $	*/
/*	$Revision: 1.2.1.1 $	*/
/*	$Date: 1995/02/01 15:20:34 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>
#include <limits.h>

double __CDECL pow(double x, double y)
{
	unsigned short*	p;
	long	yy;
	double  ret, fl;
	int	bk_errno, expr, expr2, expr3;
	
	p = (unsigned short*)&x;
	if( y>=LONG_MIN && y<=LONG_MAX ) {
		yy = (long)y;
	}
	else {
		yy = -1L;
	}
	/*** check domain error ***/
	/*** When x is negative and y is not integral value. ***/
	if(x < 0.0 && y!=(double)yy) {
		errno = EDOM;
		return(1.0);
	}
	/*** check domain(range) error ***/
	/*** When x is zero and y is less than or equal to zero. ***/
	if(y <= 0.0 && x == 0.0) {
		errno=EDOM;
		return(1.0);
	}
	/*** y is integral value ***/
	if( y == (double)yy ) {
		if( yy < 0 ) {
			yy = -yy;
		}
		ret = 1.0;
		while( yy ) {
			frexp(x,&expr);
			if( (expr+expr) < DBL_MIN_EXP ) {
				if( y < 0.0 ) {
					errno = ERANGE;
					if( x < 0.0 ) {
						ret = -HUGE_VAL;
					}
					else {
						ret = HUGE_VAL;
					}
				}
				else {
					ret = 0.0;
				}
				return(ret);
			}
			else if( (expr+expr) > DBL_MAX_EXP ) {
				errno = ERANGE;
				if( x < 0.0 ) {
					ret = -HUGE_VAL;
				}
				else {
					ret = HUGE_VAL;
				}
				return(ret);
			}
			if( yy & 1 ) {
				ret *= x;
			}
			x *= x;
			yy >>= 1;
		}
		if( y >= 0.0 ) {
			return( ret );
		}
		return( 1/ret );
	}
	/*** y is not integral value ***/
	else {
		bk_errno = errno;	/* save errno */
		errno = 0;
		/* x is always bigger than or equal zero */
		fl  = log(x);
		if(errno==EDOM)	return(0.0); 
		errno = bk_errno;
		frexp(x,&expr);
		frexp(y,&expr2);
		if( expr<0 && expr2<0 ) {
			expr2 *= -1;
		}
		expr3 = expr+expr2;
		if( y<0.0 ) {
			expr3 *= -1;
		}
		if( expr3 > DBL_MAX_EXP ) {		/* overflow */
			errno = ERANGE;
			if( x < 0.0 ) {
				ret = -HUGE_VAL;
			}
			else {
				ret = HUGE_VAL;
			}
			return(ret);
		}
		else if( expr3 < DBL_MIN_EXP ) {	/* underflow */
			errno = ERANGE;
			return(0.0);
		}
		ret = exp(fl*y);
		return(ret);
	}
}
