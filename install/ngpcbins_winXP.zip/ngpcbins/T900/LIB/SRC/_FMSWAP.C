/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMSWAP.C $	*/
/*	$Revision: 1.2.1.3 $	*/
/*	$Date: 1996/02/27 14:36:28 $	*/

#include <string.h>

#if defined(__9000__)
void * __CDECL __fmemswap(void *s1, void *s2, unsigned long n)
{
	unsigned char c;
	void *s = s1;
	unsigned char *p1 = s1;
	unsigned char *p2 = s2;

	for( ; n--; ++p1, ++p2) {
		c   = *p1;
		*p1 = *p2;
		*p2 = c;
	}
	return (s);
}

#elif defined(__900__)
void * __fmemswap(void *s1, void *s2, unsigned long n) {
	__ASM("		;; @(#)fmemswap.s	1.3 95/07/25");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; Not ANSI (TOSHIBA original)");
	__ASM("		;; void * __fmemswap(void *s1, void *s2, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;; ");
	__ASM("		ld		XHL,(XSP+4)		; s1");
	__ASM("		ld		XBC,(XSP+12)		; n");
	__ASM("		and		XBC,0x00ffffff");
	__ASM("		ret		z			; don't swap");
	__ASM("		;;");
	__ASM("		ld		XDE,(XSP+8)		; s2");
	__ASM("		cp		XDE,XHL");
	__ASM("		ret		eq			; don't swap");
	__ASM("		;;");
	__ASM("		ld		IX,HL");
	__ASM("		neg		IX");
	__ASM("		and		IX,3			; 4m+0 ?");
	__ASM("		j		z,__LongSwap");
	__ASM("		;;");
	__ASM("__ByteSwap:");
	__ASM("		ld		A,(XHL)");
	__ASM("		ld		W,(XDE)");
	__ASM("		ld		(XDE+),A");
	__ASM("		ld		(XHL+),W");
	__ASM("		sub		XBC,1");
	__ASM("		j		z,__EndSwap");
	__ASM("		djnz	IX,__ByteSwap");
	__ASM("		;;");
	__ASM("__LongSwap:");
	__ASM("		ld		IX,BC");
	__ASM("		srl		2,XBC");
	__ASM("		jr		z,__ByteSwap2");
	__ASM("		ex		IX,QBC");
	__ASM("		inc		1,IX");
	__ASM("__Loop:");
	__ASM("		ld		XWA,(XHL)");
	__ASM("		ld		XIY,(XDE)");
	__ASM("		ld		(XDE+),XWA");
	__ASM("		ld		(XHL+),XIY");
	__ASM("		djnz	BC,__Loop");
	__ASM("		djnz	IX,__Loop");
	__ASM("		;;");
	__ASM("__ByteSwap2:");
	__ASM("		ld		IX,QBC");
	__ASM("		and		IX,3");
	__ASM("		j		z,__EndSwap");
	__ASM("__Loop2:");
	__ASM("		ld		A,(XHL)");
	__ASM("		ld		W,(XDE)");
	__ASM("		ld		(XDE+),A");
	__ASM("		ld		(XHL+),W");
	__ASM("		djnz	IX,__Loop2");
	__ASM("__EndSwap:		");
	__ASM("		ld		XHL,(XSP+4)");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void * __fmemswap(void *s1, void *s2, unsigned long n) {
	__ASM("		;; @(#)fmemswap.s	1.1 95/12/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; Not ANSI (TOSHIBA original)");
	__ASM("		;; void * __fmemswap(void *s1, void *s2, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;; ");
	__ASM("		ld		WA,		(SP+0xa);	");
	__ASM("		ld		BC,		(SP+0xc);	");
	__ASM("		cmp		BC,		0x10	;	");
	__ASM("		j		p,		__End	;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		f,		__Init	;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		ld		IX,		(SP+0x7);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("		;						;	");
	__ASM("__ByteSwap:");
	__ASM("		ld		L,		(IY)	;	");
	__ASM("		ld		H,		(IX)	;	");
	__ASM("		ld		(IX),	L		;	");
	__ASM("		ld		(IY),	H		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		;						;	");
	__ASM("__Div2:");
	__ASM("		shrc	B				;	");
	__ASM("		rorc	C				;	");
	__ASM("		rorc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		f,		__WordSwap;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordSwap:");
	__ASM("		ld		HL,		(IY)	;	");
	__ASM("		ld		DE,		(IX)	;	");
	__ASM("		ld		(IX),	HL		;	");
	__ASM("		ld		(IY),	DE		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordSwap;	");
	__ASM("		;						;	");
	__ASM("		ld		WA,		0xffff	;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		f,		__WordSwap;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#endif
