/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fputs.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:06:03 $	*/

#include <stdio.h>

int __CDECL fputs(const char *s, FILE *stream)
{
	while (*s)	(*stream->out)(*s++);
	return 0;
}
