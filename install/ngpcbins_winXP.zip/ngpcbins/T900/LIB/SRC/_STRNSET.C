/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strnset.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:12:53 $	*/

#include <string.h>

char * __CDECL strnset(char *s,int c,size_t n)
{
	char *s0 = s;

	while (n-- && *s)
		*s++ = (char)c;
	return (s0);
}
