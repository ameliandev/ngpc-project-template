/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _realloc.c $	*/
/*	$Revision: 1.2 $	*/
/*	$Date: 1995/07/24 15:26:58 $	*/

#include <stdlib.h>
#include <string.h>

struct	free_list {
	struct	free_list *free_addr ;
	unsigned	free_size ;
} ;

#define	FLSIZE	(sizeof(struct free_list))

void *__CDECL	realloc(void *cp,size_t rsize)
{
	struct	free_list	*rp, *np ;
	size_t	size ;

	if (rsize == 0)
		return (NULL) ;
	if (cp == NULL)
		return (malloc(rsize)) ;
	rp = cp ;
	rp-- ;
#ifndef __BYTE_ALIGN__
	size = (size_t)((rsize+1)/2)*2 ;
#else
	size = rsize ;
#endif
	if (rp->free_size > size) {
		if (rp->free_size > (size + FLSIZE + 4)) {
			np = (struct free_list * ) ((char *) rp + FLSIZE + size) ;
			np->free_size = rp->free_size - FLSIZE - size ;
			free(++np) ;
			rp->free_size = size ;
		}
		return (cp) ;
	}
	if ((np = malloc(size)) == NULL)
		return (NULL) ;
	memcpy(np, cp, size) ;
	free(cp) ;
	return (np) ;
}
