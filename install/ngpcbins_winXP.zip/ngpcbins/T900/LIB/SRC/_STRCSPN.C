/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strcspn.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:11:45 $	*/

#include <string.h>

size_t __CDECL strcspn(const char *s1, const char *s2)
{
	const char *s;
	size_t len;

	for (len = 0; *s1; ++s1, ++len)
		for (s = s2; *s; ++s)
			if (*s1 == *s)	goto bye;
bye:
	return (len);
}
