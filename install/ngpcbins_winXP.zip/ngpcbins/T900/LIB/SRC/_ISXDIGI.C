/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _isxdigi.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:03:54 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL isxdigit(int c)
{
	return ((c>='a' && c<='f') ||
		(c>='A' && c<='F') ||
		(c>='0' && c<='9'));
}
