/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strncmp.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:12:36 $	*/

#include <string.h>

int __CDECL strncmp(const char *s1, const char *s2, size_t n)
{
	while (n && *s1 == *s2) {
		if (!*s1)	return (0);
		++s1; ++s2; --n;
	}
	return ((n == 0)? 0 : (*s1 - *s2));
}
