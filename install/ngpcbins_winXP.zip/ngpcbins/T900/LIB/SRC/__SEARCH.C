/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: __search.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:07:23 $	*/

#include <stdlib.h>
#include <string.h>

void * __CDECL _lsearch(const void *key, void *base, size_t *nmemb, size_t size, int (*compar)(const void *, const void *), int flag)
{
        int    i;
	char	*p;

        for (i = *nmemb; i > 0; --i) {
                if (((*compar)(key, base)) == 0)	return (base);
		p = (char *)base;
                p += size;
		base = (void *)p;
        }
        if (flag) {
                (*nmemb)++;
                memmove(base, (void *)key, size);
        }
        else	base = NULL;
        return (base);
}
