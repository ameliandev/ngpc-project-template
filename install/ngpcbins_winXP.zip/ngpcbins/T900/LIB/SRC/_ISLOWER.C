/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _islower.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:03:17 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL islower(int c)
{
	return (c>='a' && c<='z');
}
