/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strtok.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/31 09:51:17 $	*/

#include <string.h>

char * __CDECL strtok(char *s1, const char *s2)
{
	static char *save;

	if (!s1) {
		s1 = save;				/* use old string */
		if (!s1)	return ((char *)NULL);
	}
	s1 += strspn(s1, s2);				/* find the first char of token */
	if (!*s1)	return ((char *)NULL);		/* return if no token remaining */
	save = strpbrk(s1,s2);				/* find end of token */
	if (save) {
		*save = 0;				/* terminate the token		*/
		++save;					/* start of next token		*/
	}
	return (s1);
}
