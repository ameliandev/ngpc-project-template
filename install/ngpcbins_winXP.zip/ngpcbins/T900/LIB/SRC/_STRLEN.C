/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _STRLEN.C $	*/
/*	$Revision: 1.3.1.2 $	*/
/*	$Date: 1996/02/27 14:43:44 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
size_t __CDECL strlen(const char *s)
{
const	char *s0 = s + 1;

	while (*s++) ;
	return (s - s0);
}
#elif defined(__900__)
size_t __CDECL strlen(const char *s) {
	register char	*ss;

	ss = memchr((const void *)s,0x00,0xffff);
	if(ss==NULL)
		return 0xffff;
	return (size_t)(ss - (char *)s);
}
#elif defined(__90__)
size_t __CDECL strlen(const char *s) {
	__ASM("		;; @(#)strlen.s	1.2 95/12/25");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; size_t __CDECL strlen(const char *s)");
	__ASM("		;; RET	:		size_t");
	__ASM("		;; s	:		SP+0x2");
	__ASM("		;; ");
	__ASM("		ld		BC,0xffff");
	__ASM("		push		BC");
	__ASM("		ld		BC,0");
	__ASM("		push		BC");
	__ASM("		ld		DE,(SP+0x6)		; s");
	__ASM("		push		DE			; s");
	__ASM("		cal		_memchr");
	__ASM("		lda		SP,SP+0x6");
	__ASM("		cp		HL,0");
	__ASM("		j		ne,__SLEN		; ss!=NULL ?");
	__ASM("		ld		HL,0xffff		; return");
	__ASM("		ret");
	__ASM("__SLEN:						; ss!=NULL");
	__ASM("		sub		HL,DE			; return");
	__ASM("		;; ret");
	return (size_t)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
size_t __CDECL strlen(const char *s) {
	__ASM("		;;	@(#)strlen.s 1.1 95/12/19");
	__ASM("		;;	(C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;;	");
	__ASM("		;;	size_t __CDECL strlen(const char *s)");
	__ASM("		;;	RET		:	size of s");
	__ASM("		;;	s		:	SP+0x4");
	__ASM("		;;	");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("__ChkNull:");
	__ASM("		ld		IY,		IX		;	");
	__ASM("		inc		IX				;	");
	__ASM("		cmp		(IY),	0x0		;	");
	__ASM("		j		f,		__ChkNull;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		sub		IY,		(SP+0x4);	");
	__ASM("		ld		BC,		IY		;	");
	__ASM("		;						;ret");
	return( (size_t)__BC );
}
#elif defined(__870X__)
size_t __CDECL strlen(const char *s) {
	__ASM("		;;	@(#)strlen.s 1.1 95/12/19");
	__ASM("		;;	(C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;;	");
	__ASM("		;;	size_t __CDECL strlen(const char *s)");
	__ASM("		;;	RET		:	size of s");
	__ASM("		;;	s		;	SP+0x6");
	__ASM("		;;	");
	__ASM("		push	HL				;	");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("		ld		WA,		HL		;	");
	__ASM("		inc		WA				;	");
	__ASM("		;						;	");
	__ASM("__ChkNull:");
	__ASM("		cmp		(HL+),	0x0		;	");
	__ASM("		j		f,		__ChkNull;	");
	__ASM("		sub		HL,		WA		;	");
	__ASM("		ld		BC,		HL		;	");
	__ASM("		pop		HL				;	");
	return( (size_t)__BC );
}
#endif
