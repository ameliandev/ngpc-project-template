/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _div.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:08:12 $	*/

#include <stdlib.h>

div_t __CDECL div(int numer, int denom)
{
	div_t dv;

	if(denom) {
		dv.quot = numer / denom;
		dv.rem = numer % denom;
	}
	return (dv);
}
