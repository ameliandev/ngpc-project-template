/*****************************************************************
**		TLCS-900 C Compiler				**
**--------------------------------------------------------------**
**	[For]		{TMP94C241}				**
**	[File name]	{IO900H2.C}				**
**	[Subject]	{Definitions of I/O & SFR}		**
**  Copyright(C) 1997 TOSHIBA CORPORATION All rights reserved	**
*****************************************************************/

/***[0x00]************************************************************/
unsigned char	__io(0x00)	P0; 	/* 0x00: Port0 */
unsigned char	__io(0x02)	P0CR;	/* 0x02: Port0 control */
unsigned char	__io(0x03)	P0FC;	/* 0x03: Port1 function */
unsigned char	__io(0x04)	P1;	/* 0x04: Port1 */
unsigned char	__io(0x06)	P1CR;	/* 0x06: Port1 control */
unsigned char	__io(0x07)	P1FC;	/* 0x07: Port1 function */
unsigned char	__io(0x08)	P2;	/* 0x08: Port2 */
unsigned char	__io(0x0a)	P2CR;	/* 0x0a: Port2 control */
unsigned char	__io(0x0b)	P2FC;	/* 0x0b: Port2 function */
unsigned char	__io(0x0c)	P3;	/* 0x0c: Port3 */
unsigned char	__io(0x0e)	P3CR;	/* 0x0e: Port3 control */
unsigned char	__io(0x0f)	P3FC;	/* 0x0f: Port3 function */

/***[0x10]*****************************************************************/
unsigned char	__io(0x10)	P4;	/* 0x10: Port4 */
unsigned char	__io(0x12)	P4CR;	/* 0x12: Port4 control */
unsigned char	__io(0x13)	P4FC;	/* 0x13: Port4 function */
unsigned char	__io(0x14)	P5;	/* 0x14: Port5 */
unsigned char	__io(0x16)	P5CR;	/* 0x16: Port5 control */
unsigned char	__io(0x17)	P5FC;	/* 0x17: Port5 function */
unsigned char	__io(0x18)	P6;	/* 0x18: Port6 */
unsigned char	__io(0x1a)	P6CR;	/* 0x1a: Port6 control */
unsigned char	__io(0x1b)	P6FC;	/* 0x1b: Port6 function */
unsigned char	__io(0x1c)	P7;	/* 0x1c: Port7 */
unsigned char	__io(0x1e)	P7CR;	/* 0x1e: Port7 control */
unsigned char	__io(0x1f)	P7FC;	/* 0x1f: Port7 function */

/***[0x20]*****************************************************************/
unsigned char	__io(0x20)	P8;	/* 0x20: Port8 */
unsigned char	__io(0x22)	P8CR;	/* 0x22: Port8 control */
unsigned char	__io(0x23)	P8FC;	/* 0x23: Port8 function */
unsigned char	__io(0x28)	PA;	/* 0x28: PortA */
unsigned char	__io(0x2b)	PAFC;	/* 0x2b: PortA function */
unsigned char	__io(0x2c)	PB;	/* 0x2c: PortB */
unsigned char	__io(0x2f)	PBFC;	/* 0x2f: PortB function */

/***[0x30]*****************************************************************/
unsigned char	__io(0x30)	PC;	/* 0x30: PortC */
unsigned char	__io(0x32)	PCCR;	/* 0x32: PortC control */
unsigned char	__io(0x33)	PCFC;	/* 0x33: PortC function */
unsigned char	__io(0x34)	PD;	/* 0x34: PortD */
unsigned char	__io(0x36)	PDCR;	/* 0x36: PortD control */
unsigned char	__io(0x37)	PDFC;	/* 0x37: PortD function */
unsigned char	__io(0x38)	PE;	/* 0x38: PortE */
unsigned char	__io(0x3a)	PECR;	/* 0x3a: PortE control */
unsigned char	__io(0x3b)	PEFC;	/* 0x3b: PortE function */
unsigned char	__io(0x3c)	PF;	/* 0x3c: PortF */
unsigned char	__io(0x3e)	PFCR;	/* 0x3e: PortF control */
unsigned char	__io(0x3f)	PFFC;	/* 0x3f: PortF function */
                                             
/***[0x40]*****************************************************************/
unsigned char	__io(0x40)	PG;	/* 0x40: PortG */
unsigned char	__io(0x44)	PH;	/* 0x44: PortH */
unsigned char	__io(0x46)	PHCR;	/* 0x46: PortH control */
unsigned char	__io(0x47)	PHFC;	/* 0x47: PortH function */

/***[0x60]*****************************************************************/
unsigned char	__io(0x68)	PZ;	/* 0x68: PortZ */
unsigned char	__io(0x6a)	PZCR;	/* 0x6a: PortZ control */
                   
/***[0x80]*****************************************************************/
unsigned char	__io(0x80)	T8RUN;	/* 0x80: 8bit Timer control */
unsigned char	__io(0x88)	TREG0;	/* 0x88: 8bit timer register 0 */
unsigned char	__io(0x89)	TREG1;	/* 0x89: 8bit timer register 1 */
unsigned char	__io(0x84)	T01MOD;	/* 0x84: Timer 0,1 mode control */
unsigned char	__io(0x82)	TFFCR;	/* 0x82: Timer F/F control */
unsigned char	__io(0x8a)	TREG2;	/* 0x8a: PWM0 timer register */
unsigned char	__io(0x8b)	TREG3;	/* 0x8b: PWM1 timer register */
unsigned char	__io(0x85)	T23MOD;	/* 0x85: Timer 2,3 mode control */
unsigned char	__io(0x81)	TRDC;	/* 0x81: Timer Double Buffer control */

/***[0x90]*****************************************************************/
unsigned char	__io(0x9e)	T16RUN;	/* 0x9e: 16bit Timer control */
unsigned char	__io(0x9f)	T16CR;	/* 0x9f: Timer 4,6,8,a mode control */
unsigned int	__io(0x90)	TREG4;	/* 0x90: 16bit timer register 4 */
/*unsigned char	__io(0x90)	TREG4L;	   0x90: 16bit timer register 4[low]  */
/*unsigned char	__io(0x91)	TREG4H;	   0x91: 16bit timer register 4[high] */
unsigned int	__io(0x92)	TREG5;	/* 0x92: 16bit timer register 5 */
/*unsigned char	__io(0x92)	TREG5L;	   0x92: 16bit timer register 5[low]  */
/*unsigned char	__io(0x93)	TREG5H;	   0x93: 16bit timer register 5[high] */
unsigned int	__io(0x94)	CAP4;	/* 0x94: Capture register 4 */
/*unsigned char	__io(0x94)	CAP4L;	   0x94: Capture register 4[low]  */
/*unsigned char	__io(0x95)	CAP4H;	   0x95: Capture register 4[high] */
unsigned int	__io(0x96)	CAP5;	/* 0x96: Capture register 5 */
/*unsigned char	__io(0x96)	CAP5L;	   0x96: Capture register 5[low]  */
/*unsigned char	__io(0x97)	CAP5H;	   0x97: Capture register 5[high] */
unsigned char	__io(0x98)	T4MOD;	/* 0x98: 16bit timer mode register 4 */
unsigned char	__io(0x99)	T4FFCR;	/* 0x99: 16bit timer4 F/F control */

/***[0xa0]*****************************************************************/
unsigned int	__io(0xa0)	TREG6;	/* 0xa0: 16bit timer register 6 */
/*unsigned char	__io(0xa0)	TREG6L;	   0xa0: 16bit timer register 6[low]  */
/*unsigned char	__io(0xa1)	TREG6H;	   0xa1: 16nit timer register 6[high] */
unsigned int	__io(0xa2)	TREG7;	/* 0xa2: 16bit timer register 7 */
/*unsigned char	__io(0xa2)	TREG7L;	   0xa2: 16bit timer register 7[low]  */
/*unsigned char	__io(0xa3)	TREG7H;	   0xa3: 16nit timer register 7[high] */
unsigned int	__io(0xa4)	CAP6;	/* 0xa4: Capture register 6 */
/*unsigned char	__io(0xa4)	CAP6L;	   0xa4: Capture register 6[low]  */
/*unsigned char	__io(0xa5)	CAP6H;	   0xa5: Capture register 6[high] */
unsigned int	__io(0xa6)	CAP7;	/* 0xa6: Capture register 7 */
/*unsigned char	__io(0xa6)	CAP7L;	   0xa6: Capture register 7[low]  */
/*unsigned char	__io(0xa7)	CAP7H;	   0xa7: Capture register 7[high] */
unsigned char	__io(0xa8)	T6MOD;	/* 0xa8: 16bit timer mode register 6 */
unsigned char	__io(0xa9)	T6FFCR;	/* 0xa9: 16bit timer6 F/F control */

/***[0xb0]****************************************************************/
unsigned int	__io(0xb0)	TREG8;	/* 0xb0: 16bit timer register 8 */
/*unsigned char	__io(0xb0)	TREG8L;	   0xb0: 16bit timer register 8[low]  */
/*unsigned char	__io(0xb1)	TREG8H;	   0xb1: 16bit timer register 8[high] */
unsigned int	__io(0xb2)	TREG9;	/* 0xb2: 16bit timer register 9 */
/*unsigned char	__io(0xb2)	TREG9L;	   0xb2: 16bit timer register 9[low]  */
/*unsigned char	__io(0xb3)	TREG9H;	   0xb3: 16bit timer register 9[high] */
unsigned int	__io(0xb4)	CAP8;	/* 0xb4: Capture register 8 */
/*unsigned char	__io(0xb4)	CAP8L;	   0xb4: Capture register 8[low]  */
/*unsigned char	__io(0xb5)	CAP8H;	   0xb5: Capture register 8[high] */
unsigned int	__io(0xb6)	CAP9;	/* 0xb6: Capture register 9 */
/*unsigned char	__io(0xb6)	CAP9L;	   0xb6: Capture register 9[low]  */
/*unsigned char	__io(0xb7)	CAP9H;	   0xb7: Capture register 9[high] */
unsigned char	__io(0xb8)	T8MOD;	/* 0xb8: 16bit timer mode register 8 */
unsigned char	__io(0xb9)	T8FFCR;	/* 0xb9: 16bit timer8 F/F control */

/***[0xc0]****************************************************************/
unsigned int	__io(0xc0)	TREGA;	/* 0xc0: 16bit timer register A */
/*unsigned char	__io(0xc0)	TREGAL;	   0xc0: 16bit timer register A[low]  */
/*unsigned char	__io(0xc1)	TREGAH;	   0xc1: 16bit timer register A[high] */
unsigned int	__io(0xc2)	TREGB;	/* 0xc2: 16bit timer register B */
/*unsigned char	__io(0xc2)	TREGBL;	   0xc2: 16bit timer register B[low]  */
/*unsigned char	__io(0xc3)	TREGBH;	   0xc3: 16bit timer register B[high] */
unsigned int	__io(0xc4)	CAPA;	/* 0xc4: Capture register A */
/*unsigned char	__io(0xc4)	CAPAL;	   0xc4: Capture register A[low]  */
/*unsigned char	__io(0xc5)	CAPAH;	   0xc5: Capture register A[high] */
unsigned int	__io(0xc6)	CAPB;	/* 0xc6: Capture register B */
/*unsigned char	__io(0xc6)	CAPBL;	   0xc6: Capture register B[low]  */
/*unsigned char	__io(0xc7)	CAPBH;	   0xc7: Capture register B[high] */
unsigned char	__io(0xc8)	TAMOD;	/* 0xc8: 16bit timer mode register A */
unsigned char	__io(0xc9)	TAFFCR;	/* 0xc9: 16bit timerA F/F control */

/***[0xd0]****************************************************************/
unsigned char	__io(0xd0)	SC0BUF;	/* 0xd0: Serial channel0 buffer*/
unsigned char	__io(0xd1)	SC0CR;	/* 0xd1: Serial channel0 control */
unsigned char	__io(0xd2)	SC0MOD;	/* 0xd2: Serial channel0 mode */
unsigned char	__io(0xd3)	BR0CR;	/* 0xd3: Serial channel0 baud rate */
unsigned char	__io(0xd4)	SC1BUF;	/* 0xd4: Serial channel1 buffer */
unsigned char	__io(0xd5)	SC1CR;	/* 0xd5: Serial channel1 control */
unsigned char	__io(0xd6)	SC1MOD;	/* 0xd6: Serial channel1 mode */
unsigned char	__io(0xd7)	BR1CR;	/* 0xd7: Serial channel1 baud rate */

/***[0xe0]****************************************************************/
unsigned char	__io(0xe0)	INTE45;		/* 0xe0: Interrupt enable 5/4 */
unsigned char	__io(0xe1)	INTE67;		/* 0xe1: Interrupt enable 7/6 */
unsigned char	__io(0xe2)	INTE89;		/* 0xe2: Interrupt enable 9/8 */
unsigned char	__io(0xe3)	INTEAB;		/* 0xe3: Interrupt enable B/A */
unsigned char	__io(0xe4)	INTET01; 	/* 0xe4: Interrupt enable timer 1/0 */
unsigned char	__io(0xe5)	INTET23; 	/* 0xe5: Interrupt enable timer 3/2 */
unsigned char	__io(0xe6)	INTET45; 	/* 0xe6: Interrupt enable timer 5/4 */
unsigned char	__io(0xe7)	INTET67; 	/* 0xe7: Interrupt enable timer 7/6 */
unsigned char	__io(0xe8)	INTET89; 	/* 0xe8: Interrupt enable timer 9/8 */
unsigned char	__io(0xe9)	INTETAB; 	/* 0xe9: Interrupt enable timer B/A */
unsigned char	__io(0xea)	INTES0;	 	/* 0xea: Interrupt enable serial 0 */
unsigned char	__io(0xeb)	INTES1;	 	/* 0xeb: Interrupt enable serial 1 */
unsigned char	__io(0xec)	INTETC01; 	/* 0xec: Interrupt enable TC 0/1 */
unsigned char	__io(0xed)	INTETC23; 	/* 0xed: Interrupt enable TC 2/3 */
unsigned char	__io(0xee)	INTETC45; 	/* 0xee: Interrupt enable TC 4/5 */
unsigned char	__io(0xef)	INTETC67; 	/* 0xef: Interrupt enable TC 6/7 */

/***[0xf0]****************************************************************/
unsigned char	__io(0xf0)	INTE0AD; 	/* 0xf0: Interrupt enable 0 & A/D */
unsigned char	__io(0xf6)	IIMC;	 	/* 0xf6: INT input mode control */
unsigned char	__io(0xf7)	INTNMWDT; 	/* 0xf7: NMI & INTWD Enable */
unsigned char	__io(0xf8)	INTCLR;	 	/* 0xf8: Interrupt clear control */

/***[0x100]****************************************************************/
unsigned char	__io(0x100)	DMA0V;		/* 0x100: DMA0 request vector */
unsigned char	__io(0x101)	DMA1V;		/* 0x101: DMA1 request vector */
unsigned char	__io(0x102)	DMA2V;		/* 0x102: DMA2 request vector */
unsigned char	__io(0x103)	DMA3V;		/* 0x103: DMA3 request vector */
unsigned char	__io(0x104)	DMA4V;		/* 0x104: DMA4 request vector */
unsigned char	__io(0x105)	DMA5V;		/* 0x105: DMA5 request vector */
unsigned char	__io(0x106)	DMA6V;		/* 0x106: DMA6 request vector */
unsigned char	__io(0x107)	DMA7V;		/* 0x107: DMA7 request vector */
unsigned char	__io(0x108)	DMAB;		/* 0x108: DMA burst */
unsigned char	__io(0x109)	DMAR;		/* 0x109: DMA request */
unsigned char	__io(0x10a)	CLKMOD;		/* 0x10a: Clock mode */

/***[0x110]****************************************************************/
unsigned char	__io(0x110)	WDMOD;		/* 0x110: Watch dog mode register */
unsigned char	__io(0x111)	WDCR;		/* 0x111: Watch dog control */

/***[0x120]****************************************************************/
unsigned char	__io(0x128)	ADMOD1;		/* 0x128: A/D converter mode register 1 */
unsigned char	__io(0x129)	ADMOD2;		/* 0x129: A/D converter mode register 2*/
unsigned int	__io(0x120)	ADREG04;	/* 0x120: A/D result register 0/4 */
/*unsigned char	__io(0x120)	ADREG04L;	   0x120: A/D result register 0/4[low] */
/*unsigned char	__io(0x121)	ADREG04H;  	   0x121: A/D result register 0/4[high] */
unsigned int	__io(0x122)	ADREG15;	/* 0x122: A/D result register 1/5 */
/*unsigned char	__io(0x122)	ADREG15L;  	   0x122: A/D result register 1/5[low] */
/*unsigned char	__io(0x123)	ADREG15H;  	   0x123: A/D result register 1/5[high] */
unsigned int	__io(0x124)	ADREG26;	/* 0x124: A/D result register 2/6 */
/*unsigned char	__io(0x124)	ADREG26L;	   0x124: A/D result register 2/6[low] */
/*unsigned char	__io(0x125)	ADREG26H;	   0x125: A/D result register 2/6[high] */
unsigned int	__io(0x126)	ADREG37;	/* 0x126: A/D result register 3/7 */
/*unsigned char	__io(0x126)	ADREG37L;	   0x126: A/D result register 3/7[low] */
/*unsigned char	__io(0x127)	ADREG37H;	   0x127: A/D result register 3/7[high] */

/***[0x130]**********************************************************/
unsigned char	__io(0x130)	DAREG0;		/* 0x130: D/A conversion register 0 */
unsigned char	__io(0x131)	DAREG1;		/* 0x131: D/A conversion register 1 */
unsigned char	__io(0x132)	DADRV;		/* 0x132: D/A drive register */

/***[0x140]*****************************************************************/
unsigned int	__io(0x140)	B0CS;	/* 0x140: Programable CS0 control */
/*unsigned char	__io(0x140)	B0CSL;	   0x140: Programable CS0 control[low]  */
/*unsigned char	__io(0x141)	B0CSH;	   0x141: Programable CS0 control[high] */
unsigned char	__io(0x142)	MAMR0;	/* 0x142: Memory start address mask register 0 */
unsigned char	__io(0x143)	MSAR0;	/* 0x143: Memory start address register 0 */
unsigned int	__io(0x144)	B1CS;	/* 0x144: Programable CS1 control */
/*unsigned char	__io(0x144)	B1CSL;	   0x144: Programable CS1 control[low]  */
/*unsigned char	__io(0x145)	B1CSH;	   0x145: Programable CS1 control[high] */
unsigned char	__io(0x146)	MAMR1;	/* 0x146: Memory start address mask register 1 */
unsigned char	__io(0x147)	MSAR1;	/* 0x147: Memory start address register 1 */
unsigned int	__io(0x148)	B2CS;	/* 0x148: Programable CS2 control */
/*unsigned char	__io(0x148)	B2CSL;	   0x148: Programable CS2 control[low]  */
/*unsigned char	__io(0x149)	B2CSH;	   0x149: Programable CS2 control[high] */
unsigned char	__io(0x14a)	MAMR2;	/* 0x14a: Memory start address mask register 2 */
unsigned char	__io(0x14b)	MSAR2;	/* 0x14b: Memory start address register 2 */
unsigned int	__io(0x14c)	B3CS;	/* 0x14c: Programable CS3 control */
/*unsigned char	__io(0x14c)	B3CSL;	   0x14c: Programable CS3 control[low]  */
/*unsigned char	__io(0x14d)	B3CSH;	   0x14d: Programable CS3 control[high] */
unsigned char	__io(0x14e)	MAMR3;	/* 0x14e: Memory start address mask register 3 */
unsigned char	__io(0x14f)	MSAR3;	/* 0x14f: Memory start address register 3 */

/***[0x150]************************************** **************************/
unsigned int	__io(0x150)	B4CS;	/* 0x150: Programable CS4 control */
/*unsigned char	__io(0x150)	B4CSL;	   0x150: Programable CS4 control[low]  */
/*unsigned char	__io(0x151)	B4CSH;	   0x151: Programable CS4 control[high] */
unsigned char	__io(0x152)	MAMR4;	/* 0x152: Memory start address mask register 4 */
unsigned char	__io(0x153)	MSAR4;	/* 0x153: Memory start address register 4 */
unsigned int	__io(0x154)	B5CS;	/* 0x154: Programable CS5 control */
/*unsigned char	__io(0x154)	B5CSL;	   0x154: Programable CS5 control[low]  */
/*unsigned char	__io(0x155)	B5CSH;	   0x155: Programable CS5 control[high] */
unsigned char	__io(0x156)	MAMR5;	/* 0x156: Memory start address mask register 5 */
unsigned char	__io(0x157)	MSAR5;	/* 0x157: Memory start address register 5 */

/***[0x160]*****************************************************************/
unsigned int	__io(0x160)	DRAM0CR;	/* 0x160: DRAM 0 control register */
/*unsigned char	__io(0x160)	DRAM0CRL;	   0x160: DRAM 0 control register[low] */
/*unsigned char	__io(0x161)	DRAM0CRH;	   0x161: DRAM 0 control register[high] */
unsigned int	__io(0x162)	DRAM1CR;	/* 0x162: DRAM 1 control register */
/*unsigned char	__io(0x162)	DRAM1CRL;	   0x162: DRAM 1 control register[low] */
/*unsigned char	__io(0x163)	DRAM1CRH;	   0x163: DRAM 1 control register[high] */
unsigned char	__io(0x164)	DRAM0REF;	/* 0x164: DRAM 0 refresh control */
unsigned char	__io(0x165)	DRAM1REF;	/* 0x165: DRAM 1 refresh control */
unsigned char	__io(0x166)	PMEMCR;		/* 0x166: Page ROM Control register */

/*=={EOF}==*/
