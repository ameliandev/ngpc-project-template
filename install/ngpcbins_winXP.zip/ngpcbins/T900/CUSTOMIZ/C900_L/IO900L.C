/*****************************************************************
**		TLCS-900 C Compiler Runtime library		**
**--------------------------------------------------------------**
**	[For]		{TMP93CM40F/TMP93CM41F}			**
**	[File name]	{IO900L.C}				**
**	[Subject]	{Definitions of I/O & SFR}		**
**	[Date]		{94/03/01}				**
**  Copyright(C) 1994-96 TOSHIBA CORPORATION All rights reserved**
*****************************************************************/

/***[0x00]*****************************************************************/
unsigned char	__io(0x00)	IOP0;		/* Port0 */
unsigned char	__io(0x01)	IOP1;		/* Port1 */
unsigned char	__io(0x02)	P0CR;		/* Port0 control */
/*---undefined------(0x03)---*/
unsigned char	__io(0x04)	P1CR;		/* Port1 control */
unsigned char	__io(0x05)	P1FC;		/* Port1 function */
unsigned char	__io(0x06)	IOP2;		/* Port2 */
unsigned char	__io(0x07)	IOP3;		/* Port3 */
unsigned char	__io(0x08)	P2CR;		/* Port2 control */
unsigned char	__io(0x09)	P2FC;		/* Port2 function */
unsigned char	__io(0x0a)	P3CR;		/* Port3 control */
unsigned char	__io(0x0b)	P3FC;		/* Port3 function */
unsigned char	__io(0x0c)	IOP4;		/* Port4 */
unsigned char	__io(0x0d)	IOP5;		/* Port5 */
unsigned char	__io(0x0e)	P4CR;		/* Port4 control */
/*---undefined------(0x0f)---*/

/***[0x10]*****************************************************************/
unsigned char	__io(0x10)	P4FC;		/* Port4 function */
/*---undefined------(0x11)---*/
unsigned char	__io(0x12)	IOP6;		/* Port6 */
unsigned char	__io(0x13)	IOP7;		/* Port7 */
unsigned char	__io(0x14)	P6CR;		/* Port6 control */
unsigned char	__io(0x15)	P7CR;		/* Port7 control */
unsigned char	__io(0x16)	P6FC;		/* Port6 function */
unsigned char	__io(0x17)	P7FC;		/* Port7 function */
unsigned char	__io(0x18)	IOP8;		/* Port8 */
unsigned char	__io(0x19)	IOP9;		/* Port9 */
unsigned char	__io(0x1a)	P8CR;		/* Port8 control */
unsigned char	__io(0x1b)	P9CR;		/* Port9 control */
unsigned char	__io(0x1c)	P8FC;		/* Port8 function */
unsigned char	__io(0x1d)	P9FC;		/* Port9 function */
unsigned char	__io(0x1e)	IOPA;		/* PortA */
unsigned char	__io(0x1f)	PACR;		/* PortA control */

/***[0x20]*****************************************************************/
unsigned char	__io(0x20)	TRUN;		/* Timer run */
/*---undefined------(0x21)---*/
unsigned char	__io(0x22)	TREG0;		/* 8bit timer register 0 */
unsigned char	__io(0x23)	TREG1;		/* 8bit timer register 1 */
unsigned char	__io(0x24)	TMOD;		/* Timer mode control */
unsigned char	__io(0x25)	TFFCR;		/* Timer F/F control */
unsigned char	__io(0x26)	TREG2;		/* PWM0 timer register */
unsigned char	__io(0x27)	TREG3;		/* PWM1 timer register */
unsigned char	__io(0x28)	P0MOD;		/* PWM0 mode control */
unsigned char	__io(0x29)	P1MOD;		/* PWM1 mode control */
unsigned char	__io(0x2a)	PFFCR;		/* PWM F/F control */
/*---undefined------(0x2b)---*/
/*---undefined------(0x2c)---*/
/*---undefined------(0x2d)---*/
/*---undefined------(0x2e)---*/
/*---undefined------(0x2f)---*/

/***[0x30]*****************************************************************/
unsigned int	__io(0x30)	TREG4;		/* 16bit timer register 4 */
/*unsigned char	__io(0x30)	TREG4L;			 16bit timer register 4[low] */
/*unsigned char	__io(0x31)	TREG4H;			 16nit timer register 4[high] */
unsigned int	__io(0x32)	TREG5;		/* 16bit timer register 5 */
/*unsigned char	__io(0x32)	TREG5L;			 16bit timer register 5[low] */
/*unsigned char	__io(0x33)	TREG5H;			 16bit timer register 5[high] */
unsigned int	__io(0x34)	CAP1;		/* Capture register 1 */
/*unsigned char	__io(0x34)	CAP1L;			 Capture register 1[low] */
/*unsigned char	__io(0x35)	CAP1H;			 Capture register 1[high] */
unsigned int	__io(0x36)	CAP2;		/* Capture register 2 */
/*unsigned char	__io(0x36)	CAP2L;			 Capture register 2[low] */
/*unsigned char	__io(0x37)	CAO2H;			 Capture register 2[high] */
unsigned char	__io(0x38)	T4MOD;		/* 16bit timer mode register 4 */
unsigned char	__io(0x39)	T4FFCR;		/* 16bit timer F/F4 control */
unsigned char	__io(0x3a)	T45CR;		/* 16bit timer control */
/*---undefined------(0x3b)---*/
/*---undefined------(0x3c)---*/
/*---undefined------(0x3d)---*/
/*---undefined------(0x3e)---*/
/*---undefined------(0x3f)---*/

/***[0x40]*****************************************************************/
unsigned int	__io(0x40)	TREG6;		/* 16bit timer register 6 */
/*unsigned char	__io(0x40)	TREG6L;			 16bit timer register 6[low] */
/*unsigned char	__io(0x41)	TREG6H;			 16bit timer register 6[high] */
unsigned int	__io(0x42)	TREG7;		/* 16bit timer register 7 */
/*unsigned char	__io(0x42)	TREG7L;			 16bit timer register 7[low] */
/*unsigned char	__io(0x43)	TREG7H;			 16bit timer register 7[high] */
unsigned int	__io(0x44)	CAP3;		/* Capture register 3 */
/*unsigned char	__io(0x44)	CAP3L;			 Capture register 3[low] */
/*unsigned char	__io(0x45)	CAP3H;			 Capture register 3[high] */
unsigned int	__io(0x46)	CAP4;		/* Capture register 4 */
/*unsigned char	__io(0x46)	CAP4L;			 Capture register 4[low] */
/*unsigned char	__io(0x47)	CAP4H;			 Capture register 4[high] */
unsigned char	__io(0x48)	T5MOD;		/* 16bit timer mode register 6 */
unsigned char	__io(0x49)	T5FFCR;		/* 16bit timer F/F6 control */
/*---undefined------(0x4a)---*/
/*---undefined------(0x4b)---*/
unsigned char	__io(0x4c)	PG0REG;		/* Pattern gen0 register */
unsigned char	__io(0x4d)	PG1REG;		/* Pattern gen1 register */
unsigned char	__io(0x4e)	PG01CR;		/* Pattern gen01 control */
/*---undefined------(0x4f)---*/

/***[0x50]*****************************************************************/
unsigned char	__io(0x50)	SC0BUF;		/* Serial channel0 buffer*/
unsigned char	__io(0x51)	SC0CR;		/* Serial channel0 control */
unsigned char	__io(0x52)	SC0MOD;		/* Serial channel0 mode */
unsigned char	__io(0x53)	BR0CR;		/* Serial channel0 baud rate */
unsigned char	__io(0x54)	SC1BUF;		/* Serial channel1 buffer */
unsigned char	__io(0x55)	SC1CR;		/* Serial channel1 control */
unsigned char	__io(0x56)	SC1MOD;		/* Serial channel1 mode */
unsigned char	__io(0x57)	BR1CR;		/* Serial channel1 baud rate */
unsigned char	__io(0x58)	ODE;		/* Serial out control */
/*---undefined------(0x59)---*/
/*---undefined------(0x5a)---*/
/*---undefined------(0x5b)---*/
unsigned char	__io(0x5c)	WDMOD;		/* Watch dog mode register */
unsigned char	__io(0x5d)	WDCR;		/* Watch dog control */
unsigned char	__io(0x5e)	ADMOD1;		/* A/D converter mode 1 */
unsigned char	__io(0x5f)	ADMOD2;		/* A/D converter mode 2 */

/***[0x60]*****************************************************************/
unsigned int	__io(0x60)	ADREG04;	/* A/D result register 0/4 */
/*unsigned char	__io(0x60)	ADREG04L;		 A/D result register 0/4[low] */
/*unsigned char	__io(0x61)	ADREG04H;		 A/D result register 0/4[high] */
unsigned int	__io(0x62)	ADREG15;	/* A/D result register 1/5 */
/*unsigned char	__io(0x62)	ADREG15L;		 A/D result register 1/5[low] */
/*unsigned char	__io(0x63)	ADREG15H;		 A/D result register 1/5[high] */
unsigned int	__io(0x64)	ADREG26;	/* A/D result register 2/6 */
/*unsigned char	__io(0x64)	ADREG26L;		 A/D result register 2/6[low] */
/*unsigned char	__io(0x65)	ADREG26H;		 A/D result register 2/6[high] */
unsigned int	__io(0x66)	ADREG37;	/* A/D result register 3/7 */
/*unsigned char	__io(0x66)	ADREG37L;		 A/D result register 3/7[low] */
/*unsigned char	__io(0x67)	ADREG37H;		 A/D result register 3/7[high] */
unsigned char	__io(0x68)	B0CS;		/* Programable CS0 control */
unsigned char	__io(0x69)	B1CS;		/* Programable CS1 control */
unsigned char	__io(0x6a)	B2CS;		/* Programable CS2 control */
/*---undefined------(0x6b)---*/
/*---undefined------(0x6c)---*/
unsigned char	__io(0x6d)	CKOCR;		/* Clock output control */
unsigned char	__io(0x6e)	SYSCR0;		/* System clock control 0 */
unsigned char	__io(0x6f)	SYSCR1;		/* System clock control 1 */

/***[0x70]*****************************************************************/
unsigned char	__io(0x70)	INTE0AD;	/* Interrupt enable 0 & A/D */
unsigned char	__io(0x71)	INTE45;		/* Interrupt enable 5/4 */
unsigned char	__io(0x72)	INTE67;		/* Interrupt enable 7/6 */
unsigned char	__io(0x73)	INTET10;	/* Interrupt enable timer 1/0 */
unsigned char	__io(0x74)	INTEPW10;	/* Interrupt enable PWM 1/0 */
unsigned char	__io(0x75)	INTET54;	/* Interrupt enable timer 5/4 */
unsigned char	__io(0x76)	INTET76;	/* Interrupt enable timer 7/6 */
unsigned char	__io(0x77)	INTES0;		/* Interrupt enable serial 0 */
unsigned char	__io(0x78)	INTES1;		/* Interrupt enable serial 1 */
/*---undefined------(0x79)---*/
/*---undefined------(0x7a)---*/
unsigned char	__io(0x7b)	IIMC;		/* INT input mode control */
unsigned char	__io(0x7c)	DMA0V;		/* DMA0 request vector */
unsigned char	__io(0x7d)	DMA1V;		/* DMA1 request vector */
unsigned char	__io(0x7e)	DMA2V;		/* DMA2 request vector */
unsigned char	__io(0x7f)	DMA3V;		/* DMA3 request vector */
/* eof */
