/************************************************************************
*		Standard startup program for TLCS-900			*
*		   {TMP96C141/TMP96CM40/TMP96PM40}			*
*			     Revision: 4.0 				*
*-----------------------------------------------------------------------*
*	Copyright(C) 1994-6 TOSHIBA CORPORATION All rights reserved	*
************************************************************************/

#include	<io900.h>
#include	<stdlib.h>

/*============================================
  [ User definition part ]
    This part is necessary.
  ============================================*/
#define	_Section_Attr	code		/* Section attribute of startup routine */
#define	_Section_Name	f_code		/* Section name of startup routine */
#define	_SecInt_Attr	code		/* Section attribute of interrupt table */
#define	_SecInt_Name	inttbl		/* Section name of interrupt table */
#define	_BaseXSP	0x000800	/* Stack area bottom address */
#define	_BaseIntTbl	0x008000	/* Interrupt table base address */

#define	HeapTop		(void*)0x4000	/* Heap area top address */
#define	HeapSize	0x4000		/* Heap area size */


/*============================================
  [ Dummy section definition ]
    This part is necessary.
  ============================================*/
#pragma	section	data	f_area
#pragma	section	data	f_data


/*============================================
  [ Define external variable & function ]
    This part is necessary.
  ============================================*/
extern	long	_DataRAM;		/* for f_data initialize */

void	main(void);			/* Prototype of main function */


/*============================================
  [ Define Heap area ]
    If use malloc, calloc or realloc function,
    this part is necessary.
  ============================================*/
void*	SBRK_break = HeapTop;		/* Set Heap area top address */
int	SBRK_size = HeapSize;		/* Set Heap area size */

void*	_allocb=((void *)0);		/* memory management pointer */


/*============================================
  [ Define error No. ]
    If use mathematics function,
    this part is necessary.
  ============================================*/
int	errno;				/* error code */


/*============================================
  [ Standard library function: exit() ]
    This part must be rewrite.
  ============================================*/
void	exit(int status){
	__asm("	halt");	
}


/*============================================
  [ Standard library function: abort() ]
    This part must be rewrite.
  ============================================*/
void	abort(void){
	__asm("	;j	__startup");
}


/*============================================
  [ Startup ]
    This part is necessary.
  ============================================*/
#pragma	section	_Section_Attr	_Section_Name

void	_startup(void){

	__DI();				/* [NECESSARY] Disable interrupt */

/* These three lines are must be rewrite. */
	B2CS	= 0x8c;			/* 0 wait */
	WDMOD	= 0x00;			/* [for RTE] WDT disable */
	WDCR	= 0xb1;

	__XSP	= _BaseXSP;		/* [NECESSARY] setup XSP */

	__asm("	ld	xde,startof(f_area)");	/* Initialize f_area section */
	__asm("	ld	xbc,sizeof(f_area)");
	__asm("	ld	ix,bc");
	__asm("	srl	1,xbc");
	__asm("	j	z,FA2");
	__asm("	ld	xhl,xde");
	__asm("	ldw	(xde+),0");
	__asm("	sub	xbc,1");
	__asm("	j	z,FA2");
	__asm("	ldirw	(xde+),(xhl+)");
	__asm("	cp	qbc,0");
	__asm("	j	eq,FA2");
	__asm("	ld	wa,qbc");
	__asm("FA3:");
	__asm("	ldirw	(xde+),(xhl+)");
	__asm("	djnz	wa,FA3");
	__asm("FA2:");
	__asm("	bit	0,ix");
	__asm("	j	z,FA1");
	__asm("	ldb	(xde),0");
	__asm("FA1:");

	__asm("	ld	xde,__DataRAM");	/* Initialize f_data section */
	__asm("	ld	xhl,startof(f_data)");	
	__asm("	ld	xbc,sizeof(f_data)");	
	__asm("	or	xbc,xbc");		
	__asm("	j	z,FD1");		
	__asm("	ldirb	(XDE+),(XHL+)");	
	__asm("	cp	qbc,0");		
	__asm("	j	eq,FD1");		
	__asm("	ld	wa,qbc");		
	__asm("FD2:");				
	__asm("	ldirb	(xde+),(xhl+)");	
	__asm("	djnz	wa,FD2");		
	__asm("FD1:");			

	__EI();				/* [NECESSARY] Enable interrupt */

	main();				/* call or jump to main function */

	__asm("	halt");			/* Hook for abnormal end */
}


/*============================================
  [ Interrupt table ]
    This part must be rewrite.
  ============================================*/
#pragma	section _SecInt_Attr	INTER0	0x8000
void __regbank(-1)	_INT_RESET(void){	/* Reset/SWI0 */
	/*  Write your codes here */
	__asm("	max");
	__asm("	j	__startup");
}

#pragma section _SecInt_Attr	INTER1	0x8010
void __regbank(-1)	_INT_PRIV(void){	/* Privileged instruction/SWI1 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER2	0x8020
void __regbank(-1)	_INT_UNDEF(void){	/* Undefined instruction/SWI2 */	__asm("__INT_SWI2:");
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER3	0x8030
void __regbank(-1)	_INT_SWI3(void){	/* SWI3 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER4	0x8040
void __regbank(-1)	_INT_SWI4(void){	/* SWI4 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER5	0x8050
void __regbank(-1)	_INT_SWI5(void){	/* SWI5 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER6	0x8060
void __regbank(-1)	_INT_SWI6(void){	/* SWI6 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER7	0x8070
void __regbank(-1)	_INT_SWI7(void){	/* SWI7 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER8	0x8080
void __regbank(-1)	_INT_NMI(void){		/* NMI */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER9	0x8090
void __regbank(-1)	_INT_INTWD(void){	/* Watch Dog Timer */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER10	0x80a0
void __regbank(-1)	_INT_INT0(void){	/* INT0 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER11	0x80b0
void __regbank(-1)	_INT_INT4(void){	/* INT4 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER12	0x80c0
void __regbank(-1)	_INT_INT5(void){	/* INT5 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER13	0x80d0
void __regbank(-1)	_INT_INT6(void){	/* INT6 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER14	0x80e0
void __regbank(-1)	_INT_INT7(void){	/* INT7 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER15	0x80f0
void __regbank(-1)	_INT_RESERVED1(void){	/* Reserved1 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER16	0x8100
void __regbank(-1)	_INT_INTT0(void){	/* INTT0 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER17	0x8110
void __regbank(-1)	_INT_INTT1(void){	/* INTT1 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER18	0x8120
void __regbank(-1)	_INT_INTPW0(void){	/* INTPW0 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER19	0x8130
void __regbank(-1)	_INT_INTPW1(void){	/* INTPW1 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER20	0x8140
void __regbank(-1)	_INT_INTT4(void){	/* INTT4 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER21	0x8150
void __regbank(-1)	_INT_INTT5(void){	/* INTT5 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER22	0x8160
void __regbank(-1)	_INT_INTT6(void){	/* INTT6 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER23	0x8170
void __regbank(-1)	_INT_INTT7(void){	/* INTT7 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER24	0x8180
void __regbank(-1)	_INT_INTRX0(void){	/* INTRX0 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER25	0x8190
void __regbank(-1)	_INT_INTTX0(void){	/* INTTX0 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER26	0x81a0
void __regbank(-1)	_INT_INTRX1(void){	/* INTRX1 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER27	0x81b0
void __regbank(-1)	_INT_INTTX1(void){	/* INTTX1 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER28	0x81c0
void __regbank(-1)	_INT_INTAD(void){	/* INTAD */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER29	0x81d0
void __regbank(-1)	_INT_RESERVED2(void){	/* Reserved2 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER30	0x81e0
void __regbank(-1)	_INT_RESERVED3(void){	/* Reserved3 */
	/*  Write your codes here */
}

#pragma section _SecInt_Attr	INTER31	0x81f0
void __regbank(-1)	_INT_RESERVED4(void){	/* Reserved4 */
	/*  Write your codes here */
}
/* EOF */
