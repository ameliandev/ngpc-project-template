#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef	unsigned char u_char;


void usage(void)
{
	fprintf(stderr,"8 bit mono wav file converter\n");
	fprintf(stderr,"usage:\n");
	fprintf(stderr,"wav2c.exe [FILE] [OutTag]\n");
	return;
}



int main(int argc, char *argv[])
{
	u_char *bufptr;
	FILE *fp;
	int size;
	int i;
	char *tname,*infname,nbuff[256];
	
	if(argc != 3){
		fprintf(stderr,"invalid usage\n");
		usage();
		return 1;
	}
	
	infname = *++argv;
	tname = *++argv;
	
	if( (fp = fopen( infname,"rb" )) == NULL ){
		fprintf( stderr,"file open fail:%s\n",infname );
		return 1;
	}
	
	
	//WAV�f�[�^���o�b�t�@�ɓǂݍ���
	fseek(fp,0,SEEK_END);
	size = ftell(fp) -44;
	fseek(fp,44,SEEK_SET);
	bufptr = (u_char *)malloc(size);
	fread( bufptr, size, 1, fp );
	fclose(fp);
	
	
	if( (fp = fopen( strcat(strcpy(nbuff,tname),".snd"),"w" )) == NULL ){
		fprintf( stderr,"file open fail:%s\n",nbuff );
		free(bufptr);
		return 1;
	}
	
	fprintf(fp,"static unsigned char %s[] = {",tname);
	for(i=0;i<size;i++){
		if((i % 16) == 0) fputc('\n',fp);
		fprintf(fp,"%3d,",bufptr[i]);
	}
	fputs("\n};\n",fp);
	
	fclose(fp);
	free(bufptr); //�f�[�^�o�b�t�@�J��
	
	return 0;
}

//End of text
