hicolor now works on both emu & real ngpc with the same compilation.
just call hc_detect() before showing pictures.
