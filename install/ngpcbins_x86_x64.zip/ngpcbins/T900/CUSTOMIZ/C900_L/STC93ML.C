/************************************************************************
*		Standard startup program for TLCS-900H			*
*			{TMP93CM40F/TMP93CM41F}				*
*			     Revision: 4.0 				*
*-----------------------------------------------------------------------*
*	Copyright(C) 1994,5 TOSHIBA CORPORATION All rights reserved	*
************************************************************************/

#include	<io900l.h>
#include	<stdlib.h>

/*============================================
  [ User definition part ]
    This part is necessary.
  ============================================*/
#define	_Section_Attr	code		/* Section attribute of startup routine */
#define	_Section_Name	f_code		/* Section name of startup routine */
#define	_SecInt_Attr	const		/* Section attribute of interrupt table */
#define	_SecInt_Name	inttbl		/* Section name of interrupt table */
#define	_BaseXSP	0x000880	/* Stack area bottom address */
#define	_BaseIntTbl	0x008000	/* Interrupt table base address */

#define	HeapTop		(void*)0x4000	/* Heap area top address */
#define	HeapSize	0x4000		/* Heap area size */


/*============================================
  [ Dummy section definition ]
    This part is necessary.
  ============================================*/
#pragma	section	data	f_area
#pragma	section	data	f_data


/*============================================
  [ Define external variable & function ]
    This part is necessary.
  ============================================*/
extern	long	_DataRAM;		/* for f_data initialize */

void	main(void);			/* Prototype of main function */


/*============================================
  [ Define Heap area ]
    If use malloc, calloc or realloc function,
    this part is necessary.
  ============================================*/
void*	SBRK_break = HeapTop;		/* Set Heap area top address */
int	SBRK_size = HeapSize;		/* Set Heap area size */

void*	_allocb=((void *)0);		/* memory management pointer */


/*============================================
  [ Define error No. ]
    If use mathematics function,
    this part is necessary.
  ============================================*/
int	errno;				/* error code */


/*============================================
  [ Standard library function: exit() ]
    This part must be rewrite.
  ============================================*/
void	exit(int status){
	__asm("	halt");	
}


/*============================================
  [ Standard library function: abort() ]
    This part must be rewrite.
  ============================================*/
void	abort(void){
	__asm("	;j	__startup");
}


/*============================================
  [ Startup ]
    This part is necessary.
  ============================================*/
#pragma	section	_Section_Attr	_Section_Name

void	_startup(void){

	__DI();				/* [NECESSARY] Disable interrupt */

/* These three lines are must be rewrite. */
	B2CS	= 0x8c;			/* 0 wait */
	WDMOD	= 0x00;			/* [for RTE] WDT disable */
	WDCR	= 0xb1;

	__XSP	= _BaseXSP;		/* [NECESSARY] setup XSP */

	__asm("	ld	xde,startof(f_area)");	/* Initialize f_area section */
	__asm("	ld	xbc,sizeof(f_area)");
	__asm("	ld	ix,bc");
	__asm("	srl	1,xbc");
	__asm("	j	z,FA2");
	__asm("	ld	xhl,xde");
	__asm("	ldw	(xde+),0");
	__asm("	sub	xbc,1");
	__asm("	j	z,FA2");
	__asm("	ldirw	(xde+),(xhl+)");
	__asm("	cp	qbc,0");
	__asm("	j	eq,FA2");
	__asm("	ld	wa,qbc");
	__asm("FA3:");
	__asm("	ldirw	(xde+),(xhl+)");
	__asm("	djnz	wa,FA3");
	__asm("FA2:");
	__asm("	bit	0,ix");
	__asm("	j	z,FA1");
	__asm("	ldb	(xde),0");
	__asm("FA1:");

	__asm("	ld	xde,__DataRAM");	/* Initialize f_data section */
	__asm("	ld	xhl,startof(f_data)");	
	__asm("	ld	xbc,sizeof(f_data)");	
	__asm("	or	xbc,xbc");		
	__asm("	j	z,FD1");		
	__asm("	ldirb	(XDE+),(XHL+)");	
	__asm("	cp	qbc,0");		
	__asm("	j	eq,FD1");		
	__asm("	ld	wa,qbc");		
	__asm("FD2:");				
	__asm("	ldirb	(xde+),(xhl+)");	
	__asm("	djnz	wa,FD2");		
	__asm("FD1:");			

	__EI();				/* [NECESSARY] Enable interrupt */

	main();				/* call or jump to main function */

	__asm("	halt");			/* Hook for abnormal end */
}


/*============================================
  [ Dummy function for interrupt: _Int_dummy() ]
    This part must be rewrite.
  ============================================*/
void __regbank(-1)	_Int_dummy(void){
}


/*============================================
  [ Interrupt table ]
    This part must be rewrite.
  ============================================*/
#pragma	section _SecInt_Attr	_SecInt_Name	_BaseIntTbl
void	* const _IntTbl[] = {
		 _startup		/* Reset/SWI 0    */
		,_Int_dummy		/* SWI 1          */
		,_Int_dummy		/* INTUNDEF/SWI 2 */
		,_Int_dummy		/* SWI 3          */
		,_Int_dummy		/* SWI 4          */
		,_Int_dummy		/* SWI 5          */
		,_Int_dummy		/* SWI 6          */
		,_Int_dummy		/* SWI 7          */
		,_Int_dummy		/* NMI            */
		,_Int_dummy		/* INTWD          */
		,_Int_dummy		/* INT0           */
		,_Int_dummy		/* INT4           */
		,_Int_dummy		/* INT5           */
		,_Int_dummy		/* INT6           */
		,_Int_dummy		/* INT7           */
		,_Int_dummy		/* Reserved1      */
		,_Int_dummy		/* INTT0          */
		,_Int_dummy		/* INTT1          */
		,_Int_dummy		/* INTT2          */
		,_Int_dummy		/* INTT3          */
		,_Int_dummy		/* INTTR4         */
		,_Int_dummy		/* INTTR5         */
		,_Int_dummy		/* INTTR6         */
		,_Int_dummy		/* INTTR7         */
		,_Int_dummy		/* INTRX0         */
		,_Int_dummy		/* INTTX0         */
		,_Int_dummy		/* INTRX1         */
		,_Int_dummy		/* INTTX1         */
		,_Int_dummy		/* INTAD          */
	};
