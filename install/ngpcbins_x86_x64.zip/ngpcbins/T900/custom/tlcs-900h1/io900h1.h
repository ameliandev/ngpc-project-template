/*****************************************************************
;*         Sample SFR Header File for TLCS-900/H1 Series         *
;*                      MCU : TMP92FD23AFG                       *
;*---------------------------------------------------------------*
;*  (C)Copyright TOSHIBA CORPORATION 2009  All rights reserved   *
;*****************************************************************/

#ifdef IO_MEM
/* This definition is for I/O variable and extern definition */
/* So please do not use the name "IO_MEM".*/
#define EXTERN
#else
#define EXTERN extern
#endif

/***[0x00]************************************************************/
EXTERN unsigned char    __io(0x00)  P0;         /* 0x00: Port0 */
/*---   (0x01)  Reserved    ---*/
EXTERN unsigned char    __io(0x02)  P0CR;       /* 0x02: Port0 control */
EXTERN unsigned char    __io(0x03)  P0FC;       /* 0x03: Port1 function */
EXTERN unsigned char    __io(0x04)  P1;         /* 0x04: Port1 */
/*---   (0x05)  Reserved    ---*/
EXTERN unsigned char    __io(0x06)  P1CR;       /* 0x06: Port1 control */
EXTERN unsigned char    __io(0x07)  P1FC;       /* 0x07: Port1 function */
/*---   (0x08)  Reserved    ---*/
/*---   (0x09)  Reserved    ---*/
/*---   (0x0a)  Reserved    ---*/
/*---   (0x0b)  Reserved    ---*/
/*---   (0x0c)  Reserved    ---*/
/*---   (0x0d)  Reserved    ---*/
/*---   (0x0e)  Reserved    ---*/
/*---   (0x0f)  Reserved    ---*/

/***[0x10]*****************************************************************/
EXTERN unsigned char    __io(0x10)  P4;         /* 0x10: Port4 */
/*---   (0x11)  Reserved    ---*/
EXTERN unsigned char    __io(0x12)  P4CR;       /* 0x12: Port4 control */
EXTERN unsigned char    __io(0x13)  P4FC;       /* 0x13: Port4 function */
EXTERN unsigned char    __io(0x14)  P5;         /* 0x14: Port5 */
/*---   (0x15)  Reserved    ---*/
EXTERN unsigned char    __io(0x16)  P5CR;       /* 0x16: Port5 control */
EXTERN unsigned char    __io(0x17)  P5FC;       /* 0x17: Port5 function */
EXTERN unsigned char    __io(0x18)  P6;         /* 0x18: Port6 */
/*---   (0x19)  Reserved    ---*/
EXTERN unsigned char    __io(0x1a)  P6CR;       /* 0x1a: Port6 control */
EXTERN unsigned char    __io(0x1b)  P6FC;       /* 0x1b: Port6 function */
EXTERN unsigned char    __io(0x1c)  P7;         /* 0x1c: Port7 */
/*---   (0x1d)  Reserved    ---*/
EXTERN unsigned char    __io(0x1e)  P7CR;       /* 0x1e: Port7 control */
EXTERN unsigned char    __io(0x1f)  P7FC;       /* 0x1f: Port7 function */

/***[0x20]*****************************************************************/
EXTERN unsigned char    __io(0x20)  P8;         /* 0x20: Port8 */
EXTERN unsigned char    __io(0x21)  P8FC2;      /* 0x21: Port8 function 2 */
EXTERN unsigned char    __io(0x22)  P8CR;       /* 0x22: Port8 control */
EXTERN unsigned char    __io(0x23)  P8FC;       /* 0x23: Port8 function */
/*---   (0x24)  Reserved    ---*/
/*---   (0x25)  Reserved    ---*/
/*---   (0x26)  Reserved    ---*/
/*---   (0x27)  Reserved    ---*/
/*---   (0x28)  Reserved    ---*/
/*---   (0x29)  Reserved    ---*/
/*---   (0x2a)  Reserved    ---*/
/*---   (0x2b)  Reserved    ---*/
/*---   (0x2c)  Reserved    ---*/
/*---   (0x2d)  Reserved    ---*/
/*---   (0x2e)  Reserved    ---*/
/*---   (0x2f)  Reserved    ---*/

/***[0x30]*****************************************************************/
EXTERN unsigned char    __io(0x30)  PC;         /* 0x30: PortC */
/*---   (0x31)  Reserved    ---*/
/*---   (0x32)  Reserved    ---*/
EXTERN unsigned char    __io(0x33)  PCFC;       /* 0x33: PortC function */
EXTERN unsigned char    __io(0x34)  PD;         /* 0x34: PortD */
EXTERN unsigned char    __io(0x35)  PDFC2;      /* 0x35: PortD function 2 */
EXTERN unsigned char    __io(0x36)  PDCR;       /* 0x36: PortD control */
EXTERN unsigned char    __io(0x37)  PDFC;       /* 0x37: PortD function */
/*---   (0x38)  Reserved    ---*/
/*---   (0x39)  Reserved    ---*/
/*---   (0x3a)  Reserved    ---*/
/*---   (0x3b)  Reserved    ---*/
EXTERN unsigned char    __io(0x3c)  PF;         /* 0x3c: PortF */
EXTERN unsigned char    __io(0x3d)  PFFC2;      /* 0x3d: PortF function 2 */
EXTERN unsigned char    __io(0x3e)  PFCR;       /* 0x3e: PortF control */
EXTERN unsigned char    __io(0x3f)  PFFC;       /* 0x3f: PortF function */

/***[0x40]*****************************************************************/
EXTERN unsigned char    __io(0x40)  PG;         /* 0x40: PortG */
/*---   (0x41)  Reserved    ---*/
/*---   (0x42)  Reserved    ---*/
EXTERN unsigned char    __io(0x43)  PGFC;       /* 0x43: PortG function */
/*---   (0x44)  Reserved    ---*/
/*---   (0x45)  Reserved    ---*/
/*---   (0x46)  Reserved    ---*/
/*---   (0x47)  Reserved    ---*/
/*---   (0x48)  Reserved    ---*/
/*---   (0x49)  Reserved    ---*/
/*---   (0x4a)  Reserved    ---*/
/*---   (0x4b)  Reserved    ---*/
/*---   (0x4c)  Reserved    ---*/
/*---   (0x4d)  Reserved    ---*/
/*---   (0x4e)  Reserved    ---*/
/*---   (0x4f)  Reserved    ---*/

/***[0x50]*****************************************************************/
/*---   (0x50)  Reserved    ---*/
/*---   (0x51)  Reserved    ---*/
/*---   (0x52)  Reserved    ---*/
/*---   (0x53)  Reserved    ---*/
EXTERN unsigned char    __io(0x54)  PL;         /* 0x54: PortL */
/*---   (0x55)  Reserved    ---*/
/*---   (0x56)  Reserved    ---*/
EXTERN unsigned char    __io(0x57)  PLFC;       /* 0x57: PortL function */
/*---   (0x58)  Reserved    ---*/
/*---   (0x59)  Reserved    ---*/
/*---   (0x5a)  Reserved    ---*/
/*---   (0x5b)  Reserved    ---*/
EXTERN unsigned char    __io(0x5C)  PN;         /* 0x5C: PortN */
/*---   (0x5d)  Reserved    ---*/
EXTERN unsigned char    __io(0x5e)  PNCR;       /* 0x5E: PortN control */
EXTERN unsigned char    __io(0x5f)  PNFC;       /* 0x5F: PortN function */

/***[0xd0]*****************************************************************/
EXTERN unsigned char    __io(0xd0)  INTE01;     /* 0xd0: INT0 & INT1 enable */
EXTERN unsigned char    __io(0xd1)  INTE23;     /* 0xd1: INT2 & INT3 enable */
EXTERN unsigned char    __io(0xd2)  INTE45;     /* 0xd2: INT4 & INT5 enable */
EXTERN unsigned char    __io(0xd3)  INTE67;     /* 0xd3: INT6 & INT7 enable */
EXTERN unsigned char    __io(0xd4)  INTETA01;   /* 0xd4: INTTA0 & INTTA1 enable */
EXTERN unsigned char    __io(0xd5)  INTETA23;   /* 0xd5: INTTA2 & INTTA3 enable */
EXTERN unsigned char    __io(0xd6)  INTETA45;   /* 0xd6: INTTA4 & INTTA5 enable */
/*---   (0xd7)  Reserved    ---*/
EXTERN unsigned char    __io(0xd8)  INTES0;     /* 0xd8: INTRX0 & INTTX0 enable */
EXTERN unsigned char    __io(0xd9)  INTES1HSC;  /* 0xd9: INTRX1 & INTTX1 / INTHSC enable */
EXTERN unsigned char    __io(0xda)  INTES2;     /* 0xda: INTRX2 & INTTX2 enable */
/*---   (0xdb)  Reserved    ---*/
EXTERN unsigned char    __io(0xdc)  INTESB0;    /* 0xdc: INTSBE0 enable */
EXTERN unsigned char    __io(0xdd)  INTESB1;    /* 0xdd: INTSBE1 enable */
/*---   (0xde)  Reserved    ---*/
/*---   (0xdf)  Reserved    ---*/

/***[0xe0]*****************************************************************/
EXTERN unsigned char    __io(0xe0)  INTETB0;    /* 0xe0: INTTB00 & INTTB01 enable */
EXTERN unsigned char    __io(0xe1)  INTETBO0;   /* 0xe1: INTTBO0 enable */
EXTERN unsigned char    __io(0xe2)  INTETB1;    /* 0xe2: INTTB10 & INTTB11 enable */
EXTERN unsigned char    __io(0xe3)  INTETBO1;   /* 0xe3: INTTBO1 enable */
EXTERN unsigned char    __io(0xe4)  INTEPAD;    /* 0xe4: INTP0 & INTAD enable */
EXTERN unsigned char    __io(0xe5)  INTERTC;    /* 0xe5: INTRTC enable */
/*---   (0xe6)  Reserved    ---*/
/*---   (0xe7)  Reserved    ---*/
/*---   (0xe8)  Reserved    ---*/
/*---   (0xe9)  Reserved    ---*/
/*---   (0xea)  Reserved    ---*/
/*---   (0xeb)  Reserved    ---*/
/*---   (0xec)  Reserved    ---*/
/*---   (0xed)  Reserved    ---*/
/*---   (0xee)  Reserved    ---*/
EXTERN unsigned char    __io(0xef)  INTNMWDT;   /* 0xef: NMI & INTWD enable */

/***[0xf0]*****************************************************************/
EXTERN unsigned char    __io(0xf0)  INTETC01;   /* 0xf0: INTTC0 & INTTC1 enable */
EXTERN unsigned char    __io(0xf1)  INTETC23;   /* 0xf1: INTTC2 & INTTC3 enable */
EXTERN unsigned char    __io(0xf2)  INTETC45;   /* 0xf2: INTTC4 & INTTC5 enable */
EXTERN unsigned char    __io(0xf3)  INTETC67;   /* 0xf3: INTTC6 & INTTC7 enable */
EXTERN unsigned char    __io(0xf4)  HSCSEL;     /* 0xf4: HSC selection */
EXTERN unsigned char    __io(0xf5)  SIMC;       /* 0xf5: SIO INT control */
EXTERN unsigned char    __io(0xf6)  IIMC;       /* 0xf6: INT input mode control */
/*---   (0xf7)  Reserved    ---*/
EXTERN unsigned char    __io(0xf8)  INTCLR;     /* 0xf8: INT clear control */
/*---   (0xf9)  Reserved    ---*/
EXTERN unsigned char    __io(0xfa)  IIMC2;      /* 0xfa: INT input mode control 2 */
EXTERN unsigned char    __io(0xfb)  IIMC3;      /* 0xfb: INT input mode control 3 */
/*---   (0xfc)  Reserved    ---*/
/*---   (0xfd)  Reserved    ---*/
/*---   (0xfe)  Reserved    ---*/
/*---   (0xff)  Reserved    ---*/

/***[0x100]****************************************************************/
EXTERN unsigned char    __io(0x100) DMA0V;      /* 0x100: DMA0 request vector */
EXTERN unsigned char    __io(0x101) DMA1V;      /* 0x101: DMA1 request vector */
EXTERN unsigned char    __io(0x102) DMA2V;      /* 0x102: DMA2 request vector */
EXTERN unsigned char    __io(0x103) DMA3V;      /* 0x103: DMA3 request vector */
EXTERN unsigned char    __io(0x104) DMA4V;      /* 0x104: DMA4 request vector */
EXTERN unsigned char    __io(0x105) DMA5V;      /* 0x105: DMA5 request vector */
EXTERN unsigned char    __io(0x106) DMA6V;      /* 0x106: DMA6 request vector */
EXTERN unsigned char    __io(0x107) DMA7V;      /* 0x107: DMA7 request vector */
EXTERN unsigned char    __io(0x108) DMAB;       /* 0x108: DMA burst request */
EXTERN unsigned char    __io(0x109) DMAR;       /* 0x109: DMA software request */
/*---   (0x10a)   Reserved  ---*/
/*---   (0x10b)   Reserved  ---*/
/*---   (0x10c)   Reserved  ---*/
/*---   (0x10d)   Reserved  ---*/
/*---   (0x10e)   Reserved  ---*/
/*---   (0x10f)   Reserved  ---*/

/***[0x140]****************************************************************/
EXTERN unsigned char    __io(0x140) B0CSL;      /* 0x140: Block 0 MEMC control L */
EXTERN unsigned char    __io(0x141) B0CSH;      /* 0x141: Block 0 MEMC control H */
EXTERN unsigned char    __io(0x142) MAMR0;      /* 0x142: Memory Mask 0 */
EXTERN unsigned char    __io(0x143) MSAR0;      /* 0x143: Memory Start Address 0 */
EXTERN unsigned char    __io(0x144) B1CSL;      /* 0x144: Block 1 MEMC control L */
EXTERN unsigned char    __io(0x145) B1CSH;      /* 0x145: Block 1 MEMC control H */
EXTERN unsigned char    __io(0x146) MAMR1;      /* 0x146: Memory Mask 1 */
EXTERN unsigned char    __io(0x147) MSAR1;      /* 0x147: Memory Start Address 1 */
EXTERN unsigned char    __io(0x148) B2CSL;      /* 0x148: Block 2 MEMC control L */
EXTERN unsigned char    __io(0x149) B2CSH;      /* 0x149: Block 2 MEMC control H */
EXTERN unsigned char    __io(0x14a) MAMR2;      /* 0x14a: Memory Mask 2 */
EXTERN unsigned char    __io(0x14b) MSAR2;      /* 0x14b: Memory Start Address 2 */
EXTERN unsigned char    __io(0x14c) B3CSL;      /* 0x14c: Block 3 MEMC control L */
EXTERN unsigned char    __io(0x14d) B3CSH;      /* 0x14d: Block 3 MEMC control H */
EXTERN unsigned char    __io(0x14e) MAMR3;      /* 0x14e: Memory Mask 3 */
EXTERN unsigned char    __io(0x14f) MSAR3;      /* 0x14f: Memory Start Address 3 */

/***[0x150]****************************************************************/
/*---   (0x150)   Reserved  ---*/
/*---   (0x151)   Reserved  ---*/
/*---   (0x152)   Reserved  ---*/
/*---   (0x153)   Reserved  ---*/
/*---   (0x154)   Reserved  ---*/
/*---   (0x155)   Reserved  ---*/
/*---   (0x156)   Reserved  ---*/
/*---   (0x157)   Reserved  ---*/
EXTERN unsigned char    __io(0x158) BEXCSL;     /* 0x158: Block EX MEMC control L */
EXTERN unsigned char    __io(0x159) BEXCSH;     /* 0x159: Block EX MEMC control H */
/*---   (0x15a)   Reserved  ---*/
/*---   (0x15b)   Reserved  ---*/
/*---   (0x15c)   Reserved  ---*/
/*---   (0x15d)   Reserved  ---*/
/*---   (0x15e)   Reserved  ---*/
/*---   (0x15f)   Reserved  ---*/

/***[0x160]****************************************************************/
/*---   (0x160)   Reserved  ---*/
/*---   (0x161)   Reserved  ---*/
/*---   (0x162)   Reserved  ---*/
/*---   (0x163)   Reserved  ---*/
/*---   (0x164)   Reserved  ---*/
/*---   (0x165)   Reserved  ---*/
EXTERN unsigned char    __io(0x166) PMEMCR;     /* 0x166: Page ROM control */
/*---   (0x167)   Reserved  ---*/
/*---   (0x168)   Reserved  ---*/
/*---   (0x169)   Reserved  ---*/
/*---   (0x16a)   Reserved  ---*/
/*---   (0x16b)   Reserved  ---*/
/*---   (0x16c)   Reserved  ---*/
/*---   (0x16d)   Reserved  ---*/
/*---   (0x16e)   Reserved  ---*/
/*---   (0x16f)   Reserved  ---*/

/***[0x10e0]***************************************************************/
EXTERN unsigned char    __io(0x10e0)    SYSCR0; /* 0x10e0: System Clock control 0 */
EXTERN unsigned char    __io(0x10e1)    SYSCR1; /* 0x10e1: System Clock control 1 */
EXTERN unsigned char    __io(0x10e2)    SYSCR2; /* 0x10e2: System Clock control 2 */
EXTERN unsigned char    __io(0x10e3)    EMCCR0; /* 0x10e3: EMC control 0 */
EXTERN unsigned char    __io(0x10e4)    EMCCR1; /* 0x10e4: EMC control 1 */
EXTERN unsigned char    __io(0x10e5)    EMCCR2; /* 0x10e5: EMC control 2 */
/*---   (0x10e6)  Reserved  ---*/
/*---   (0x10e7)  Reserved  ---*/
EXTERN unsigned char    __io(0x10e8)    PLLCR0; /* 0x10e8: PLL control 0 */
EXTERN unsigned char    __io(0x10e9)    PLLCR1; /* 0x10e9: PLL control 1 */
/*---   (0x10ea)  Reserved  ---*/
/*---   (0x10eb)  Reserved  ---*/
/*---   (0x10ec)  Reserved  ---*/
/*---   (0x10ed)  Reserved  ---*/
/*---   (0x10ee)  Reserved  ---*/
/*---   (0x10ef)  Reserved  ---*/

/***[0x1100]***************************************************************/
EXTERN unsigned char __io(0x1100)   TA01RUN;    /* 0x1100: 8 bit timer RUN */
/*---   (0x1101)  Reserved  ---*/
EXTERN unsigned char __io(0x1102)   TA0REG;     /* 0x1102: 8 bit timer 0 */
EXTERN unsigned char __io(0x1103)   TA1REG;     /* 0x1103: 8 bit timer 1 */
EXTERN unsigned char __io(0x1104)   TA01MOD;    /* 0x1104: 8 bit timer source CLK & mode */
EXTERN unsigned char __io(0x1105)   TA1FFCR;    /* 0x1105: 8 bit timer flip-flop control */
/*---   (0x1106)  Reserved  ---*/
/*---   (0x1107)  Reserved  ---*/
EXTERN unsigned char __io(0x1108)   TA23RUN;    /* 0x1108: 8 bit timer RUN */
/*---   (0x1109)  Reserved  ---*/
EXTERN unsigned char __io(0x110a)   TA2REG;     /* 0x110a: 8 bit timer 2 */
EXTERN unsigned char __io(0x110b)   TA3REG;     /* 0x110b: 8 bit timer 3 */
EXTERN unsigned char __io(0x110c)   TA23MOD;    /* 0x110c: 8 bit timer source CLK & mode */
EXTERN unsigned char __io(0x110d)   TA3FFCR;    /* 0x110d: 8 bit timer flip-flop control */
/*---   (0x110e)  Reserved  ---*/
/*---   (0x110f)  Reserved  ---*/

/***[0x1110]***************************************************************/
EXTERN unsigned char __io(0x1110)   TA45RUN;    /* 0x1110: 8 bit timer RUN */
/*---   (0x1111)  Reserved  ---*/
EXTERN unsigned char __io(0x1112)   TA4REG;     /* 0x1112: 8 bit timer 4 */
EXTERN unsigned char __io(0x1113)   TA5REG;     /* 0x1113: 8 bit timer 5 */
EXTERN unsigned char __io(0x1114)   TA45MOD;    /* 0x1114: 8 bit timer source CLK & mode */
EXTERN unsigned char __io(0x1115)   TA5FFCR;    /* 0x1115: 8 bit timer flip-flop control */
/*---   (0x1116)  Reserved  ---*/
/*---   (0x1117)  Reserved  ---*/
/*---   (0x1118)  Reserved  ---*/
/*---   (0x1119)  Reserved  ---*/
/*---   (0x111a)  Reserved  ---*/
/*---   (0x111b)  Reserved  ---*/
/*---   (0x111c)  Reserved  ---*/
/*---   (0x111d)  Reserved  ---*/
/*---   (0x111e)  Reserved  ---*/
/*---   (0x111f)  Reserved  ---*/

/***[0x1180]***************************************************************/
EXTERN unsigned char __io(0x1180)   TB0RUN;     /* 0x1180: 16 bit timer RUN */
/*---   (0x1181)  Reserved  ---*/
EXTERN unsigned char __io(0x1182)   TB0MOD;     /* 0x1182: 16 bit timer source CLK & mode */
EXTERN unsigned char __io(0x1183)   TB0FFCR;    /* 0x1183: 16 bit timer flip-flop control */
/*---   (0x1184)  Reserved  ---*/
/*---   (0x1185)  Reserved  ---*/
/*---   (0x1186)  Reserved  ---*/
/*---   (0x1187)  Reserved  ---*/
EXTERN unsigned char __io(0x1188)   TB0RG0L;    /* 0x1188: 16 bit timer 0 L */
EXTERN unsigned char __io(0x1189)   TB0RG0H;    /* 0x1189: 16 bit timer 0 H */
EXTERN unsigned char __io(0x118a)   TB0RG1L;    /* 0x118a: 16 bit timer 1 L */
EXTERN unsigned char __io(0x118b)   TB0RG1H;    /* 0x118b: 16 bit timer 1 H */
EXTERN unsigned char __io(0x118c)   TB0CP0L;    /* 0x118c: 16 bit timer capture 0 L */
EXTERN unsigned char __io(0x118d)   TB0CP0H;    /* 0x118d: 16 bit timer capture 0 H */
EXTERN unsigned char __io(0x118e)   TB0CP1L;    /* 0x118e: 16 bit timer capture 1 L */
EXTERN unsigned char __io(0x118f)   TB0CP1H;    /* 0x118f: 16 bit timer capture 1 H */

/***[0x1190]***************************************************************/
EXTERN unsigned char __io(0x1190)   TB1RUN;     /* 0x1190: 16 bit timer RUN */
/*---   (0x1191)  Reserved  ---*/
EXTERN unsigned char __io(0x1192)   TB1MOD;     /* 0x1192: 16 bit timer source CLK & mode */
EXTERN unsigned char __io(0x1193)   TB1FFCR;    /* 0x1193: 16 bit timer flip-flop control */
/*---   (0x1194)  Reserved  ---*/
/*---   (0x1195)  Reserved  ---*/
/*---   (0x1196)  Reserved  ---*/
/*---   (0x1197)  Reserved  ---*/
EXTERN unsigned char __io(0x1198)   TB1RG0L;    /* 0x1198: 16 bit timer 0 L */
EXTERN unsigned char __io(0x1199)   TB1RG0H;    /* 0x1199: 16 bit timer 0 H */
EXTERN unsigned char __io(0x119a)   TB1RG1L;    /* 0x119a: 16 bit timer 1 L */
EXTERN unsigned char __io(0x119b)   TB1RG1H;    /* 0x119b: 16 bit timer 1 H */
EXTERN unsigned char __io(0x119c)   TB1CP0L;    /* 0x119c: 16 bit timer capture 0 L */
EXTERN unsigned char __io(0x119d)   TB1CP0H;    /* 0x119d: 16 bit timer capture 0 H */
EXTERN unsigned char __io(0x119e)   TB1CP1L;    /* 0x119e: 16 bit timer capture 1 L */
EXTERN unsigned char __io(0x119f)   TB1CP1H;    /* 0x119f: 16 bit timer capture 1 H */

/***[0xc00]***************************************************************/
EXTERN unsigned short __io(0xc00)   HSC0MD;     /* 0xc00: High Speed Serial mode */
EXTERN unsigned short __io(0xc02)   HSC0CT;     /* 0xc02: High Speed Serial control */
EXTERN unsigned short __io(0xc04)   HSC0ST;     /* 0xc04: High Speed Serial status */
EXTERN unsigned short __io(0xc06)   HSC0CR;     /* 0xc06: High Speed Serial CRC */
EXTERN unsigned short __io(0xc08)   HSC0IS;     /* 0xc08: High Speed Serial INT */
EXTERN unsigned short __io(0xc0a)   HSC0WE;     /* 0xc0a: High Speed Serial INT status write enable */
EXTERN unsigned short __io(0xc0c)   HSC0IE;     /* 0xc0c: High Speed Serial INT enable */
EXTERN unsigned short __io(0xc0e)   HSC0IR;     /* 0xc0e: High Speed Serial INT request */

/***[0xc10]***************************************************************/
EXTERN unsigned char __io(0xc10)    HSC0TD;     /* 0xc10: High Speed Serial transmission data */
EXTERN unsigned char __io(0xc12)    HSC0RD;     /* 0xc12: High Speed Serial receive data */
EXTERN unsigned char __io(0xc14)    HSC0TS;     /* 0xc14: High Speed Serial transmit data shift */
EXTERN unsigned char __io(0xc16)    HSC0RS;     /* 0xc16: High Speed Serial receive data shift */
/*---   (0xc18)  Reserved   ---*/
/*---   (0xc19)  Reserved   ---*/
/*---   (0xc1a)  Reserved   ---*/
/*---   (0xc1b)  Reserved   ---*/
/*---   (0xc1c)  Reserved   ---*/
/*---   (0xc1d)  Reserved   ---*/
/*---   (0xc1e)  Reserved   ---*/
/*---   (0xc1f)  Reserved   ---*/

/***[0x1200]***************************************************************/
EXTERN unsigned char __io(0x1200)   SC0BUF;     /* 0x1200: Serial CH 0 buffer */
EXTERN unsigned char __io(0x1201)   SC0CR;      /* 0x1201: Serial CH 0 control */
EXTERN unsigned char __io(0x1202)   SC0MOD0;    /* 0x1202: Serial CH 0 mode 0 */
EXTERN unsigned char __io(0x1203)   BR0CR;      /* 0x1203: Serial CH 0 baud rate control */
EXTERN unsigned char __io(0x1204)   BR0ADD;     /* 0x1204: Serial CH 0 K setting */
EXTERN unsigned char __io(0x1205)   SC0MOD1;    /* 0x1205: Serial CH 0 mode 1 */
/*---   (0x1206)  Reserved  ---*/
EXTERN unsigned char __io(0x1207)   SIR0CR;     /* 0x1207: IrDA control 0 */
EXTERN unsigned char __io(0x1208)   SC1BUF;     /* 0x1208: Serial CH 1 buffer */
EXTERN unsigned char __io(0x1209)   SC1CR;      /* 0x1209: Serial CH 1 control */
EXTERN unsigned char __io(0x120a)   SC1MOD0;    /* 0x120a: Serial CH 1 mode 0 */
EXTERN unsigned char __io(0x120b)   BR1CR;      /* 0x120b: Serial CH 1 baud rate control */
EXTERN unsigned char __io(0x120c)   BR1ADD;     /* 0x120c: Serial CH 1 K setting */
EXTERN unsigned char __io(0x120d)   SC1MOD1;    /* 0x120d: Serial CH 1 mode 1 */
/*---   (0x120e)  Reserved  ---*/
EXTERN unsigned char __io(0x120f)   SIR1CR;     /* 0x120f: IrDA control 1 */

/***[0x1210]***************************************************************/
EXTERN unsigned char __io(0x1210)   SC2BUF;     /* 0x1210: Serial CH 2 buffer */
EXTERN unsigned char __io(0x1211)   SC2CR;      /* 0x1211: Serial CH 2 control */
EXTERN unsigned char __io(0x1212)   SC2MOD0;    /* 0x1212: Serial CH 2 mode 0 */
EXTERN unsigned char __io(0x1213)   BR2CR;      /* 0x1213: Serial CH 2 baud rate control */
EXTERN unsigned char __io(0x1214)   BR2ADD;     /* 0x1214: Serial CH 2 K setting */
EXTERN unsigned char __io(0x1215)   SC2MOD1;    /* 0x1215: Serial CH 2 mode 1 */
/*---   (0x1216)  Reserved  ---*/
EXTERN unsigned char __io(0x1217)   SIR2CR;     /* 0x1217: IrDA control 2 */
/*---   (0x1218)  Reserved  ---*/
/*---   (0x1219)  Reserved  ---*/
/*---   (0x121a)  Reserved  ---*/
/*---   (0x121b)  Reserved  ---*/
/*---   (0x121c)  Reserved  ---*/
/*---   (0x121d)  Reserved  ---*/
/*---   (0x121e)  Reserved  ---*/
/*---   (0x121f)  Reserved  ---*/

/***[0x1240]***************************************************************/
EXTERN unsigned char __io(0x1240)   SBI0CR1;    /* 0x1240: Serial bus interface 0 control 1 */
EXTERN unsigned char __io(0x1241)   SBI0DBR;    /* 0x1241: SBI buffer */
EXTERN unsigned char __io(0x1242)   I2C0AR;     /* 0x1242: I2CBUS 0 address */
EXTERN unsigned char __io(0x1243)   SBI0CR2;    /* 0x1243: Serial bus interface 0 status */
EXTERN unsigned char __io(0x1244)   SBI0BR0;    /* 0x1244: Serial bus interface 0 baud rate 0 */
EXTERN unsigned char __io(0x1245)   SBI0BR1;    /* 0x1245: Serial bus interface 0 baud rate 1 */
/*---   (0x1246)  Reserved  ---*/
/*---   (0x1247)  Reserved  ---*/
EXTERN unsigned char __io(0x1248)   SBI1CR1;    /* 0x1248: Serial bus interface 1 control 1 */
EXTERN unsigned char __io(0x1249)   SBI1DBR;    /* 0x1249: SBI 1 buffer */
EXTERN unsigned char __io(0x124a)   I2C1AR;     /* 0x124a: I2CBUS 1 address */
EXTERN unsigned char __io(0x124b)   SBI1CR2;    /* 0x124b: Serial bus interface 1 status */
EXTERN unsigned char __io(0x124c)   SBI1BR0;    /* 0x124c: Serial bus interface 1 baud rate 0 */
EXTERN unsigned char __io(0x124d)   SBI1BR1;    /* 0x124d: Serial bus interface 1 baud rate 1 */
/*---   (0x124e)  Reserved  ---*/
/*---   (0x124f)  Reserved  ---*/

/***[0x12a0]***************************************************************/
EXTERN unsigned char __io(0x12a0)   ADREG0L;    /* 0x12a0: AD result 0 L */
EXTERN unsigned char __io(0x12a1)   ADREG0H;    /* 0x12a1: AD result 0 H */
EXTERN unsigned char __io(0x12a2)   ADREG1L;    /* 0x12a2: AD result 1 L */
EXTERN unsigned char __io(0x12a3)   ADREG1H;    /* 0x12a3: AD result 1 H */
EXTERN unsigned char __io(0x12a4)   ADREG2L;    /* 0x12a4: AD result 2 L */
EXTERN unsigned char __io(0x12a5)   ADREG2H;    /* 0x12a5: AD result 2 H */
EXTERN unsigned char __io(0x12a6)   ADREG3L;    /* 0x12a6: AD result 3 L */
EXTERN unsigned char __io(0x12a7)   ADREG3H;    /* 0x12a7: AD result 3 H */
EXTERN unsigned char __io(0x12a8)   ADREG4L;    /* 0x12a8: AD result 4 L */
EXTERN unsigned char __io(0x12a9)   ADREG4H;    /* 0x12a9: AD result 4 H */
EXTERN unsigned char __io(0x12aa)   ADREG5L;    /* 0x12aa: AD result 5 L */
EXTERN unsigned char __io(0x12ab)   ADREG5H;    /* 0x12ab: AD result 5 H */
EXTERN unsigned char __io(0x12ac)   ADREG6L;    /* 0x12ac: AD result 6 L */
EXTERN unsigned char __io(0x12ad)   ADREG6H;    /* 0x12ad: AD result 6 H */
EXTERN unsigned char __io(0x12ae)   ADREG7L;    /* 0x12ae: AD result 7 L */
EXTERN unsigned char __io(0x12af)   ADREG7H;    /* 0x12af: AD result 7 H */

/***[0x12b0]***************************************************************/
EXTERN unsigned char __io(0x12b0)   ADREG8L;    /* 0x12b0: AD result 8 L */
EXTERN unsigned char __io(0x12b1)   ADREG8H;    /* 0x12b1: AD result 8 H */
EXTERN unsigned char __io(0x12b2)   ADREG9L;    /* 0x12b2: AD result 9 L */
EXTERN unsigned char __io(0x12b3)   ADREG9H;    /* 0x12b3: AD result 9 H */
EXTERN unsigned char __io(0x12b4)   ADREGAL;    /* 0x12b4: AD result A L */
EXTERN unsigned char __io(0x12b5)   ADREGAH;    /* 0x12b5: AD result A H */
EXTERN unsigned char __io(0x12b6)   ADREGBL;    /* 0x12b6: AD result B L */
EXTERN unsigned char __io(0x12b7)   ADREGBH;    /* 0x12b7: AD result B H */
EXTERN unsigned char __io(0x12b8)   ADMOD0;     /* 0x12b8: AD mode control 0 */
EXTERN unsigned char __io(0x12b9)   ADMOD1;     /* 0x12b9: AD mode control 1 */
EXTERN unsigned char __io(0x12ba)   ADMOD2;     /* 0x12ba: AD mode control 2 */
/*---   (0x12bb)  Reserved  ---*/
/*---   (0x12bc)  Reserved  ---*/
/*---   (0x12bd)  Reserved  ---*/
/*---   (0x12be)  Reserved  ---*/
/*---   (0x12bf)  Reserved  ---*/

/***[0x1300]***************************************************************/
EXTERN unsigned char __io(0x1300)   WDMOD;      /* 0x1300: WDT mode */
EXTERN unsigned char __io(0x1301)   WDCR;       /* 0x1301: WDT control */
/*---   (0x1302)  Reserved  ---*/
/*---   (0x1303)  Reserved  ---*/
/*---   (0x1304)  Reserved  ---*/
/*---   (0x1305)  Reserved  ---*/
/*---   (0x1306)  Reserved  ---*/
/*---   (0x1307)  Reserved  ---*/
/*---   (0x1308)  Reserved  ---*/
/*---   (0x1309)  Reserved  ---*/
/*---   (0x130a)  Reserved  ---*/
/*---   (0x130b)  Reserved  ---*/
/*---   (0x130c)  Reserved  ---*/
/*---   (0x130d)  Reserved  ---*/
/*---   (0x130e)  Reserved  ---*/
/*---   (0x130f)  Reserved  ---*/

/***[0x1310]***************************************************************/
EXTERN unsigned char __io(0x1310)   RTCCR;      /* 0x1310: RTC control */
/*---   (0x1311)  Reserved  ---*/
/*---   (0x1312)  Reserved  ---*/
/*---   (0x1313)  Reserved  ---*/
/*---   (0x1314)  Reserved  ---*/
/*---   (0x1315)  Reserved  ---*/
/*---   (0x1316)  Reserved  ---*/
/*---   (0x1317)  Reserved  ---*/
/*---   (0x1318)  Reserved  ---*/
/*---   (0x1319)  Reserved  ---*/
/*---   (0x131a)  Reserved  ---*/
/*---   (0x131b)  Reserved  ---*/
/*---   (0x131c)  Reserved  ---*/
/*---   (0x131d)  Reserved  ---*/
/*---   (0x131e)  Reserved  ---*/
/*---   (0x131f)  Reserved  ---*/

/***[0x13A0]***************************************************************/
EXTERN unsigned char __io(0x13a0)   KIEN;       /* 0x13a0: KEY input enable setting */
EXTERN unsigned char __io(0x13a1)   KICR;       /* 0x13a1: KEY input control */
/*---   (0x13a2)  Reserved  ---*/
/*---   (0x13a3)  Reserved  ---*/
/*---   (0x13a4)  Reserved  ---*/
/*---   (0x13a5)  Reserved  ---*/
/*---   (0x13a6)  Reserved  ---*/
/*---   (0x13a7)  Reserved  ---*/
/*---   (0x13a8)  Reserved  ---*/
/*---   (0x13a9)  Reserved  ---*/
/*---   (0x13aa)  Reserved  ---*/
/*---   (0x13ab)  Reserved  ---*/
/*---   (0x13ac)  Reserved  ---*/
/*---   (0x13ad)  Reserved  ---*/
/*---   (0x13ae)  Reserved  ---*/
/*---   (0x13af)  Reserved  ---*/

/***[0x1400]***************************************************************/
EXTERN unsigned char __io(0x1400)   ROMCMP00;   /* 0x1400: Address Compare 00 */
EXTERN unsigned char __io(0x1401)   ROMCMP01;   /* 0x1401: Address Compare 01 */
EXTERN unsigned char __io(0x1402)   ROMCMP02;   /* 0x1402: Address Compare 02 */
/*---   (0x1403)  Reserved  ---*/
EXTERN unsigned char __io(0x1404)   ROMSUB0LL;  /* 0x1404: Address Substitution 0LL */
EXTERN unsigned char __io(0x1405)   ROMSUB0LH;  /* 0x1405: Address Substitution 0LH */
EXTERN unsigned char __io(0x1406)   ROMSUB0HL;  /* 0x1406: Address Substitution 0HL */
EXTERN unsigned char __io(0x1407)   ROMSUB0HH;  /* 0x1407: Address Substitution 0HH */
EXTERN unsigned char __io(0x1408)   ROMCMP10;   /* 0x1408: Address Compare 10 */
EXTERN unsigned char __io(0x1409)   ROMCMP11;   /* 0x1409: Address Compare 11 */
EXTERN unsigned char __io(0x140a)   ROMCMP12;   /* 0x140a: Address Compare 12 */
/*---   (0x140b)  Reserved  ---*/
EXTERN unsigned char __io(0x140c)   ROMSUB1LL;  /* 0x140c: Address Substitution 1LL */
EXTERN unsigned char __io(0x140d)   ROMSUB1LH;  /* 0x140d: Address Substitution 1LH */
EXTERN unsigned char __io(0x140e)   ROMSUB1HL;  /* 0x140e: Address Substitution 1HL */
EXTERN unsigned char __io(0x140f)   ROMSUB1HH;  /* 0x140f: Address Substitution 1HH */

/***[0x1410]***************************************************************/
EXTERN unsigned char __io(0x1410)   ROMCMP20;   /* 0x1410: Address Compare 20 */
EXTERN unsigned char __io(0x1411)   ROMCMP21;   /* 0x1411: Address Compare 21 */
EXTERN unsigned char __io(0x1412)   ROMCMP22;   /* 0x1412: Address Compare 22 */
/*---   (0x1413)  Reserved  ---*/
EXTERN unsigned char __io(0x1414)   ROMSUB2LL;  /* 0x1414: Address Substitution 2LL */
EXTERN unsigned char __io(0x1415)   ROMSUB2LH;  /* 0x1415: Address Substitution 2LH */
EXTERN unsigned char __io(0x1416)   ROMSUB2HL;  /* 0x1416: Address Substitution 2HL */
EXTERN unsigned char __io(0x1417)   ROMSUB2HH;  /* 0x1417: Address Substitution 2HH */
EXTERN unsigned char __io(0x1418)   ROMCMP30;   /* 0x1418: Address Compare 30 */
EXTERN unsigned char __io(0x1419)   ROMCMP31;   /* 0x1419: Address Compare 31 */
EXTERN unsigned char __io(0x141a)   ROMCMP32;   /* 0x141a: Address Compare 32 */
/*---   (0x141b)  Reserved  ---*/
EXTERN unsigned char __io(0x141c)   ROMSUB3LL;  /* 0x141c: Address Substitution 3LL */
EXTERN unsigned char __io(0x141d)   ROMSUB3LH;  /* 0x141d: Address Substitution 3LH */
EXTERN unsigned char __io(0x141e)   ROMSUB3HL;  /* 0x141e: Address Substitution 3HL */
EXTERN unsigned char __io(0x141f)   ROMSUB3HH;  /* 0x141f: Address Substitution 3HH */

/***[0x1420]***************************************************************/
EXTERN unsigned char __io(0x1420)   ROMCMP40;   /* 0x1420: Address Compare 40 */
EXTERN unsigned char __io(0x1421)   ROMCMP41;   /* 0x1421: Address Compare 41 */
EXTERN unsigned char __io(0x1422)   ROMCMP42;   /* 0x1422: Address Compare 42 */
/*---   (0x1423)  Reserved  ---*/
EXTERN unsigned char __io(0x1424)   ROMSUB4LL;  /* 0x1424: Address Substitution 4LL */
EXTERN unsigned char __io(0x1425)   ROMSUB4LH;  /* 0x1425: Address Substitution 4LH */
EXTERN unsigned char __io(0x1426)   ROMSUB4HL;  /* 0x1426: Address Substitution 4HL */
EXTERN unsigned char __io(0x1427)   ROMSUB4HH;  /* 0x1427: Address Substitution 4HH */
EXTERN unsigned char __io(0x1428)   ROMCMP50;   /* 0x1428: Address Compare 50 */
EXTERN unsigned char __io(0x1429)   ROMCMP51;   /* 0x1429: Address Compare 51 */
EXTERN unsigned char __io(0x142a)   ROMCMP52;   /* 0x142a: Address Compare 52 */
/*---   (0x142b)  Reserved  ---*/
EXTERN unsigned char __io(0x142c)   ROMSUB5LL;  /* 0x142c: Address Substitution 5LL */
EXTERN unsigned char __io(0x142d)   ROMSUB5LH;  /* 0x142d: Address Substitution 5LH */
EXTERN unsigned char __io(0x142e)   ROMSUB5HL;  /* 0x142e: Address Substitution 5HL */
EXTERN unsigned char __io(0x142f)   ROMSUB5HH;  /* 0x142f: Address Substitution 5HH */

/***[0x1430]***************************************************************/
EXTERN unsigned char __io(0x1430)   ROMCMP60;   /* 0x1430: Address Compare 60 */
EXTERN unsigned char __io(0x1431)   ROMCMP61;   /* 0x1431: Address Compare 61 */
EXTERN unsigned char __io(0x1432)   ROMCMP62;   /* 0x1432: Address Compare 62 */
/*---   (0x1433)  Reserved  ---*/
EXTERN unsigned char __io(0x1434)   ROMSUB6LL;  /* 0x1434: Address Substitution 6LL */
EXTERN unsigned char __io(0x1435)   ROMSUB6LH;  /* 0x1435: Address Substitution 6LH */
EXTERN unsigned char __io(0x1436)   ROMSUB6HL;  /* 0x1436: Address Substitution 6HL */
EXTERN unsigned char __io(0x1437)   ROMSUB6HH;  /* 0x1437: Address Substitution 6HH */
EXTERN unsigned char __io(0x1438)   ROMCMP70;   /* 0x1438: Address Compare 70 */
EXTERN unsigned char __io(0x1439)   ROMCMP71;   /* 0x1439: Address Compare 71 */
EXTERN unsigned char __io(0x143a)   ROMCMP72;   /* 0x143a: Address Compare 72 */
/*---   (0x143b)  Reserved  ---*/
EXTERN unsigned char __io(0x143c)   ROMSUB7LL;  /* 0x143c: Address Substitution 7LL */
EXTERN unsigned char __io(0x143d)   ROMSUB7LH;  /* 0x143d: Address Substitution 7LH */
EXTERN unsigned char __io(0x143e)   ROMSUB7HL;  /* 0x143e: Address Substitution 7HL */
EXTERN unsigned char __io(0x143f)   ROMSUB7HH;  /* 0x143f: Address Substitution 7HH */

/*-eof-*/
