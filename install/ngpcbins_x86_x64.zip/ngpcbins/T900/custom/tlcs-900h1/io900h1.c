/*****************************************************************
;*         Sample SFR/Vector File for TLCS-900/H1 Series         *
;*                      MCU : TMP92FD23AFG                       *
;*---------------------------------------------------------------*
;*  (C)Copyright TOSHIBA CORPORATION 2009  All rights reserved   *
;*****************************************************************/

#define IO_MEM    1
/* This definition is for I/O variable and extern definition */
/* So please do not use the name "IO_MEM".*/

#include "io900h1.h"

void _startup(void);

/*========================================================
  [ Dummy function for interrupt ]
  ========================================================*/
void    __interrupt    _Int_dummy(void)
{
}

/*============================================
  [ Define interrupt table ]
    This part must be rewrite.
  ============================================*/
#pragma section const INT_VECTOR
void * const _IntTbl[] = {
     _startup       /* 0xffff00: reset / SWI0 */
    ,_Int_dummy     /* 0xffff04: SWI1  */
    ,_Int_dummy     /* 0xffff08: INTUNDEF / SWI2 */
    ,_Int_dummy     /* 0xffff0c: SWI3 */
    ,_Int_dummy     /* 0xffff10: SWI4 */
    ,_Int_dummy     /* 0xffff14: SWI5 */
    ,_Int_dummy     /* 0xffff18: SWI6 */
    ,_Int_dummy     /* 0xffff1c: SWI7 */
    ,_Int_dummy     /* 0xffff20: NMI */
    ,_Int_dummy     /* 0xffff24: INTWD */
    ,_Int_dummy     /* 0xffff28: INT0 */
    ,_Int_dummy     /* 0xffff2c: INT1 */
    ,_Int_dummy     /* 0xffff30: INT2 */
    ,_Int_dummy     /* 0xffff34: INT3 */
    ,_Int_dummy     /* 0xffff38: INT4 */
    ,_Int_dummy     /* 0xffff3c: INT5 */
    ,_Int_dummy     /* 0xffff40: INT6 */
    ,_Int_dummy     /* 0xffff44: INT7 */
    ,_Int_dummy     /* 0xffff48: INTTA0 */
    ,_Int_dummy     /* 0xffff4c: INTTA1 */
    ,_Int_dummy     /* 0xffff50: INTTA2 */
    ,_Int_dummy     /* 0xffff54: INTTA3 */
    ,_Int_dummy     /* 0xffff58: INTTA4 */
    ,_Int_dummy     /* 0xffff5c: INTTA5 */
    ,_Int_dummy     /* 0xffff60: (Reserved) */
    ,_Int_dummy     /* 0xffff64: (Reserved) */
    ,_Int_dummy     /* 0xffff68: INTRX0 */
    ,_Int_dummy     /* 0xffff6c: INTTX0 */
    ,_Int_dummy     /* 0xffff70: INTRX1 */
    ,_Int_dummy     /* 0xffff74: INTTX1 */
    ,_Int_dummy     /* 0xffff78: INTRX2 */
    ,_Int_dummy     /* 0xffff7c: INTTX2 */
    ,_Int_dummy     /* 0xffff80: (Reserved) */
    ,_Int_dummy     /* 0xffff84: (Reserved) */
    ,_Int_dummy     /* 0xffff88: INTSBE0 */
    ,_Int_dummy     /* 0xffff8c: (Reserved) */
    ,_Int_dummy     /* 0xffff90: INTSBE1 */
    ,_Int_dummy     /* 0xffff94: (Reserved) */
    ,_Int_dummy     /* 0xffff98: (Reserved) */
    ,_Int_dummy     /* 0xffff9c: (Reserved) */
    ,_Int_dummy     /* 0xffffa0: (Reserved) */
    ,_Int_dummy     /* 0xffffa4: (Reserved) */
    ,_Int_dummy     /* 0xffffa8: INTTB00 */
    ,_Int_dummy     /* 0xffffac: INTTB01 */
    ,_Int_dummy     /* 0xffffb0: INTTBO0 */
    ,_Int_dummy     /* 0xffffb4: INTTB10 */
    ,_Int_dummy     /* 0xffffb8: INTTB11 */
    ,_Int_dummy     /* 0xffffbc: INTTBO1 */
    ,_Int_dummy     /* 0xffffc0: INTAD */
    ,_Int_dummy     /* 0xffffc4: INTP0 */
    ,_Int_dummy     /* 0xffffc8: INTRTC */
    ,_Int_dummy     /* 0xffffcc: (Reserved) */
    ,_Int_dummy     /* 0xffffd0: INTTC0 */
    ,_Int_dummy     /* 0xffffd4: INTTC1 */
    ,_Int_dummy     /* 0xffffd8: INTTC2 */
    ,_Int_dummy     /* 0xffffdc: INTTC3 */
    ,_Int_dummy     /* 0xffffe0: INTTC4 */
    ,_Int_dummy     /* 0xffffe4: INTTC5 */
    ,_Int_dummy     /* 0xffffe8: INTTC6 */
    ,_Int_dummy     /* 0xffffec: INTTC7 */
    };
#pragma section const   /* return to default */

/*-eof-*/
