/*****************************************************************
;*         Sample Initial Program for TLCS-900/H1 Series         *
;*                      MCU : TMP92FD23AFG                       *
;*---------------------------------------------------------------*
;*  (C)Copyright TOSHIBA CORPORATION 2009  All rights reserved   *
;*****************************************************************/

#include <stdlib.h>
#include <errno.h>

/*===================================================================*/
/* [ Configuration part ]                                            */
/*   Following macro value means that:                               */
/*   0 : The function is not used.                                   */
/*   1 : The function is used.                                       */
/*   When you use 'abort' or 'exit' or 'heap area',                  */
/*   Rewrite each program to fit your use.                           */
/*===================================================================*/
#define  __USE_FLOAT    0   /* Change 0 to 1, if use floating point. */
#define  __USE_ABORT    0   /* Change 0 to 1, if use abort function. */
#define  __USE_EXIT     0   /* Change 0 to 1, if use exit function.  */
#define  __USE_HEAP     0   /* Change 0 to 1, if use heap area.      */

#if __USE_FLOAT
/*===================================================================*/
/* [ Define public variable ]                                        */
/*  When use floating point, this part is necessary.                 */
/*  Do not change this part.                                         */
/*  'errno' is reserved word. Do not access to this variable.        */
/*===================================================================*/
volatile int errno;                   /* Refer from standard library */

#endif      /* __USE_FLOAT */

#if __USE_ABORT
/*===================================================================*/
/* [ Standard library function: abort() ]                            */
/*   When use abort function, this part is necessary.                */
/*   Rewrite this part to fit your program.                          */
/*===================================================================*/
void    abort(void)
{
  /*=================================================================*/
  /*  Write the process before reset, then jump to your start up     */
  /*  routine.                                                       */
  /*=================================================================*/
  /*  __asm("    j    __startup");                            SAMPLE */
  /*=================================================================*/
}
#endif      /* __USE_ABORT */

#if __USE_EXIT
/*===================================================================*/
/* [ Standard library function: exit() ]                             */
/*   When use exit function, this part is necessary.                 */
/*   Rewrite this part to fit your program.                          */
/*===================================================================*/
void    exit(int status)
{
  /*=================================================================*/
  /*  Write the process as same as normal program ending.            */
  /*=================================================================*/
  /*  __asm("    halt");                                      SAMPLE */
  /*=================================================================*/
}
#endif      /* __USE_EXIT */

#if __USE_HEAP
/*===================================================================*/
/* [ Define Heap area ]                                              */
/*   When use malloc, calloc or realloc, this part is necessary.     */
/*   Rewrite the address and size of Heap area to fit your program.  */
/*===================================================================*/
#define  HeapTop   (void*)0x8000    /* Heap area top address */
#define  HeapSize  0x1000           /* Heap area size */
unsigned long SBRK_break = HeapTop; /* Set Heap area top address */
unsigned long SBRK_size = HeapSize; /* Set Heap area size */
void*    _allocb=((void *)0);       /* Memory management pointer */

#endif      /* __USE_HEAP */

/*-eof-*/
