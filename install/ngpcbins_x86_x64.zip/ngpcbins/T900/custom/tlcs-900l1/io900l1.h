/*****************************************************************
;*         Sample SFR Header File for TLCS-900/L1 Series         *
;*                      MCU : TMP91FW64FG                        *
;*---------------------------------------------------------------*
;*  (C)Copyright TOSHIBA CORPORATION 2009  All rights reserved   *
;*****************************************************************/

#ifdef IO_MEM
/* This definition is for I/O variable and extern definition */
/* So please do not use the name "IO_MEM".*/
#define EXTERN
#else
#define EXTERN extern
#endif

/***[0x00]************************************************************/
EXTERN unsigned char    __io(0x00)  P0;         /*  0x00: Port0 */
EXTERN unsigned char    __io(0x01)  P1;         /*  0x01: Port1 */
EXTERN unsigned char    __io(0x02)  P0CR;       /*  0x02: Port0 control */
/*---   (0x03)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x04)  P1CR;       /*  0x04: Port1 control */
EXTERN unsigned char    __io(0x05)  P1FC;       /*  0x05: Port1 function    */
EXTERN unsigned char    __io(0x06)  P2;         /*  0x06: Port2 */
/*---   (0x07)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x08)  P2CR;       /*  0x08: Port2 control */
EXTERN unsigned char    __io(0x09)  P2FC;       /*  0x09: Port2 function    */
/*---   (0x0a)  Reserved    ---*/ 
/*---   (0x0b)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x0c)  P3;         /*  0x0c: Port3 */
EXTERN unsigned char    __io(0x0d)  P3FC2;      /*  0x0d: Port3 function 2  */
EXTERN unsigned char    __io(0x0e)  P3CR;       /*  0x0e: Port3 control */
EXTERN unsigned char    __io(0x0f)  P3FC;       /*  0x0f: Port3 function    */

/***[0x10]*****************************************************************/
EXTERN unsigned char    __io(0x10)  P4;         /*  0x10: Port4 */
EXTERN unsigned char    __io(0x11)  P4FC2;      /*  0x11: Port4 function 2  */
EXTERN unsigned char    __io(0x12)  P4CR;       /*  0x12: Port4 control */
EXTERN unsigned char    __io(0x13)  P4FC;       /*  0x13: Port4 function    */
EXTERN unsigned char    __io(0x14)  P5;         /*  0x14: Port5 */
/*---   (0x15)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x16)  P5CR;       /*  0x16: Port5 control */
EXTERN unsigned char    __io(0x17)  P5FC;       /*  0x17: Port5 function    */
EXTERN unsigned char    __io(0x18)  P6;         /*  0x18: Port6 */
/*---   (0x19)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x1a)  P6CR;       /*  0x1a: Port6 control */
EXTERN unsigned char    __io(0x1b)  P6FC;       /*  0x1b: Port6 function    */
EXTERN unsigned char    __io(0x1c)  P7;         /*  0x1c: Port7 */
/*---   (0x1d)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x1e)  P7CR;       /*  0x1e: Port7 control */
EXTERN unsigned char    __io(0x1f)  P7FC;       /*  0x1f: Port7 function    */

/***[0x20]*****************************************************************/
EXTERN unsigned char    __io(0x20)  P8;         /*  0x20: Port8 */
/*---   (0x21)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x22)  P8CR;       /*  0x22: Port8 control */
EXTERN unsigned char    __io(0x23)  P8FC;       /*  0x23: Port8 function    */
EXTERN unsigned char    __io(0x24)  P9;         /*  0x24: Port9 */
/*---   (0x25)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x26)  P9CR;       /*  0x26: Port9 control */
EXTERN unsigned char    __io(0x27)  P9FC;       /*  0x27: Port9 function    */
EXTERN unsigned char    __io(0x28)  PA;         /*  0x28: PortA */
/*---   (0x29)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x2a)  PACR;       /*  0x2a: PortA control */
EXTERN unsigned char    __io(0x2b)  PAFC;       /*  0x2b: PortA function    */
EXTERN unsigned char    __io(0x2c)  PB;         /*  0x2c: PortB */
EXTERN unsigned char    __io(0x2d)  PBFC2;      /*  0x2d: PortB function 2  */
EXTERN unsigned char    __io(0x2e)  PBCR;       /*  0x2e: PortB control */
EXTERN unsigned char    __io(0x2f)  PBFC;       /*  0x2f: PortB function    */

/***[0x30]*****************************************************************/
/*---   (0x30)  Reserved    ---*/ 
/*---   (0x31)  Reserved    ---*/ 
/*---   (0x32)  Reserved    ---*/ 
/*---   (0x33)  Reserved    ---*/ 
/*---   (0x34)  Reserved    ---*/ 
/*---   (0x35)  Reserved    ---*/ 
/*---   (0x36)  Reserved    ---*/ 
/*---   (0x37)  Reserved    ---*/ 
/*---   (0x38)  Reserved    ---*/ 
/*---   (0x39)  Reserved    ---*/ 
/*---   (0x3a)  Reserved    ---*/ 
/*---   (0x3b)  Reserved    ---*/ 
/*---   (0x3c)  Reserved    ---*/ 
/*---   (0x3d)  Reserved    ---*/ 
/*---   (0x3e)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x3f)  ODE;        /*  0x3f: Open drain control    */

/***[0x60]*****************************************************************/
/*---   (0x60)  Reserved    ---*/ 
/*---   (0x61)  Reserved    ---*/ 
/*---   (0x62)  Reserved    ---*/ 
/*---   (0x63)  Reserved    ---*/ 
/*---   (0x64)  Reserved    ---*/ 
/*---   (0x65)  Reserved    ---*/ 
/*---   (0x66)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x67)  TXDCTL;     /*  0x67: TXD output control    */
/*---   (0x68)  Reserved    ---*/ 
/*---   (0x69)  Reserved    ---*/ 
/*---   (0x6a)  Reserved    ---*/ 
/*---   (0x6b)  Reserved    ---*/ 
/*---   (0x6c)  Reserved    ---*/ 
/*---   (0x6d)  Reserved    ---*/ 
/*---   (0x6e)  Reserved    ---*/ 
/*---   (0x6f)  Reserved    ---*/ 

/***[0x70]*****************************************************************/
/*---   (0x70)  Reserved    ---*/ 
/*---   (0x71)  Reserved    ---*/ 
/*---   (0x72)  Reserved    ---*/ 
/*---   (0x73)  Reserved    ---*/ 
/*---   (0x74)  Reserved    ---*/ 
/*---   (0x75)  Reserved    ---*/ 
/*---   (0x76)  Reserved    ---*/ 
/*---   (0x77)  Reserved    ---*/ 
/*---   (0x78)  Reserved    ---*/ 
/*---   (0x79)  Reserved    ---*/ 
/*---   (0x7a)  Reserved    ---*/ 
/*---   (0x7b)  Reserved    ---*/ 
/*---   (0x7c)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x7d)  PZ;         /*  0x7d: PortZ */
EXTERN unsigned char    __io(0x7e)  PZCR;       /*  0x7e: PortZ control */
EXTERN unsigned char    __io(0x7f)  PZFC;       /*  0x7f: PortZ function    */

/***[0x80]*****************************************************************/
EXTERN unsigned char    __io(0x80)  DMA0V;      /*  0x80: DMA0 start vector */
EXTERN unsigned char    __io(0x81)  DMA1V;      /*  0x81: DMA1 start vector */
EXTERN unsigned char    __io(0x82)  DMA2V;      /*  0x82: DMA2 start vector */
EXTERN unsigned char    __io(0x83)  DMA3V;      /*  0x83: DMA3 start vector */
/*---   (0x84)  Reserved    ---*/ 
/*---   (0x85)  Reserved    ---*/ 
/*---   (0x86)  Reserved    ---*/ 
/*---   (0x87)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x88)  INTCLR;     /*  0x88: INT clear control */
EXTERN unsigned char    __io(0x89)  DMAR;       /*  0x89: DMA software request  */
EXTERN unsigned char    __io(0x8a)  DMAB;       /*  0x8a: DMA Burst */
/*---   (0x8b)  Reserved    ---*/ 
EXTERN unsigned char    __io(0x8c)  IIMC;       /*  0x8c: INT input mode control    */
/*---   (0x8d)  Reserved    ---*/ 
/*---   (0x8e)  Reserved    ---*/ 
/*---   (0x8f)  Reserved    ---*/ 

/***[0x90]*****************************************************************/
EXTERN unsigned char    __io(0x90)  INTE0AD;    /*  0x90: INT0 & INTAD enable   */
EXTERN unsigned char    __io(0x91)  INTE12;     /*  0x91: INT1 & INT2 enable    */
EXTERN unsigned char    __io(0x92)  INTE34;     /*  0x92: INT3 & INT4 enable    */
EXTERN unsigned char    __io(0x93)  INTE56;     /*  0x93: INT5 & INT6 enable    */
EXTERN unsigned char    __io(0x94)  INTE78;     /*  0x94: INT7 & INT8 enable    */
EXTERN unsigned char    __io(0x95)  INTE910;    /*  0x95: INT9 & INT10 enable   */
EXTERN unsigned char    __io(0x96)  INTETA01;   /*  0x96: INTTA0 & INTTA1 enable    */
EXTERN unsigned char    __io(0x97)  INTETA23;   /*  0x97: INTTA2 & INTTA3 enable    */
EXTERN unsigned char    __io(0x98)  INTETA45;   /*  0x98: INTTA4 & INTTA5 enable    */
EXTERN unsigned char    __io(0x99)  INTETB0;    /*  0x99: INTTB00 & INTTB01 enable  */
EXTERN unsigned char    __io(0x9a)  INTETB1;    /*  0x9a: INTTB10 & INTTB11 enable  */
EXTERN unsigned char    __io(0x9b)  INTETB2;    /*  0x9b: INTTB20 & INTTB21 enable  */
EXTERN unsigned char    __io(0x9c)  INTETB3;    /*  0x9c: INTTB30 & INTTB31 enable  */
EXTERN unsigned char    __io(0x9d)  INTETB4;    /*  0x9d: INTTB40 & INTTB41 enable  */
EXTERN unsigned char    __io(0x9e)  INTETB01V;  /*  0x9e: INTTBOF0 & INTTBOF1 enable    */
EXTERN unsigned char    __io(0x9f)  INTETB23V;  /*  0x9f: INTTBOF2 & INTTBOF3 enable    */

/***[0xa0]*****************************************************************/
EXTERN unsigned char    __io(0xa0)  INTETB4VRTC;    /*  0xa0: INTTBOF4 & INTRTC enable  */
EXTERN unsigned char    __io(0xa1)  INTES0;     /*  0xa1: INTTX0 & INTRX0 enable    */
EXTERN unsigned char    __io(0xa2)  INTES1;     /*  0xa2: INTTX1 & INTRX1 enable    */
EXTERN unsigned char    __io(0xa3)  INTES2;     /*  0xa3: INTTX2 & INTRX2 enable    */
EXTERN unsigned char    __io(0xa4)  INTESBI01;  /*  0xa4: INTSBI0 & INTSBI0 enable  */
EXTERN unsigned char    __io(0xa5)  INTETC01;   /*  0xa5: INTTC0 & INTTC1 enable    */
EXTERN unsigned char    __io(0xa6)  INTETC23;   /*  0xa6: INTTC2 & INTTC3 enable    */
/*---   (0xa7)  Reserved    ---*/ 
/*---   (0xa8)  Reserved    ---*/ 
/*---   (0xa9)  Reserved    ---*/ 
/*---   (0xaa)  Reserved    ---*/ 
/*---   (0xab)  Reserved    ---*/ 
/*---   (0xac)  Reserved    ---*/ 
/*---   (0xad)  Reserved    ---*/ 
/*---   (0xae)  Reserved    ---*/ 
/*---   (0xaf)  Reserved    ---*/ 

/***[0xc0]*****************************************************************/
EXTERN unsigned char    __io(0xc0)  B0CS;       /*  0xc0: Block 0 CS/WAIT control   */
EXTERN unsigned char    __io(0xc1)  B1CS;       /*  0xc1: Block 1 CS/WAIT control   */
EXTERN unsigned char    __io(0xc2)  B2CS;       /*  0xc2: Block 2 CS/WAIT control   */
EXTERN unsigned char    __io(0xc3)  B3CS;       /*  0xc3: Block 3 CS/WAIT control   */
/*---   (0xc4)  Reserved    ---*/ 
/*---   (0xc5)  Reserved    ---*/ 
/*---   (0xc6)  Reserved    ---*/ 
EXTERN unsigned char    __io(0xc7)  BEXCS;      /*  0xc7: External CS/WAIT control  */
EXTERN unsigned char    __io(0xc8)  MSAR0;      /*  0xc8: Memory address 0  */
EXTERN unsigned char    __io(0xc9)  MAMR0;      /*  0xc9: Memory address mask 0 */
EXTERN unsigned char    __io(0xca)  MSAR1;      /*  0xca: Memory address 1  */
EXTERN unsigned char    __io(0xcb)  MAMR1;      /*  0xcb: Memory address mask 1 */
EXTERN unsigned char    __io(0xcc)  MSAR2;      /*  0xcc: Memory address 2  */
EXTERN unsigned char    __io(0xcd)  MAMR2;      /*  0xcd: Memory address mask 2 */
EXTERN unsigned char    __io(0xce)  MSAR3;      /*  0xce: Memory address 3  */
EXTERN unsigned char    __io(0xcf)  MAMR3;      /*  0xcf: Memory address mask 3 */

/***[0xe0]*****************************************************************/
EXTERN unsigned char    __io(0xe0)  SYSCR0;     /*  0xe0: System clock control 0    */
EXTERN unsigned char    __io(0xe1)  SYSCR1;     /*  0xe1: System clock control 1    */
EXTERN unsigned char    __io(0xe2)  SYSCR2;     /*  0xe2: System clock control 2    */
EXTERN unsigned char    __io(0xe3)  EMCCR0;     /*  0xe3: EMC control 0 */
EXTERN unsigned char    __io(0xe4)  EMCCR1;     /*  0xe4: EMC control 1 */
/*---   (0xe5)  Reserved    ---*/ 
/*---   (0xe6)  Reserved    ---*/ 
/*---   (0xe7)  Reserved    ---*/ 
/*---   (0xe8)  Reserved    ---*/ 
/*---   (0xe9)  Reserved    ---*/ 
/*---   (0xea)  Reserved    ---*/ 
/*---   (0xeb)  Reserved    ---*/ 
/*---   (0xec)  Reserved    ---*/ 
/*---   (0xed)  Reserved    ---*/ 
/*---   (0xee)  Reserved    ---*/ 
/*---   (0xef)  Reserved    ---*/ 

/***[0x100]****************************************************************/
EXTERN unsigned char    __io(0x100) TA01RUN;    /*  0x100: 8 bit timer RUN  */
/*---   (0x101) Reserved    ---*/ 
EXTERN unsigned char    __io(0x102) TA0REG;     /*  0x102: 8 bit timer 0    */
EXTERN unsigned char    __io(0x103) TA1REG;     /*  0x103: 8 bit timer 1    */
EXTERN unsigned char    __io(0x104) TA01MOD;    /*  0x104: 8 bit timer source CLK & mode    */
EXTERN unsigned char    __io(0x105) TA1FFCR;    /*  0x105: 8 bit timer flip-flop control    */
/*---   (0x106) Reserved    ---*/ 
/*---   (0x107) Reserved    ---*/ 
EXTERN unsigned char    __io(0x108) TA23RUN;    /*  0x108: 8 bit timer RUN  */
/*---   (0x109) Reserved    ---*/ 
EXTERN unsigned char    __io(0x10a) TA2REG;     /*  0x10a: 8 bit timer 0    */
EXTERN unsigned char    __io(0x10b) TA3REG;     /*  0x10b: 8 bit timer 1    */
EXTERN unsigned char    __io(0x10c) TA23MOD;    /*  0x10c: 8 bit timer source CLK & mode    */
EXTERN unsigned char    __io(0x10d) TA3FFCR;    /*  0x10d: 8 bit timer flip-flop control    */
/*---   (0x10e) Reserved    ---*/ 
/*---   (0x10f) Reserved    ---*/ 

/***[0x110]****************************************************************/
EXTERN unsigned char    __io(0x110) TA45RUN;    /*  0x110: 8 bit timer RUN  */
/*---   (0x111) Reserved    ---*/ 
EXTERN unsigned char    __io(0x112) TA4REG;     /*  0x112: 8 bit timer 0    */
EXTERN unsigned char    __io(0x113) TA5REG;     /*  0x113: 8 bit timer 1    */
EXTERN unsigned char    __io(0x114) TA45MOD;    /*  0x114: 8 bit timer source CLK & mode    */
EXTERN unsigned char    __io(0x115) TA5FFCR;    /*  0x115: 8 bit timer flip-flop control    */
/*---   (0x116) Reserved    ---*/ 
/*---   (0x117) Reserved    ---*/ 
/*---   (0x118) Reserved    ---*/ 
/*---   (0x119) Reserved    ---*/ 
/*---   (0x11a) Reserved    ---*/ 
/*---   (0x11b) Reserved    ---*/ 
/*---   (0x11c) Reserved    ---*/ 
/*---   (0x11d) Reserved    ---*/ 
/*---   (0x11e) Reserved    ---*/ 
/*---   (0x11f) Reserved    ---*/ 

/***[0x180]****************************************************************/
EXTERN unsigned char    __io(0x180) TB0RUN;     /*  0x180: 16 bit timer control */
/*---   (0x181) Reserved    ---*/ 
EXTERN unsigned char    __io(0x182) TB0MOD;     /*  0x182: 16 bit timer source CLK & mode   */
EXTERN unsigned char    __io(0x183) TB0FFCR;    /*  0x183: 16 bit timer flip-flop control   */
EXTERN unsigned char    __io(0x184) PRESEL0;    /*  0x184: Prescaler clock selection 0  */
/*---   (0x185) Reserved    ---*/ 
/*---   (0x186) Reserved    ---*/ 
/*---   (0x187) Reserved    ---*/ 
EXTERN unsigned char    __io(0x188) TB0RG0L;    /*  0x188: 16 bit timer 0L  */
EXTERN unsigned char    __io(0x189) TB0RG0H;    /*  0x189: 16 bit timer 0H  */
EXTERN unsigned char    __io(0x18a) TB0RG1L;    /*  0x18a: 16 bit timer 1L  */
EXTERN unsigned char    __io(0x18b) TB0RG1H;    /*  0x18b: 16 bit timer 1H  */
EXTERN unsigned char    __io(0x18c) TB0CP0L;    /*  0x18c: Capture 0L   */
EXTERN unsigned char    __io(0x18d) TB0CP0H;    /*  0x18d: Capture 0H   */
EXTERN unsigned char    __io(0x18e) TB0CP1L;    /*  0x18e: Capture 1L   */
EXTERN unsigned char    __io(0x18f) TB0CP1H;    /*  0x18f: Capture 1H   */

/***[0x190]****************************************************************/
EXTERN unsigned char    __io(0x190) TB1RUN;     /*  0x190: 16 bit timer control */
/*---   (0x191) Reserved    ---*/ 
EXTERN unsigned char    __io(0x192) TB1MOD;     /*  0x192: 16 bit timer source CLK & mode   */
EXTERN unsigned char    __io(0x193) TB1FFCR;    /*  0x193: 16 bit timer flip-flop control   */
EXTERN unsigned char    __io(0x194) PRESEL1;    /*  0x194: Prescaler clock selection 1  */
/*---   (0x195) Reserved    ---*/ 
/*---   (0x196) Reserved    ---*/ 
/*---   (0x197) Reserved    ---*/ 
EXTERN unsigned char    __io(0x198) TB1RG0L;    /*  0x198: 16 bit timer 0L  */
EXTERN unsigned char    __io(0x199) TB1RG0H;    /*  0x199: 16 bit timer 0H  */
EXTERN unsigned char    __io(0x19a) TB1RG1L;    /*  0x19a: 16 bit timer 1L  */
EXTERN unsigned char    __io(0x19b) TB1RG1H;    /*  0x19b: 16 bit timer 1H  */
EXTERN unsigned char    __io(0x19c) TB1CP0L;    /*  0x19c: Capture 0L   */
EXTERN unsigned char    __io(0x19d) TB1CP0H;    /*  0x19d: Capture 0H   */
EXTERN unsigned char    __io(0x19e) TB1CP1L;    /*  0x19e: Capture 1L   */
EXTERN unsigned char    __io(0x19f) TB1CP1H;    /*  0x19f: Capture 1H   */

/***[0x1a0]****************************************************************/
EXTERN unsigned char    __io(0x1a0) TB2RUN;     /*  0x1a0: 16 bit timer control */
/*---   (0x1a1) Reserved    ---*/ 
EXTERN unsigned char    __io(0x1a2) TB2MOD;     /*  0x1a2: 16 bit timer source CLK & mode   */
EXTERN unsigned char    __io(0x1a3) TB2FFCR;    /*  0x1a3: 16 bit timer flip-flop control   */
EXTERN unsigned char    __io(0x1a4) PRESEL2;    /*  0x1a4: Prescaler clock selection 2  */
/*---   (0x1a5) Reserved    ---*/ 
/*---   (0x1a6) Reserved    ---*/ 
/*---   (0x1a7) Reserved    ---*/ 
EXTERN unsigned char    __io(0x1a8) TB2RG0L;    /*  0x1a8: 16 bit timer 0L  */
EXTERN unsigned char    __io(0x1a9) TB2RG0H;    /*  0x1a9: 16 bit timer 0H  */
EXTERN unsigned char    __io(0x1aa) TB2RG1L;    /*  0x1aa: 16 bit timer 1L  */
EXTERN unsigned char    __io(0x1ab) TB2RG1H;    /*  0x1ab: 16 bit timer 1H  */
EXTERN unsigned char    __io(0x1ac) TB2CP0L;    /*  0x1ac: Capture 0L   */
EXTERN unsigned char    __io(0x1ad) TB2CP0H;    /*  0x1ad: Capture 0H   */
EXTERN unsigned char    __io(0x1ae) TB2CP1L;    /*  0x1ae: Capture 1L   */
EXTERN unsigned char    __io(0x1af) TB2CP1H;    /*  0x1af: Capture 1H   */

/***[0x1b0]****************************************************************/
EXTERN unsigned char    __io(0x1b0) TB3RUN;     /*  0x1b0: 16 bit timer control */
/*---   (0x1b1) Reserved    ---*/ 
EXTERN unsigned char    __io(0x1b2) TB3MOD;     /*  0x1b2: 16 bit timer source CLK & mode   */
EXTERN unsigned char    __io(0x1b3) TB3FFCR;    /*  0x1b3: 16 bit timer flip-flop control   */
EXTERN unsigned char    __io(0x1b4) PRESEL3;    /*  0x1b4: Prescaler clock selection 3  */
/*---   (0x1b5) Reserved    ---*/ 
/*---   (0x1b6) Reserved    ---*/ 
/*---   (0x1b7) Reserved    ---*/ 
EXTERN unsigned char    __io(0x1b8) TB3RG0L;    /*  0x1b8: 16 bit timer 0L  */
EXTERN unsigned char    __io(0x1b9) TB3RG0H;    /*  0x1b9: 16 bit timer 0H  */
EXTERN unsigned char    __io(0x1ba) TB3RG1L;    /*  0x1ba: 16 bit timer 1L  */
EXTERN unsigned char    __io(0x1bb) TB3RG1H;    /*  0x1bb: 16 bit timer 1H  */
EXTERN unsigned char    __io(0x1bc) TB3CP0L;    /*  0x1bc: Capture 0L   */
EXTERN unsigned char    __io(0x1bd) TB3CP0H;    /*  0x1bd: Capture 0H   */
EXTERN unsigned char    __io(0x1be) TB3CP1L;    /*  0x1be: Capture 1L   */
EXTERN unsigned char    __io(0x1bf) TB3CP1H;    /*  0x1bf: Capture 1H   */

/***[0x1c0]****************************************************************/
EXTERN unsigned char    __io(0x1c0) TB4RUN;     /*  0x1c0: 16 bit timer control */
/*---   (0x1c1) Reserved    ---*/ 
EXTERN unsigned char    __io(0x1c2) TB4MOD;     /*  0x1c2: 16 bit timer source CLK & mode   */
EXTERN unsigned char    __io(0x1c3) TB4FFCR;    /*  0x1c3: 16 bit timer flip-flop control   */
EXTERN unsigned char    __io(0x1c4) PRESEL4;    /*  0x1c4: Prescaler clock selection 4  */
/*---   (0x1c5) Reserved    ---*/ 
/*---   (0x1c6) Reserved    ---*/ 
/*---   (0x1c7) Reserved    ---*/ 
EXTERN unsigned char    __io(0x1c8) TB4RG0L;    /*  0x1c8: 16 bit timer 0L  */
EXTERN unsigned char    __io(0x1c9) TB4RG0H;    /*  0x1c9: 16 bit timer 0H  */
EXTERN unsigned char    __io(0x1ca) TB4RG1L;    /*  0x1ca: 16 bit timer 1L  */
EXTERN unsigned char    __io(0x1cb) TB4RG1H;    /*  0x1cb: 16 bit timer 1H  */
EXTERN unsigned char    __io(0x1cc) TB4CP0L;    /*  0x1cc: Capture 0L   */
EXTERN unsigned char    __io(0x1cd) TB4CP0H;    /*  0x1cd: Capture 0H   */
EXTERN unsigned char    __io(0x1ce) TB4CP1L;    /*  0x1ce: Capture 1L   */
EXTERN unsigned char    __io(0x1cf) TB4CP1H;    /*  0x1cf: Capture 1H   */

/***[0x200]****************************************************************/
EXTERN unsigned char    __io(0x200) SC0BUF;     /*  0x200: Serial CH0 buffer    */
EXTERN unsigned char    __io(0x201) SC0CR;      /*  0x201: Serial CH0 control   */
EXTERN unsigned char    __io(0x202) SC0MOD0;    /*  0x202: Serial CH0 mode 0    */
EXTERN unsigned char    __io(0x203) BR0CR;      /*  0x203: Serial CH0 baud rate control */
EXTERN unsigned char    __io(0x204) BR0ADD;     /*  0x204: Serial CH0 K setting */
EXTERN unsigned char    __io(0x205) SC0MOD1;    /*  0x205: Serial CH0 mode 1    */
/*---   (0x206) Reserved    ---*/ 
/*---   (0x207) Reserved    ---*/ 
EXTERN unsigned char    __io(0x208) SC1BUF;     /*  0x208: Serial CH1 buffer    */
EXTERN unsigned char    __io(0x209) SC1CR;      /*  0x209: Serial CH1 control   */
EXTERN unsigned char    __io(0x20a) SC1MOD0;    /*  0x20a: Serial CH1 mode 0    */
EXTERN unsigned char    __io(0x20b) BR1CR;      /*  0x20b: Serial CH1 baud rate control */
EXTERN unsigned char    __io(0x20c) BR1ADD;     /*  0x20c: Serial CH1 K setting */
EXTERN unsigned char    __io(0x20d) SC1MOD1;    /*  0x20d: Serial CH1 mode 1    */
/*---   (0x20e) Reserved    ---*/ 
/*---   (0x20f) Reserved    ---*/ 

/***[0x210]****************************************************************/
EXTERN unsigned char    __io(0x210) SC2BUF;     /*  0x210: Serial CH2 buffer    */
EXTERN unsigned char    __io(0x211) SC2CR;      /*  0x211: Serial CH2 control   */
EXTERN unsigned char    __io(0x212) SC2MOD0;    /*  0x212: Serial CH2 mode 0    */
EXTERN unsigned char    __io(0x213) BR2CR;      /*  0x213: Serial CH2 baud rate control */
EXTERN unsigned char    __io(0x214) BR2ADD;     /*  0x214: Serial CH2 K setting */
EXTERN unsigned char    __io(0x215) SC2MOD1;    /*  0x215: Serial CH2 mode 1    */
/*---   (0x216) Reserved    ---*/ 
/*---   (0x217) Reserved    ---*/ 
/*---   (0x218) Reserved    ---*/ 
/*---   (0x219) Reserved    ---*/ 
/*---   (0x21a) Reserved    ---*/ 
/*---   (0x21b) Reserved    ---*/ 
/*---   (0x21c) Reserved    ---*/ 
/*---   (0x21d) Reserved    ---*/ 
/*---   (0x21e) Reserved    ---*/ 
/*---   (0x21f) Reserved    ---*/ 

/***[0x240]****************************************************************/
EXTERN unsigned char    __io(0x240) SBI0CR1;    /*  0x240: SBI control 1    */
EXTERN unsigned char    __io(0x241) SBI0DBR;    /*  0x241: SBI buffer   */
EXTERN unsigned char    __io(0x242) I2C0AR;     /*  0x242: I2C bus address  */
EXTERN unsigned char    __io(0x243) SBI0SR;     /*  0x243: SBI status   */
EXTERN unsigned char    __io(0x244) SBI0BR;     /*  0x244: SBI baud rate    */
/*---   (0x245) Reserved    ---*/ 
/*---   (0x246) Reserved    ---*/ 
EXTERN unsigned char    __io(0x247) SBI0CR0;    /*  0x247: SBI control 0    */
EXTERN unsigned char    __io(0x248) SBI1CR1;    /*  0x248: SBI control 1    */
EXTERN unsigned char    __io(0x249) SBI1DBR;    /*  0x249: SBI buffer   */
EXTERN unsigned char    __io(0x24a) I2C1AR;     /*  0x24a: I2C bus address  */
EXTERN unsigned char    __io(0x24b) SBI1SR;     /*  0x24b: SBI status   */
EXTERN unsigned char    __io(0x24c) SBI1BR;     /*  0x24c: SBI baud rate    */
/*---   (0x24d) Reserved    ---*/ 
/*---   (0x24e) Reserved    ---*/ 
EXTERN unsigned char    __io(0x24f) SBI1CR0;    /*  0x24f: SBI control 0    */

/***[0x2b0]****************************************************************/
EXTERN unsigned char    __io(0x2b0) ADCCR1;     /*  0x2b0: AD control 1 */
EXTERN unsigned char    __io(0x2b1) ADCCR2;     /*  0x2b1: AD control 2 */
EXTERN unsigned char    __io(0x2b2) ADCDRL;     /*  0x2b2: AD result L  */
EXTERN unsigned char    __io(0x2b3) ADCDRH;     /*  0x2b3: AD result H  */
/*---   (0x2b4) Reserved    ---*/ 
/*---   (0x2b5) Reserved    ---*/ 
/*---   (0x2b6) Reserved    ---*/ 
/*---   (0x2b7) Reserved    ---*/ 
/*---   (0x2b8) Reserved    ---*/ 
/*---   (0x2b9) Reserved    ---*/ 
/*---   (0x2ba) Reserved    ---*/ 
/*---   (0x2bb) Reserved    ---*/ 
/*---   (0x2bc) Reserved    ---*/ 
/*---   (0x2bd) Reserved    ---*/ 
/*---   (0x2be) Reserved    ---*/ 
/*---   (0x2bf) Reserved    ---*/ 

/***[0x300]****************************************************************/
EXTERN unsigned char    __io(0x300) WDMOD;      /*  0x300: WDT mode */
EXTERN unsigned char    __io(0x301) WDCR;       /*  0x301: WDT control  */
/*---   (0x302) Reserved    ---*/ 
/*---   (0x303) Reserved    ---*/ 
/*---   (0x304) Reserved    ---*/ 
/*---   (0x305) Reserved    ---*/ 
/*---   (0x306) Reserved    ---*/ 
/*---   (0x307) Reserved    ---*/ 
/*---   (0x308) Reserved    ---*/ 
/*---   (0x309) Reserved    ---*/ 
/*---   (0x30a) Reserved    ---*/ 
/*---   (0x30b) Reserved    ---*/ 
/*---   (0x30c) Reserved    ---*/ 
/*---   (0x30d) Reserved    ---*/ 
/*---   (0x30e) Reserved    ---*/ 
/*---   (0x30f) Reserved    ---*/ 

/***[0x310]****************************************************************/
EXTERN unsigned char    __io(0x310) RTCCR;      /*  0x310: RTC control  */
/*---   (0x311) Reserved    ---*/ 
/*---   (0x312) Reserved    ---*/ 
/*---   (0x313) Reserved    ---*/ 
/*---   (0x314) Reserved    ---*/ 
/*---   (0x315) Reserved    ---*/ 
/*---   (0x316) Reserved    ---*/ 
/*---   (0x317) Reserved    ---*/ 
/*---   (0x318) Reserved    ---*/ 
/*---   (0x319) Reserved    ---*/ 
/*---   (0x31a) Reserved    ---*/ 
/*---   (0x31b) Reserved    ---*/ 
/*---   (0x31c) Reserved    ---*/ 
/*---   (0x31d) Reserved    ---*/ 
/*---   (0x31e) Reserved    ---*/ 
/*---   (0x31f) Reserved    ---*/ 

/***[0x400]****************************************************************/
EXTERN unsigned char    __io(0x400) ROMCMP00;   /*  0x400: Address Compare 00   */
EXTERN unsigned char    __io(0x401) ROMCMP01;   /*  0x401: Address Compare 01   */
EXTERN unsigned char    __io(0x402) ROMCMP02;   /*  0x402: Address Compare 02   */
/*---   (0x403) Reserved    ---*/ 
EXTERN unsigned char    __io(0x404) ROMSUB0L;   /*  0x404: Address Substitution 0L  */
EXTERN unsigned char    __io(0x405) ROMSUB0H;   /*  0x405: Address Substitution 0H  */
/*---   (0x406) Reserved    ---*/ 
/*---   (0x407) Reserved    ---*/ 
EXTERN unsigned char    __io(0x408) ROMCMP10;   /*  0x408: Address Compare 10   */
EXTERN unsigned char    __io(0x409) ROMCMP11;   /*  0x409: Address Compare 11   */
EXTERN unsigned char    __io(0x40a) ROMCMP12;   /*  0x40a: Address Compare 12   */
/*---   (0x40b) Reserved    ---*/ 
EXTERN unsigned char    __io(0x40c) ROMSUB1L;   /*  0x40c: Address Substitution 1L  */
EXTERN unsigned char    __io(0x40d) ROMSUB1H;   /*  0x40d: Address Substitution 1H  */
/*---   (0x40e) Reserved    ---*/ 
/*---   (0x40f) Reserved    ---*/ 

/***[0x410]****************************************************************/
EXTERN unsigned char    __io(0x410) ROMCMP20;   /*  0x410: Address Compare 20   */
EXTERN unsigned char    __io(0x411) ROMCMP21;   /*  0x411: Address Compare 21   */
EXTERN unsigned char    __io(0x412) ROMCMP22;   /*  0x412: Address Compare 22   */
/*---   (0x413) Reserved    ---*/ 
EXTERN unsigned char    __io(0x414) ROMSUB2L;   /*  0x414: Address Substitution 2L  */
EXTERN unsigned char    __io(0x415) ROMSUB2H;   /*  0x415: Address Substitution 2H  */
/*---   (0x416) Reserved    ---*/ 
/*---   (0x417) Reserved    ---*/ 
EXTERN unsigned char    __io(0x418) ROMCMP30;   /*  0x418: Address Compare 30   */
EXTERN unsigned char    __io(0x419) ROMCMP31;   /*  0x419: Address Compare 31   */
EXTERN unsigned char    __io(0x41a) ROMCMP32;   /*  0x41a: Address Compare 32   */
/*---   (0x41b) Reserved    ---*/ 
EXTERN unsigned char    __io(0x41c) ROMSUB3L;   /*  0x41c: Address Substitution 3L  */
EXTERN unsigned char    __io(0x41d) ROMSUB3H;   /*  0x41d: Address Substitution 3H  */
/*---   (0x41e) Reserved    ---*/ 
/*---   (0x41f) Reserved    ---*/ 

/***[0x420]****************************************************************/
EXTERN unsigned char    __io(0x420) ROMCMP40;   /*  0x420: Address Compare 40   */
EXTERN unsigned char    __io(0x421) ROMCMP41;   /*  0x421: Address Compare 41   */
EXTERN unsigned char    __io(0x422) ROMCMP42;   /*  0x422: Address Compare 42   */
/*---   (0x423) Reserved    ---*/ 
EXTERN unsigned char    __io(0x424) ROMSUB4L;   /*  0x424: Address Substitution 4L  */
EXTERN unsigned char    __io(0x425) ROMSUB4H;   /*  0x425: Address Substitution 4H  */
/*---   (0x426) Reserved    ---*/ 
/*---   (0x427) Reserved    ---*/ 
EXTERN unsigned char    __io(0x428) ROMCMP50;   /*  0x428: Address Compare 50   */
EXTERN unsigned char    __io(0x429) ROMCMP51;   /*  0x429: Address Compare 51   */
EXTERN unsigned char    __io(0x42a) ROMCMP52;   /*  0x42a: Address Compare 52   */
/*---   (0x42b) Reserved    ---*/ 
EXTERN unsigned char    __io(0x42c) ROMSUB5L;   /*  0x42c: Address Substitution 5L  */
EXTERN unsigned char    __io(0x42d) ROMSUB5H;   /*  0x42d: Address Substitution 5H  */
/*---   (0x42e) Reserved    ---*/ 
/*---   (0x42f) Reserved    ---*/ 

/*-eof-*/
