/*****************************************************************
;*         Sample SFR/Vector File for TLCS-900/L1 Series         *
;*                      MCU : TMP91FW64FG                        *
;*---------------------------------------------------------------*
;*  (C)Copyright TOSHIBA CORPORATION 2009  All rights reserved   *
;*****************************************************************/

#define IO_MEM    1
/* This definition is for I/O variable and extern definition */
/* So please do not use the name "IO_MEM".*/

#include "io900l1.h"

void _startup(void);

/*========================================================
  [ Dummy function for interrupt ]
  ========================================================*/
void    __interrupt    _Int_dummy(void)
{
}

/*============================================
  [ Define interrupt table ]
    This part must be rewrite.
  ============================================*/
#pragma section const INT_VECTOR
void * const _IntTbl[] = {
     _startup       /* 0xffff00: reset / SWI0 */
    ,_Int_dummy     /* 0xffff04: SWI1  */
    ,_Int_dummy     /* 0xffff08: INTUNDEF / SWI2 */
    ,_Int_dummy     /* 0xffff0c: SWI3 */
    ,_Int_dummy     /* 0xffff10: SWI4 */
    ,_Int_dummy     /* 0xffff14: SWI5 */
    ,_Int_dummy     /* 0xffff18: SWI6 */
    ,_Int_dummy     /* 0xffff1c: SWI7 */
    ,_Int_dummy     /* 0xffff20: NMI */
    ,_Int_dummy     /* 0xffff24: INTWD */
    ,_Int_dummy     /* 0xffff28: INT0 */
    ,_Int_dummy     /* 0xffff2c: INT1 */
    ,_Int_dummy     /* 0xffff30: INT2 */
    ,_Int_dummy     /* 0xffff34: INT3 */
    ,_Int_dummy     /* 0xffff38: INT4 */
    ,_Int_dummy     /* 0xffff3c: INT5 */
    ,_Int_dummy     /* 0xffff40: INT6 */
    ,_Int_dummy     /* 0xffff44: INT7 */
    ,_Int_dummy     /* 0xffff48: INT8 */
    ,_Int_dummy     /* 0xffff4c: INT9 */
    ,_Int_dummy     /* 0xffff50: INT10 */
    ,_Int_dummy     /* 0xffff54: INTTA0 */
    ,_Int_dummy     /* 0xffff58: INTTA1 */
    ,_Int_dummy     /* 0xffff5c: INTTA2 */
    ,_Int_dummy     /* 0xffff60: INTTA3 */
    ,_Int_dummy     /* 0xffff64: INTTA4 */
    ,_Int_dummy     /* 0xffff68: INTTA5 */
    ,_Int_dummy     /* 0xffff6c: INTTB00 */
    ,_Int_dummy     /* 0xffff70: INTTB01 */
    ,_Int_dummy     /* 0xffff74: INTTB10 */
    ,_Int_dummy     /* 0xffff78: INTTB11 */
    ,_Int_dummy     /* 0xffff7c: INTTB20 */
    ,_Int_dummy     /* 0xffff80: INTTB21 */
    ,_Int_dummy     /* 0xffff84: INTTB30 */
    ,_Int_dummy     /* 0xffff88: INTTB31 */
    ,_Int_dummy     /* 0xffff8c: INTTB40 */
    ,_Int_dummy     /* 0xffff90: INTTB41 */
    ,_Int_dummy     /* 0xffff94: INTTBOF0 */
    ,_Int_dummy     /* 0xffff98: INTTBOF1 */
    ,_Int_dummy     /* 0xffff9c: INTTBOF2 */
    ,_Int_dummy     /* 0xffffa0: INTTBOF3 */
    ,_Int_dummy     /* 0xffffa4: INTTBOF3 */
    ,_Int_dummy     /* 0xffffa8: INTRX0 */
    ,_Int_dummy     /* 0xffffac: INTTX0 */
    ,_Int_dummy     /* 0xffffb0: INTRX1 */
    ,_Int_dummy     /* 0xffffb4: INTTX1 */
    ,_Int_dummy     /* 0xffffb8: INTRX2 */
    ,_Int_dummy     /* 0xffffbc: INTTX2 */
    ,_Int_dummy     /* 0xffffc0: INTSBI0 */
    ,_Int_dummy     /* 0xffffc4: INTSBI1 */
    ,_Int_dummy     /* 0xffffc8: INTRTC */
    ,_Int_dummy     /* 0xffffcc: INTAD */
    ,_Int_dummy     /* 0xffffd0: INTTC0 */
    ,_Int_dummy     /* 0xffffd4: INTTC1 */
    ,_Int_dummy     /* 0xffffd8: INTTC2 */
    ,_Int_dummy     /* 0xffffdc: INTTC3 */
    };
#pragma section const   /* return to default */

/*-eof-*/
