/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fread.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:06:09 $	*/

#include <stdio.h>

size_t __CDECL fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
	char		*p;
	unsigned int	len;
	unsigned int	ret;

	p = (char *)ptr;
	len = ret = size * nmemb;
	if (len == 0)	return 0;

	*p++ = fgetc(stream);
	--len;
	while(len--)	*p++ = (*stream->in)();
	return ret;
}
