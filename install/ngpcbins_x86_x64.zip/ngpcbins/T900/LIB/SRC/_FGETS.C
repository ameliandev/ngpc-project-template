/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fgets.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:05:45 $	*/

#include <stdio.h>

char * __CDECL fgets(char *s, int n, FILE *stream)
{
	unsigned char c;
	char *sstart = s;

	while (--n > 0) {
		c = fgetc(stream);
		if ((*s = c) != '\n') {
			s++;
			continue;
		}
		s++;
		break;
	}
	*s = 0;
	return sstart;
}
