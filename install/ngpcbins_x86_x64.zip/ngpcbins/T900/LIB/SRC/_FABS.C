/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _fabs.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1995/01/20 21:57:46 $	*/

#include <float.h>
#include <math.h>

double __CDECL fabs(double  x)
{
	if(x>=0.)	return(x);
	else		return(-x);
}
