/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _labs.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:08:21 $	*/

#include <stdlib.h>

long __CDECL labs(long int j) {

	return ((j < 0) ? -j : j);
}
