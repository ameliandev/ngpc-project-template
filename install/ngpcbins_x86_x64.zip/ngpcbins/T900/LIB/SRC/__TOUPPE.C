/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: __touppe.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:02:10 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL _toupper(int c)
{
	return ((c)+('A'-'a'));
}
