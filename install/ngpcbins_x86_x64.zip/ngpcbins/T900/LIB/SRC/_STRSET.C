/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strset.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:13:41 $	*/

#include <string.h>

char * __CDECL strset(char *s, int c)
{
	char *s0 = s;

	while (*s)
		*s++ = (char)c;
	return (s0);
}
