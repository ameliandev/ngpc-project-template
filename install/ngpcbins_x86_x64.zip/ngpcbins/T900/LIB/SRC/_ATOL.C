/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _atol.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:07:41 $	*/

#include <ctype.h>
#include <stdlib.h>

long __CDECL atol(const char *nptr)
{
	long num = 0;
	int c;
	int sign = 0;
	
	while (isspace(*nptr))	++nptr;
	if(*nptr == '-')
		sign = 1,++nptr;
	else if(*nptr == '+')
		++nptr;
	for(;;) {
		c = *nptr++;
		if (isdigit(c))
			num = num*10+(c-'0');
		else
			break;
	}
	return (sign ? -num : num);
}
