/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fwrite.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:06:19 $	*/

#include <stdio.h>

size_t __CDECL fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
	unsigned int	len;
	unsigned int	ret;
	const char *p = ptr;

	len = ret = size * nmemb;
	if (len == 0)	return 0;

	while(len--)	(*stream->out)(*p++);
	return ret;
}
