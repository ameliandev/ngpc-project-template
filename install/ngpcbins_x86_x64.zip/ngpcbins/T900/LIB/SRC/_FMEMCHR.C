/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMEMCHR.C $	*/
/*	$Revision: 1.2.1.4 $	*/
/*	$Date: 1996/02/27 14:38:54 $	*/

#include <string.h>

#if defined(__9000__)
void * __CDECL __fmemchr(const void *s, int c, unsigned long n)
{
const	unsigned char	*p = s;

	while (n--) {
		if (*p == (unsigned char)c)
			return ((void *)p);
		p++;
	}
	return ((void *)NULL);
}

#elif defined(__900__)
void *__fmemchr(const void *s1,int c, unsigned long n) {
	__ASM("		;; @(#)fmemchr.s	1.2 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void *memchr(const void *s1, int c, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; c	:		XSP+8");
	__ASM("		;; n	:		XSP+10");
	__ASM("		;; ");
	__ASM("		ld		XHL,0");
	__ASM("		ld		XBC,(XSP+10)		; n");
	__ASM("		and		XBC,0x00ffffff		; 16M Byte ");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		ld		XHL,(XSP+4)		; s1");
	__ASM("		ld		WA,(XSP+8)		; c");
	__ASM("		ld		DE,QBC");
	__ASM("		inc		1,DE");
	__ASM("		;;");
	__ASM("__Loop:	");
	__ASM("		cpir	A,(XHL+)");
	__ASM("		j		z,__Found");
	__ASM("		djnz	DE,__Loop");
	__ASM("		ld		XHL,0			; return NULL");
	__ASM("		ret");
	__ASM("__Found:	");
	__ASM("		dec		1,XHL			; adjust address");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *__fmemchr(const void *s1,int c, unsigned long n) {
	__ASM("		;; @(#)fmemchr.s    1.1 95/12/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *fmemchr(const void *s1, int c, unsigned long n)");
	__ASM("		;; RET	:		find position or NULL");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; c	:		SP+0x7");
	__ASM("		;; n	:		SP+0x9");
	__ASM("		;; ");
	__ASM("		ld		BC,		(SP+0x9);	");
	__ASM("		ld		DE,		(SP+0xb);	");
	__ASM("		cmp		DE,		0x10	;	");
	__ASM("		j		p,		__SetNull;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		f,		__Init	;	");
	__ASM("		cmp		DE,		0x0		;	");
	__ASM("		j		t,		__SetNull;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		ld		WA,		(SP+0x7);	");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;	");
	__ASM("__ByteComp:");
	__ASM("		cmp		A,		(IY)	;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		inc		IY				;	");
	__ASM("		dec		BC				;	");	
	__ASM("		j		nz,		__ByteComp;	");
	__ASM("		;						;	");
	__ASM("		ld		BC,		0xffff	;	");
	__ASM("		dec		DE				;	");
	__ASM("		j		f,		__ByteComp;	");
	__ASM("		;						;	");
	__ASM("__SetNull:");
	__ASM("		ld		IY,		0x0		;	");
	__ASM("__End:");
	__ASM("		;						;	");
	return (void *)__IY;
}
#endif

