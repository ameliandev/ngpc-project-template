/* Copyright(C) 1995 TOSHIBA CORPORATION  All rights reserved */
/*	$RCSfile: $ */
/*	$Revision: $ */
/*	$Date: $ */


typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;

DBLBIT g_mathtbl[] = {
	{0xff,0xff,0xff,0xff,0xff,0xff,0xef,0x7f},	/* HUGE_VAL */
};

