/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fprintf.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:13:59 $	*/

#include <stdio.h>
#include <stdarg.h>

int __CDECL	_doprnt(const char *fmt, va_list *args, void (*fnc)(int c));

static void __CDECL	_stmOut(int c);

static FILE	*_fp;

int __CDECL fprintf(FILE *stream, const char *format, ...)
{
	va_list		args;

	_fp = stream;
	va_start(args,format);
	return (_doprnt(format, &args, _stmOut));
}

int __CDECL	vfprintf(FILE *stream, const char *format, va_list arg)
{
	_fp = stream;
	return (_doprnt(format, &arg, _stmOut));
}

static void __CDECL	_stmOut(int c)
{
	fputc(c, _fp);
}
