/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _fmod.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:19:52 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL fmod(double x, double y)
{
	int expr1, expr2;
	unsigned short *p;
	double x1, y1, val;
	
	if( y == 0 ) {
		return(1);
	}
	p = (unsigned short*)&y;
	expr2 = (p[3]>>4)&0x07FF;
	if( expr2 > 1022 ) {
		expr2 -= 1022;
	}
	else {
		expr2 = -(1022-expr2);
	}

	x1 = fabs(x);
	y1 = fabs(y);

	p = (unsigned short*)&x1;
	
	while( x1 >= y1 ) {
		expr1 = (p[3]>>4)&0x07ff;
		if( expr1 > 1022 ) {
			expr1 -= 1022;
		}
		else {
			expr1 = -(1022-expr1);
		}
		val = ldexp(y1,expr1-expr2);
		if( x1 >= val ) {		/* val=y*(2^(expr1-expr2))   */
			x1 -= val;
		}
		else {
			x1 -= (val*0.5);
		}
	}
	if( x < 0.0 ) {
		x1 = -x1;
	}
	return ( x1 );
}
