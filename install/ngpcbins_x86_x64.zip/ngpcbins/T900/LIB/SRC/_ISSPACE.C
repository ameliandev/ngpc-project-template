/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _isspace.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:03:42 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL isspace(int c)
{
	return (c == 0x20 || (c>=0x09 && c<=0x0d));
}
