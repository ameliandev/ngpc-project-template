/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _bsearch.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:07:46 $	*/

#include <stdlib.h>

void * __CDECL bsearch(const void *key, const void *base, size_t nmemb, size_t size, int (*compar)(const void *, const void *))
{
	int	low, mid, high ;
	int	ret ;

	if (nmemb) {
		low = 0 ;
		high = nmemb - 1 ;
		while (low <= high) {
			mid = (high + low) >> 1;
			if ((ret = (*compar)(key,(char *)base + mid * size)) < 0) {
				if (mid == 0)	break;
				high = mid -1;
			}
			else if (ret > 0) {
				low = mid + 1;
				if (low == 0)	break;
			}
			else
			return ((char *)base + mid * size);
		}
	}
	return NULL ;
}
