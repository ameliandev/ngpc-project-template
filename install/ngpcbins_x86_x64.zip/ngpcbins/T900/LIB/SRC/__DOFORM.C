/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: __DOFORM.C $	*/
/*	$Revision: 1.4 $	*/
/*	$Date: 1997/02/07 14:41:36 $	*/

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>

static	void __CDECL	_dodigit(char *str, long val);
static	void __CDECL	_doudigit(char *str, unsigned long val);
static	void __CDECL	_doxdigit(char *str, unsigned long val, int cap);
static	void __CDECL	_doodigit(char *str, unsigned long val);

#ifdef FLOAT
char * __CDECL	_facnv( char* dbl, unsigned char* s, int flag, int* e, int* sgn );
static	void __CDECL	_dofloat(char c, void (*fnc)(int c), char* val, int flag, int width, int precision);
static	void __CDECL	_dofloat_f(char c, void (*fnc)(int c), int flag, int width, int precision, char *buf, int expr, int sgn);
static	void __CDECL	_dofloat_e(char c, void (*fnc)(int c), int flag, int width, int precision, char *buf, int expr, int sgn);
static	int __CDECL	_zerochk(char *str);
#endif

#define	PLUS		0x01
#define	MINUS		0x02
#define	BLANK		0x04
#define	SHARP		0x08
#define	PRECISION	0x10
#define	SHORT		0x20
#define	LONG		0x40
#define	LONGDOUBLE	0x80
#define	SIGNED		0x100

#define	ISPLUS(x)	(x & PLUS)
#define	ISMINUS(x)	(x & MINUS)
#define	ISBLANK(x)	(x & BLANK)
#define	ISSHARP(x)	(x & SHARP)
#define	ISPRECISION(x)	(x & PRECISION)
#define	ISSHORT(x)	(x & SHORT)
#define	ISLONG(x)	(x & LONG)
#define	ISLONGDOUBLE(x)	(x & LONGDOUBLE)

static	int	padchar;
static	int	out_cnt;

int __CDECL	_doprnt(const char *fmt,va_list *args,void (*fnc)(int c))
{
	register int	cnt;
	register int	c;
	register int	flag;
	register int	width;
	register int	precision;
	union {
		double a;
		long double b;
	} work;

	cnt = 0;
	while((c = *fmt++) != '\0') {
		if (c != '%') {
			fnc(c);
			cnt++;
			continue;
		}
		flag = precision = width = 0;
		padchar = ' ';
	/* flag set */
flagset:	switch (c = *fmt++) {
		case	' ':
			flag |= BLANK;
			goto	flagset;
		case	'#':
			flag |= SHARP;
			goto	flagset;
		case	'+':
			flag |= PLUS;
			goto	flagset;
		case	'-':
			flag |= MINUS;
			goto	flagset;
		case	'0':
			padchar = '0';
			goto	flagset;
		}
		
	/* width set */
		if (c == '*') {
			if ((width = va_arg(*args,int)) < 0) {
				width = -width;
				flag |= MINUS;
			}
			c = *fmt++;
		}
		else {
			while( isdigit(c) ) {
				width = width * 10 + (c - '0');
				c=*fmt++ ;
			}
		}

	/* precision set */
		if (c == '.') {
			flag |= PRECISION;
			if ((c = *fmt++) == '*') {
				if ((precision = va_arg(*args,int)) < 0) {
					flag &= ~PRECISION;
				}
				c = *fmt++;
			}
			else {
				while( isdigit(c) ) {
					precision = precision * 10 + (c - '0');
					c=*fmt++ ;
				}
			}
		}
	
	/* size set */
		if (c == 'h') {
			flag |= SHORT;
			c = *fmt++;
		}
		else	if (c == 'l') {
			flag |= LONG;
			c = *fmt++;
		}
		else	if (c == 'L') {
			flag |= LONGDOUBLE;
			c = *fmt++;
		}
		
	/* type set & output */
		switch(c) {
		case	'c':
		case	'%':
			if (!ISMINUS(flag)) {
				while((--width) > 0) {
					cnt++;
					fnc(padchar);
				}
			}
			cnt++;
			if (c == 'c')
				fnc(va_arg(*args,int));
			else	fnc('%');
			if (ISMINUS(flag)) {
				while((--width) > 0) {
					cnt++;
					fnc(' ');
				}
			}
			break;
		case	's':
			{
				register char	*str;
				register int	len;
			
				str = va_arg(*args,char *);
				len = strlen(str);
				if (!ISPRECISION(flag) || precision >= len)
					precision = len;
				else	len = precision;
				if (len  > width) {
					width = 0;
					cnt += len;
				}
				else {
					cnt+=width;
					width-=len;
				}
				if (!ISMINUS(flag)) {
					while(width--)	fnc(padchar);
				}
				while (precision--)	fnc(*str++);
				if (ISMINUS(flag)) {
					while(width--)	fnc(' ');
				}
			}
			break;
		case	'd':
		case	'i':
			{
				register int	len,sgn;
				register long	val;
				char		buf[12];

#ifdef	INT_LONG
				val = va_arg(*args,long);
				if(ISSHORT(flag))	val = (short)val;
#else
				if (ISLONG(flag))	val = va_arg(*args,long);
				else	val = va_arg(*args,short);
#endif
				sgn = 0;
				if (ISPRECISION(flag) && precision == 0 && val == 0) {
					buf[0] = '\0';
					len = 0;
				}
				else	{
					_dodigit(buf,val);
					len = strlen(buf);
					if (val < 0)	sgn = 1;
				}
				if (!ISPRECISION(flag) || precision < len)	precision = 0;
				else	precision -= len;
				if (flag & (BLANK | PLUS))	sgn = 1;
				width -= (len + precision + sgn);
				if (width < 0)	width = 0;
				cnt += (width + len + precision + sgn);
				if(width && !ISMINUS(flag) && (padchar == ' ' || ISPRECISION(flag))) {
					while (width--)	fnc(' ');
					width = 0;
				}
				if (val < 0)	fnc('-');
				else	{
					if (ISPLUS(flag))	fnc('+');
					else if (ISBLANK(flag))	fnc(' ');
				}
				if (!ISMINUS(flag) && padchar == '0') {
					while (width--)	fnc('0');
				}
				while (precision--)	fnc('0');
				while (len)	fnc(buf[--len]);
				if (ISMINUS(flag)) {
					while (width--)	fnc(' ');
				}
			}
			break;
		case	'u':
			{
				register int	len;
				register long	val;
				char		buf[12];
			
#ifdef	INT_LONG
				val = va_arg(*args,unsigned long);
				if(ISSHORT(flag))	val = (unsigned short)val;
#else
				if (ISLONG(flag))	val = va_arg(*args,unsigned long);
				else	val = va_arg(*args,unsigned short);
#endif
				if (ISPRECISION(flag) && precision == 0 && val == 0) {
					buf[0] = '\0';
					len = 0;
				}
				else {
					_doudigit(buf,val);
					len = strlen(buf);
				}
				if (!ISPRECISION(flag) || precision < len)	precision = 0;
				else	precision -= len;
				width -= (len + precision);
				if (width < 0)	width = 0;
				cnt += (width + len + precision);
				if (!ISMINUS(flag)) {
					while (width--)	fnc(padchar);
				}
				while (precision--)	fnc('0');
				while (len)	fnc(buf[--len]);
				if (ISMINUS(flag)) {
					while (width--)	fnc(' ');
				}
			}
			break;
		case	'p':
			flag |= LONG;
		case	'x':
		case	'X':
			{
				register int	tlen;
				register int	len;
				register long	val;
				char		buf[12];
			
#ifdef	INT_LONG
				val = va_arg(*args,unsigned long);
				if (ISSHORT(flag))	val = (unsigned short)val;
#else
				if (ISLONG(flag))	val = va_arg(*args,unsigned long);
				else	val = va_arg(*args,unsigned short);
#endif
				if (ISPRECISION(flag) && precision == 0 && val == 0) {
					buf[0] = '\0';
					len = 0;
				}
				else	{
					_doxdigit(buf,val,c);
					len = strlen(buf);
				}
				if (!ISPRECISION(flag) || precision < len)	precision = 0;
				else	precision -= len;
				if (ISSHARP(flag))	tlen = 2;
				else	tlen = 0;
				width -= (len + precision + tlen);
				if (width < 0)	width = 0;
				cnt += (width + len + precision + tlen);
				if (!ISMINUS(flag) && padchar == ' ') {
					while (width--)	fnc(' ');
				}
				if (tlen && len) {
					fnc('0');
					fnc(c);
				}
				if (!ISMINUS(flag) && padchar == '0') {
					while (width--)	fnc('0');
				}
				while (precision--)	fnc('0');
				while (len)	fnc(buf[--len]);
				if (ISMINUS(flag)) {
					while (width--)	fnc(' ');
				}
			}
			break;
		case	'o':
			{
				register int	tlen;
				register int	len;
				register long	val;
				char		buf[12];
			
#ifdef	INT_LONG
				val = va_arg(*args,unsigned long);
				if (ISSHORT(flag))	val = (unsigned short)val;
#else
				if (ISLONG(flag))	val = va_arg(*args,unsigned long);
				else	val = va_arg(*args,unsigned short);
#endif
				if (ISPRECISION(flag) && precision == 0 && val == 0) {
					buf[0] = '\0';
					len = 0;
				}
				else	{
					_doodigit(buf,val);
					len = strlen(buf);
				}
				if (!ISPRECISION(flag) || precision < len)	precision = 0;
				else	precision -= len;
				if (ISSHARP(flag))	tlen = 1;
				else	tlen = 0;
				width -= (len + precision + tlen);
				if (width < 0)	width = 0;
				cnt += (width + len + precision + tlen);
				if (!ISMINUS(flag) && padchar == ' ') {
					while (width--)	fnc(' ');
				}
				if (tlen && len)	fnc('0');
				if (!ISMINUS(flag) && padchar == '0') {
					while (width--)	fnc('0');
				}
				while (precision--)	fnc('0');
				while (len)	fnc(buf[--len]);
				if (ISMINUS(flag)) {
					while (width--)	fnc(' ');
				}
			}
			break;
		case	'n':
			{
				void *p;

				p = va_arg(*args,int*);

#ifdef	INT_LONG
				if (ISSHORT(flag))	*(short *)p = cnt;
				else	*(long *)p = cnt;
#else
				if (ISLONG(flag))	*(long *)p = cnt;
				else	*(short *)p = cnt;
#endif
			}
			break;
		case	'f':
		case	'e':
		case	'E':
		case	'g':
		case	'G':
#ifdef	FLOAT
			if(ISLONGDOUBLE(flag))	work.b=va_arg(*args,long double);
			else	work.a=(double) va_arg(*args,double);
			_dofloat((char)c, fnc, (char*)&work, flag, width, precision);
			cnt+=out_cnt;
#endif
			break;
		}
	}
	return (cnt);
}

static	void __CDECL	_dodigit(char *str, long val)
{
	register unsigned long	uval;
	
	uval = (val < 0 ? -val : val);
	do {
		*str++ = (char)((uval % 10L) + '0');
		uval /= 10L;
	} while (uval);
	*str = '\0';
}

static	void __CDECL	_doudigit(char *str, unsigned long val)
{
	do {
		*str++ = (char)((val % 10) + '0');
		val /= 10;
	} while (val);
	*str = '\0';
}

static	void __CDECL	_doxdigit(char *str, unsigned long val, int cap)
{
	register char	*ch;
	
	if (cap == 'x')
		ch = "0123456789abcdef";
	else	ch = "0123456789ABCDEF";
	do {
		*str++ = ch[(val % 16)];
		val /= 16;
	} while (val);
	*str = '\0';
}

static	void __CDECL	_doodigit(char *str, unsigned long val)
{
	do {
		*str++ = (char)((val % 8) + '0');
		val /= 8;
	} while (val);
	*str = '\0';
}

#ifdef	FLOAT
static	void __CDECL	_dofloat(char c, void (*fnc)(int c), char* val, int flag, int width, int precision)
{
	char	buf[21];
	int	sgn, expr=0;
	_facnv(val, (unsigned char*)buf, flag, &expr, &sgn);
	out_cnt=0;
	if (c == 'e' || c == 'E') {
		_dofloat_e(c, fnc, flag, width, precision, buf, expr, sgn);
	}
	else if (c == 'f' || c == 'F') {
		_dofloat_f(c, fnc, flag, width, precision, buf, expr, sgn);
	}
	else {
		if (!ISPRECISION(flag)) {
			precision = 6;
			flag |= PRECISION;
		}
		if ((expr <= -4) || (expr > precision)) {
			_dofloat_e(c,fnc,flag,width,precision,buf,expr,sgn);
		}
		else {
			_dofloat_f(c,fnc,flag,width,precision,buf,expr,sgn);
		}
	}
}

static	void __CDECL	_dofloat_f(char c, void (*fnc)(int c), int flag, int width, int precision, char *buf, int expr, int sgn)
{
	int	i;
	int	intsz;
	int	seido=15;

	if (expr < 1)	intsz = 0;
	else	intsz = expr;
	
	if (!ISPRECISION(flag))	precision = 6;
	if (ISLONGDOUBLE(flag))	seido=18;
	
	if (toupper(c) == 'G')	i = precision;
	else	i = precision + expr;
	if (i < (seido+1) && buf[i] > '4' && i >= 0) {
		i--;
		buf[i]++;
		while (i > 0 && buf[i] > '9') {
			buf[i] = '0';
			i--;
			buf[i]++;
		}
	}
	if (toupper(c) == 'G') {
		i = precision-1;
		precision += -expr;
	}
	if (toupper(c) == 'G' && !ISSHARP(flag) ) {
		for(; buf[i]=='0'; i--,precision--) ;
	}
	if (!ISPRECISION(flag) || precision)	width--;
	if (sgn || (flag & (BLANK | PLUS)))	width--;
	width -= (intsz + precision);
	if (buf[0] > '9')	width--;
	if (width < 0)	width = 0;
	if (ISMINUS(flag) == 0 && padchar == ' ') {
#if 1	/* 1997/02/05 */
		if (expr < 1)	width--;
#endif
		while (width-- > 0) {
			fnc(' ');
			out_cnt++;
		}
	}
	if (sgn) {
		fnc('-');
		out_cnt++;
	}
	else {
		if (ISPLUS(flag)) {
			fnc('+');
			out_cnt++;
		}
		else if (ISBLANK(flag)) {
			fnc(' ');
			out_cnt++;
		}
	}
	if (!ISMINUS(flag) && padchar == '0') {
#if 1	/* 1997/02/05 */
		if (expr < 1)	width--;
#endif
		while (width-- > 0) {
			fnc('0');
			out_cnt++;
		}
	}
	if (buf[0] > '9' && expr >= 0 ) {
		fnc('1');
		buf[0] = '0';
		out_cnt++;
	}
        else if ( expr <= 0 ) {
		fnc('0');
		out_cnt++;
	}
	for(i=0; i < (seido+1) && intsz-- > 0;i++) {
		fnc(buf[i]);
		out_cnt++;
	}
	while(intsz-- > 0) {
		fnc('0');
		out_cnt++;
	}
	if (ISSHARP(flag) || precision ) {
		fnc('.');
		out_cnt++;
	}
	for (; expr < 0 && precision-- ;expr++) {
		if( expr+1 == 0 && buf[0] > '9' ) {
			fnc('1');
			buf[0] = '0';
		}
		else	fnc('0');
		out_cnt++;
	}
	if (i < (seido+1) ) {
		for(; i < (seido+1) && precision-- > 0;i++) {
			fnc(buf[i]);
			out_cnt++;
		}
	}
	while (precision-- > 0) {
		fnc('0');
		out_cnt++;
	}
	if (ISMINUS(flag)) {
#if 1	/* 1997/02/05 */
		if (expr < 1)	width--;
#endif
		while (width-- > 0) {
			fnc(' ');
			out_cnt++;
		}
	}
}

static	int __CDECL	_zerochk(char *str)
{
	while (*str) {
		if (*str++ != '0')	return (0);
	}
	return (1);
}

static	void __CDECL	_dofloat_e(char c, void (*fnc)(int c), int flag, int width, int precision, char *buf, int expr, int sgn)
{
	register int	i;
	int	len;
	int	seido=15;

	if (!ISPRECISION(flag))	precision = 6;
	
	if (toupper(c) == 'G' && precision ) {		/* Round	*/
		precision--;
	}
	i = precision + 1;
	if (ISLONGDOUBLE(flag))	seido=18;
	if (i < (seido+1) && buf[i--] > '4') {
		buf[i]++;
		while (i > 0 && buf[i] > '9') {
			buf[i] = '0';
			buf[--i]++;
		}
	}
	if (toupper(c) == 'G' && !ISSHARP(flag)) {
		for(i=precision; i > 0 && buf[i] == '0'; i--,precision--) ;
	}
	
	width -= 5;
	if (!ISPRECISION(flag) || precision)	width--;
	if (sgn || (flag & (BLANK | PLUS)))	width--;
	width -= precision;
	if (width < 0)	width = 0;
	
	if (!ISMINUS(flag) && padchar == ' ') {
		while (--width > 0) {
			fnc(' ');
			out_cnt++;
		}
	}
	
	if (sgn) {
		fnc('-');
		out_cnt++;
	}
	else {
		if (ISPLUS(flag)) {
			fnc('+');
			out_cnt++;
		}
		else if (ISBLANK(flag)) {
			fnc(' ');
			out_cnt++;
		}
	}
	
	if (!ISMINUS(flag) && padchar == '0') {
		while (--width > 0) {
			fnc('0');
			out_cnt++;
		}
	}
	if (buf[0] > '9') {
		fnc('1');
		buf[0] = '0';
		i = 0;
		out_cnt++;
#if 0	/* 1997/02/06 */
		(expr < 0 ? expr++ : expr--);
#else
		expr++;
#endif
	}
	else {
		fnc(buf[0]);
		out_cnt++;
		i = 1;
	}
	if (precision || ISSHARP(flag)) {
		fnc('.');
		out_cnt++;
	}
	if (toupper(c) == 'G' && !precision && expr==1 )	return;
	if (i < (seido+1) ) {
		for(; i < (seido+1) && precision-- > 0;i++) {
			fnc(buf[i]);
			out_cnt++;
		}
	}
	while (precision-- > 0) {
		fnc('0');
		out_cnt++;
	}
	
	_dodigit(buf,(long)--expr );
	len = strlen(buf);
	if (toupper(c) == 'G') {
		fnc(c - 2);
		out_cnt++;
	}
	else {
		fnc(c);
		out_cnt++;
	}
	if (expr < 0) {
		fnc('-');
		out_cnt++;
	}
	else {
		fnc('+');
		out_cnt++;
	}
	i = len;
	while(i++ < 3) {
		fnc('0');
		out_cnt++;
	}
	while(len) {
		fnc(buf[--len]);
		out_cnt++;
	}
	if (ISMINUS(flag)) {
		while (--width > 0) {
			fnc(' ');
			out_cnt++;
		}
	}
}
#endif
