/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _ltoa.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:08:43 $	*/

#include <stdlib.h>

char * __CDECL ltoa(long val, char *s, int radix)
{
	if (radix == 10 && val < 0) {
		s[0] = '-';
		return ((ultoa(-val, s+1, radix)) - 1);
	}
	else	return (ultoa(val, s, radix));
}
