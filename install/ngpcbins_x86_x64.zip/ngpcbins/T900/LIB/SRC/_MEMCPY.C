/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MEMCPY.C $	*/
/*	$Revision: 1.3.1.3 $	*/
/*	$Date: 1996/02/27 14:41:41 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
void * __CDECL memcpy(void *s1, const void *s2, size_t n)
{
	void *s = s1;
	unsigned char	*p1 = s1;
const	unsigned char	*p2 = s2;


	while (n--) {
		*p1++ = *p2++;
	}
	return (s);
}
#elif defined(__900__)
void *memcpy(void *s1, void *s2, size_t n) {
	__ASM("		;; @(#)memcpy.s	1.1 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void *memcpy(void *s1, void *s2, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;;");
	__ASM("		ld		BC,(XSP+12)");
	__ASM("		ld		XHL,(XSP+4)");
	__ASM("		cp		BC,0");
	__ASM("		ret		z");
	__ASM("		;;");
	__ASM("		ld		XIX,XHL			; s1");
	__ASM("		ld		XIY,(XSP+8)		; s2");
	__ASM("		cp		XIX,XIY");
	__ASM("		ret		eq");
	__ASM("		;;");
	__ASM("		bit		0,IX			; address check");
	__ASM("		j		z,__Skip");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		ret		nov			; BC == 0");
	__ASM("__Skip:");
	__ASM("		srl		1,BC			; /= 2 & set B0 to C-flag");
	__ASM("		jr		z,__ByteCopy");
	__ASM("		ldirw	(XIX+),(XIY+)");
	__ASM("__ByteCopy:");
	__ASM("		ret		nc");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif defined(__90__)
void *memcpy(void *s1, void *s2, size_t n) {
	__ASM("		;; @(#)memcpy.s	1.1 95/12/11");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; void *memcpy(void *s1, void *s2, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x2");
	__ASM("		;; s2	:		SP+0x4");
	__ASM("		;; n	:		SP+0x6");
	__ASM("		;;");
	__ASM("		ld		BC,(SP+0x6)		; n");
	__ASM("		ld		HL,BC");
	__ASM("		cp		HL,0");
	__ASM("		ld		HL,(SP+0x2)		; return s1");
	__ASM("		ret		z			; n==0 ?");
	__ASM("		;;");
	__ASM("		ld		DE,(SP+0x4)		; s2");
	__ASM("		cp		HL,DE");
	__ASM("		ret		eq			; s1==s2 ?");
	__ASM("		;;");
	__ASM("		ld		IX,HL			; s1");
	__ASM("		ex		DE,HL			; s2<->s1");
	__ASM("		ldir");
	__ASM("		ld		HL,IX			; return s1");
	__ASM("		;; ret");
	return (void *)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *memcpy(void *s1, void *s2, size_t n) {
	__ASM("		;; @(#)memcpy.s	1.1 95/12/01");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *memcpy(void *s1, void *s2, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;;	");
	__ASM("		ld		WA,		(SP+0xa);	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("		ld		IY,		(SP+0x7);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("		;						;	");
	__ASM("__ByteCpy:");
	__ASM("		ld		C,		(IY)	;	");
	__ASM("		ld		(IX),	C		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("__Div2:");
	__ASM("		shrc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("__WordCpy:");
	__ASM("		ld		BC,		(IY)	;	");
	__ASM("		ld		(IX),	BC		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordCpy;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#elif defined(__870X__)
void *memcpy(void *s1, void *s2, size_t n) {
	__ASM("		;; @(#)memcpy.s	1.1 95/11/29");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *memcpy(void *s1, void *s2, size_t n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x6");
	__ASM("		;; s2	:		SP+0x8");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;;");
	__ASM("		push	HL				;	");
	__ASM("		ld		WA,		(SP+0xa);	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("		ld		DE,		(SP+0x8);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Init	;	");
	__ASM("		;						;	");
	__ASM("__ByteCopy:");
	__ASM("		ld		(HL),	(DE)	;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		DE				;	");
	__ASM("__Init:");
	__ASM("		shrc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordCopy:");
	__ASM("		ld		(HL),	(DE)	;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		DE				;	");
	__ASM("		ld		(HL),	(DE)	;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		DE				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordCopy;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		BC,		(SP+0x6);	");
	__ASM("		pop		HL				;	");
	__ASM("		;						;ret");
	return (void *)__BC;
}
#endif
