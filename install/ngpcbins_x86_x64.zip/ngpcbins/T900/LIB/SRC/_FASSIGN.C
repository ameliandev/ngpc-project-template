/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fassign.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:05:18 $	*/

#include <stdio.h>


void __CDECL fassign(FILE *stream, unsigned char (*in)(void), void (*out)(unsigned char c))
{
	stream->flag = 0;
	stream->in = in;
	stream->out = out;
}
