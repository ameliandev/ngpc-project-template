/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _abs.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:07:30 $	*/

#include <stdlib.h>

int __CDECL abs(int j)
{
	return ((j < 0) ? -j : j);
}
