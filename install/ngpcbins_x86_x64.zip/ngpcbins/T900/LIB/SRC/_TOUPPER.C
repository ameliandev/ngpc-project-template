/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _toupper.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:04:39 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL toupper(int c)
{
	return ((islower(c))?(c)+('A'-'a'):(c));
}
