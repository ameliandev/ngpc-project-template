/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _free.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1995/01/20 17:03:16 $	*/

#include <stdlib.h>

struct	free_list {
	struct	free_list *free_addr ;
	unsigned	free_size ;
} ;

#define	FLSIZE	(sizeof(struct free_list))

extern	struct	free_list *_allocb ;

void __CDECL free(void *ptr)
{
	struct free_list *cp,*pp,*fp;

	if(!ptr)
		return;
	fp = (struct free_list*)ptr ;
	--fp ;
	if (!_allocb) {
		fp->free_addr = NULL ;
		_allocb = fp ;
		return ;
	}
	for (pp = cp = _allocb ; cp ; pp = cp, cp = cp->free_addr)
		if (fp <= cp)
			break ;
	if (fp == cp)
		return ;
	if (cp == _allocb) {
		if ((struct free_list*) (fp + FLSIZE + fp->free_size) == _allocb) {
			fp->free_addr = _allocb->free_addr ;
			fp->free_size += _allocb->free_size + FLSIZE ;
		}
		else	fp->free_addr = _allocb ;
		_allocb = fp ;
		return ;
	}
	if (cp && ((struct free_list*) (fp + FLSIZE + fp->free_size)) == cp) {
		fp->free_addr = cp->free_addr ;
		fp->free_size += cp->free_size + FLSIZE ;
	}
	else	fp->free_addr = cp ;

	if ((struct free_list*) ( pp + FLSIZE + pp->free_size) == fp) {
		pp->free_addr = fp->free_addr ;
		pp->free_size += fp->free_size + FLSIZE ;
	}
	else	pp->free_addr = fp ;
}
