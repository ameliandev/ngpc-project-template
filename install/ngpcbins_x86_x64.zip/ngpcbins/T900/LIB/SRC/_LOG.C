/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _log.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:23:56 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define SQRT2	1.41421356237309504000

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static DBLBIT	s_logtbl={0xcd,0x3b,0x7f,0x66,0x9e,0xa0,0xf6,0x3f} ;

#define	SQRT2	s_logtbl.val

#endif

double __CDECL log(double x)
{
	int	i, nptr;
	double	x2, s, last;

	if(x<=0.0) {
		errno=EDOM;
		return(0.);
	}
	frexp(x/SQRT2,&nptr);
	x /= ldexp(1,nptr);
	x = (x-1) / (x+1);
	x2 = x * x;
	i = 1;
	s = x;
	do {
		x *= x2;
		i += 2;
		last = s;
		s += x/i;
	}
	while( last != s );
	return( LN2*nptr+2*s );
}
