/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _STRTOD.C $	*/
/*	$Revision: 1.3 $	*/
/*	$Date: 1996/12/25 10:10:22 $	*/

#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <errno.h>
#include <locale.h>

#ifdef FLOAT
char __CDECL	_afcnv(int (*fnc)(), int prec, char *val, int width);
#endif

static void __CDECL	_setstrchar(char *s);
static int __CDECL	_getstrchar(void);

static char	*str_p;
static char _ovflw_dble[]={ 0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

double __CDECL strtod(const char* str, char **endptr)
{
	unsigned int* p;
	union {
		double x;
		unsigned char xx[8];
	} val;
	char *bak_ptr,chk_ch;

	bak_ptr = (char *)str;
        while (isspace(*str))	str++;
	chk_ch = *str;
	if(!isdigit(chk_ch) && chk_ch!='+' && chk_ch!='-' && chk_ch!='.') {
#if 1	/* 1996/12/24 */
		if(endptr) {
#else
		if(*endptr) {
#endif
			*endptr = bak_ptr;
			return (double)0.0;
		}
	}
        _setstrchar((char *)str);
        _afcnv(_getstrchar, 8, (char*)&val.x, -1);
#if 1	/* 1996/12/24 */
	if(endptr)
#endif
	*endptr = str_p-1;
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
	p = (unsigned int*)&val.xx[6];
#else
	p = (unsigned int*)&val.xx[0];
#endif
	if (!memcmp(val.xx, &_ovflw_dble, sizeof(double))) {	/* underflow */
		errno = ERANGE;
		val.x = 0.0;
	}
	else if ((*p&0x7fff)>>4 > 0x07fe) {
		errno = ERANGE;
		if (*p&0x8000)	val.x=-HUGE_VAL;
		else	val.x = HUGE_VAL;
	}
        return (val.x);
}

static void __CDECL	_setstrchar(char *s)
{
        str_p = s ;
}

static int __CDECL	_getstrchar(void)
{
	return ((int)*str_p++);
}
