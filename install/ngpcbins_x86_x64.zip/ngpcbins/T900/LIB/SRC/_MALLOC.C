/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MALLOC.C $	*/
/*	$Revision: 1.1.1.3 $	*/
/*	$Date: 1996/02/27 14:21:45 $	*/

#include <stdlib.h>

#if defined (__9000__) || defined (__900__) || (defined(__870X__) && defined(__LARGE__))
char *__adecl	sbrk(unsigned long);
#else
char *__adecl	sbrk(unsigned int);
#endif

struct	free_list {
	struct	free_list *free_addr;
	unsigned	free_size;
};

#define	FLSIZE	(sizeof(struct free_list))

extern struct	free_list *_allocb;		/* declare startup routine */

void *__CDECL	malloc(size_t allocsz)
{
	struct	free_list	*pp, *cp, *np;
	size_t	size;

#ifndef __BYTE_ALIGN__
	size = (size_t)((allocsz+1)/2)*2;
#else
	size = allocsz;
#endif
	for (pp = _allocb ; pp ; cp = pp, pp = pp->free_addr) {
		if (pp->free_size >= size)
			break;
	}

	if (pp) {
		if ((pp->free_size - size) >= (FLSIZE + 4)) {
			np = (struct free_list *) (((char *) pp) + FLSIZE + size);
			np->free_addr = pp->free_addr;
			np->free_size = pp->free_size - FLSIZE - size;
			pp->free_addr = np;
			pp->free_size = size;
		}
		if (pp == _allocb)
			_allocb = pp->free_addr;
		else	cp->free_addr = pp->free_addr;
	}
	else	{
		if ((pp = (struct free_list *) sbrk(size + FLSIZE)) == (struct free_list *) -1)
			return ((void *)NULL);
		pp->free_addr = NULL;
		pp->free_size = size;
	}
	return	((void *) ++pp);
}
