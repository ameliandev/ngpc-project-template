/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _frexp.c $	*/
/*	$Revision: 1.1.1.2 $	*/
/*	$Date: 1995/01/31 17:50:15 $	*/

#include <float.h>
#include <math.h>

double __CDECL frexp(double x,int *nptr)
{
	union {
		double  d;
		unsigned char c[8];
		unsigned short nn1[4];
	} d;
	int	i;
	unsigned short nn;

	d.d=x;
	*nptr=0;
	if(x==0.)	return(x);
	nn=((unsigned short)(d.c[7] & 0x7f) << 4) + ((unsigned short)(d.c[6] & 0xf0) >> 4);
	*nptr = nn - 1022 ;
	if(*nptr>0)	{ for(i=0;i<*nptr;i++)  nn--; } 
	else		{ for(i=0;i>*nptr;i--)  nn++; } 
	nn = nn << 4;
	nn |= d.c[6] & 0x0f;
	if(d.c[7]&0x80)		nn |= 0x8000;
	d.nn1[3] = nn;
	
	return(d.d);
}
