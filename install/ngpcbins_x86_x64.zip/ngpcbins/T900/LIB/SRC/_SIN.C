/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _sin.c $	*/
/*	$Revision: 1.2.1.1 $	*/
/*	$Date: 1995/01/31 21:30:48 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL _trig(double x, double y, int sign );

double __CDECL sin(double x)
{
	if (x < 0.0) {
		return( _trig(x,-x,1) );
	}
	else {
		return( _trig(x,x,0) );
	}
}
