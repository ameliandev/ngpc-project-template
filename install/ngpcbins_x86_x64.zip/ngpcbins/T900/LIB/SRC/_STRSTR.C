/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strstr.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:13:52 $	*/

#include <string.h>

char * __CDECL strstr(const char *s1,const char *s2)
{
	size_t len1,len2;
	char c = *s2;

	len1 = strlen(s1);
	len2 = strlen(s2);
	if (!len2)	return ((char *)s1);
	while (len2 <= len1) {
		if (c == *s1)
	    		if (memcmp((const void *)s2, (const void *)s1, len2) == 0)
				return ((char *)s1);
		++s1;
		--len1;
	}
	return (NULL);
}
