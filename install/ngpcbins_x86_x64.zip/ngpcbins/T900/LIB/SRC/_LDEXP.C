/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _ldexp.c $	*/
/*	$Revision: 1.1.1.3 $	*/
/*	$Date: 1995/01/31 17:51:23 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL ldexp(double x, int nptr)
{
	union {
		double  d ;
		unsigned char c[8] ;
		unsigned short nn1[4];
	} d;
	int	i;
	unsigned short nn;

	d.d=x;
	if( x == 0 ) {
		return(0);
	}
	if(nptr>2047) {
		errno=ERANGE ;
		if( d.c[7]&0x80 ) {
			return(-HUGE_VAL);
		}
		return(HUGE_VAL);
	}
	if(nptr<-2047) {
		return(0.);
	}
	nn=((short)(d.c[7] & 0x7f) << 4) + ((short)(d.c[6] & 0xf0) >> 4);
	if(nptr>0) {
		for(i=0;i<nptr;i++) {
			if( nn+1 >= 2047 ) {
				errno=ERANGE;
				if( d.c[7]&0x80 ) {
					return(-HUGE_VAL);
				}
				return(HUGE_VAL);
			}
			nn++;
		}
	}
	else {
		for(i=0;i>nptr;i--) {
			if( nn-1 == 0 ) {
				errno=ERANGE;
				return(0.);
			}
			nn--;
		}
	} 

	nn = nn << 4;
	nn |= d.c[6] & 0x0f;
	if(d.c[7]&0x80)		nn |= 0x8000;
	d.nn1[3] = nn;

	return(d.d);
}
