/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _exp.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:20:35 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL exp(double  x)
{
	int	i;
	double	xx, ret=1.0, pret;

	if(x==0.0)	return(ret);
	xx = 1.0;
	if( x>LN_DBLMAX ) {
		errno=ERANGE;
		return(HUGE_VAL);
	}
	if( x<LN_DBLMIN ) {
		return(0.0);
	}
	for(i=1; i<=LOP; i++){
		pret=ret;
		xx  *= x /i;
		ret += xx;
		if( pret==ret ) break;
	}
	return(ret);
}
