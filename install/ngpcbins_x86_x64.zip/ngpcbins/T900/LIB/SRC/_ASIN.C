/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _asin.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:18:24 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL asin(double  x)
{
	if(fabs(x)>1.0)		{ errno=EDOM; return(0.); }
	if(x==0.0)		return(x);
	if(fabs(x)==1.0)	return(x*PAI5);

	return( atan( x/sqrt(1-(x*x)) ) );
}
