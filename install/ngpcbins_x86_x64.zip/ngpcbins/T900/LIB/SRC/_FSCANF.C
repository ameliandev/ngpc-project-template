/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fscanf.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:13:39 $	*/

#include <stdio.h>
#include <stdarg.h>

int __CDECL	_doscan(const char *fmt, va_list args, int (*fnc)(void), void (*ungetfnc)(int c));

static int __CDECL	_getstmchar(void);
static void __CDECL	_ungetstmchar(int c);

static FILE	*scn_fp;

int __CDECL	fscanf(FILE *stream, const char *format, ...)
{
	va_list	args;

	scn_fp = stream;
	
	va_start(args, format) ;
	return (_doscan(format, args,  _getstmchar, _ungetstmchar)) ;
}

static int __CDECL	_getstmchar(void)
{
	return(fgetc(scn_fp)) ;
}

static void __CDECL	_ungetstmchar(int c)
{
	ungetc(c, scn_fp) ;
}
