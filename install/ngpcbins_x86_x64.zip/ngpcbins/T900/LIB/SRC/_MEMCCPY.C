/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _MEMCCPY.C $	*/
/*	$Revision: 1.3.1.1 $	*/
/*	$Date: 1996/01/19 20:04:17 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
void * __CDECL memccpy(void *s1, const void *s2, int c, size_t n)
{
	unsigned char c0;
	unsigned char *p1 = s1;
const	unsigned char *p2 = s2;

	while (n--) {
		c0 = *p1++ = *p2++;
		if ((unsigned char)c == c0)
			return ((void *)p1);
	}
	return (NULL);
}
#elif defined(__900__) || defined(__870X__)
void *memccpy(void *s1,const void *s2, int c, size_t n) {
	unsigned char *pos;

	pos = (unsigned char *)memchr(s2,c,n);
	if(pos==NULL) {
		memcpy(s1,s2,n);
	}
	else {
		size_t nn;
		nn = pos - (unsigned char *)s2 + 1;
		memcpy(s1,s2,nn);
	}
	return (void *)pos;
}
#endif

#if defined(__90__)
void *memccpy(void *s1,const void *s2, int c, size_t n) {
	__ASM("		;; @(#)memccpy.s	1.2 95/12/25");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; void *memccpy(void *s1,const void *s2, int c, size_t n)");
	__ASM("		;; RET	:		find position or NULL");
	__ASM("		;; s1	:		SP+0x2");
	__ASM("		;; s2	:		SP+0x4");
	__ASM("		;; c	:		SP+0x6");
	__ASM("		;; n	:		SP+0x8");
	__ASM("		;; ");
	__ASM("		ld		DE,(SP+0x4)		; s2");
	__ASM("		ld		BC,(SP+0x6)		; c");
	__ASM("		ld		IX,(SP+0x8)		; n");
	__ASM("		push		IX			; n");
	__ASM("		push		BC			; c");
	__ASM("		push		DE			; s2");
	__ASM("		cal		_memchr");
	__ASM("		lda		SP,SP+0x6");
	__ASM("		ld		IY,HL			; return pos");
	__ASM("		cp		HL,0");
	__ASM("		j		ne,__MCCPY1		; pos!=NULL ?");
	__ASM("		push		IX			; n");
	__ASM("		j		__MCCPY2");
	__ASM("__MCCPY1:					; pos!=NULL");
	__ASM("		sub		HL,DE			; pos-s2");
	__ASM("		inc		HL			; pos-s2+1");
	__ASM("		push		HL			; nn");
	__ASM("__MCCPY2:");
	__ASM("		push		DE			; s2");
	__ASM("		ld		BC,(SP+0x6)		; s1");
	__ASM("		push		BC			; s1");
	__ASM("		cal		_memcpy");
	__ASM("		lda		SP,SP+0x6");
	__ASM("		ld		HL,IY			; return pos");
	__ASM("		;; ret");
	return (void *)__HL;
}
#endif
