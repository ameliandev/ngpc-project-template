/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _acos.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:18:41 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

double __CDECL acos(double  x)
{
	double  ret ;

	if(fabs(x)>1.0)		{ errno=EDOM; return(0.); }
	if(x==1.0)		return(0.);

	ret = PAI5 - asin(x);
	return(ret);
}
