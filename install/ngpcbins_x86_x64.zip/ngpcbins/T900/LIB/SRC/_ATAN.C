/*      Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: _atan.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:18:04 $	*/

#include <float.h>
#include <math.h>
#include <errno.h>

#define N 20

double __CDECL atan(double  x)
{
	int	i;
	int	sign;
	double	val;
	
	if( x==0.0 ) {
		return(0.0);
	}
	if( x*x==-1.0 ) {
		errno=EDOM;
		return(0.0);
	}
	if( x > 1 ) {
		sign = 1;
		x = 1 / x;
	}
	else if( x < -1 ) {
		sign = -1;
		x = 1 / x;
	}
	else {
		sign = 0;
	}
	val = 0 ;
	for( i=N; i>=1; i--) {
		val = ( i * i * x * x ) / ( 2 * i + 1 + val );
	}
	if( sign > 0 ) {
		return( (PAI/2) - x/(1+val) );
	}
	if( sign < 0 ) {
		return( (-PAI/2) - x/(1+val) );
	}
	return( x/(1+val) );
}
