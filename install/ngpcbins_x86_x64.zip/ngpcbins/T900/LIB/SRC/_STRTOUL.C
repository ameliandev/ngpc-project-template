/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strtoul.c $	*/
/*	$Revision: 1.2 $	*/
/*	$Date: 1995/01/31 13:24:57 $	*/

#include <stdlib.h>
#include <ctype.h>
#include <errno.h>

unsigned long __CDECL strtoul(const char *nptr, char **endptr, int base)
{
	unsigned long val,old;
	int over = 0;
	int c;
	char *bak_ptr,chk_ch,stop_alpha;

	bak_ptr = (char *)nptr;
	while (isspace(*nptr))	++nptr;
	if(base < 0 || base > 36) {
NOT:
		if(*endptr) {
			*endptr = bak_ptr;
			return (long)0;
		}
	}
	chk_ch = *nptr;
	if(isalpha(chk_ch)) {
		if(base < 11) goto NOT;
		stop_alpha = 'A' + (base -11);
		if(toupper(chk_ch) > stop_alpha)
			goto NOT;
	}
	else if(!isdigit(chk_ch) && chk_ch!='+' && chk_ch!='-')	goto NOT;
	if (*nptr == '+')	++nptr;
	if (base == 0) {
		base = 10;
		if (*nptr == '0') {
			++nptr,base = 8;
			if (*nptr == 'X' || *nptr == 'x')
				++nptr,base = 16;
			}
		}
	else if (base == 16 && nptr[0] == '0' && (nptr[1] == 'x' || nptr[1] == 'X'))
		nptr += 2;
	for (val=0,old=0;;old=val) {
		c = *nptr++;
		if (c == '\0')	break;
		if (isdigit(c))	c = c - '0';
		else if (islower(c))	c = c - 'a' + 10;
		else if (isupper(c))	c = c - 'A' + 10;
		else	break;
		if (c >= base)	break;
		val = val*base;
		if (val < old)	over = 1;
		val += c;
	}
	if (over)	val = 0xffffffff,errno = ERANGE;
	if (endptr)	*endptr = (void *)(nptr-1);
	return (val);
}
