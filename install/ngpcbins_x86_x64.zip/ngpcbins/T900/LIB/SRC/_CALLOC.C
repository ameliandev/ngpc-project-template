/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _calloc.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1995/01/20 17:02:47 $	*/

#include <stdlib.h>
#include <string.h>

void* __CDECL calloc(size_t nmemb, size_t size)
{
	void *ptr;

	if (!nmemb || !size)	return (NULL);
	ptr = malloc(nmemb * size);
	if (ptr)	memset(ptr, '\0', nmemb * size);
	return (ptr) ;
}
