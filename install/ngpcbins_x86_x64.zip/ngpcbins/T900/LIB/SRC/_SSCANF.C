/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _sscanf.c $	*/
/*	$Revision: 1.1.1.3 $	*/
/*	$Date: 1995/01/24 19:03:27 $	*/

#include <stdio.h>
#include <stdarg.h>

int __CDECL	_doscan(const char *fmt, va_list args, int (*fnc)(void), void (*ungetfnc)(int c));

static void __CDECL	_setstrchar(char *s);
static int __CDECL	_getstrchar(void);
static void __CDECL	_ungetstrchar(int c);

static char	*str_p;

int __CDECL	sscanf(const char *s, const char *format, ...)
{
	va_list	args;

        str_p = (char *)s;
	va_start(args, format);
	return (_doscan(format, args, _getstrchar, _ungetstrchar));
}

static void __CDECL	_setstrchar(char *s)
{
        str_p = s ;
}

static int __CDECL	_getstrchar(void)
{
	return ((int)*str_p++);
}

static void __CDECL	_ungetstrchar(int c)
{
/*	*--str_p = (char)c;	*/
	--str_p;
}
