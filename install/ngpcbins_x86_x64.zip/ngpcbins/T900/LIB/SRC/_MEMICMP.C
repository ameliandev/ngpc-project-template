/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _memicmp.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:10:31 $	*/

#include <ctype.h>
#include <string.h>

int __CDECL memicmp(void *s1, void *s2, size_t n)
{
	int		diff;
	unsigned char	*p1 = (unsigned char *)s1;
	unsigned char	*p2 = (unsigned char *)s2;

	while (n--) {
		diff = (int)toupper(*p1) - (int)toupper(*p2);
		if (diff) {
			return (diff);
		}
		p1++;
		p2++;
	}
	return (0);
}
