/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMCCPY.C $	*/
/*	$Revision: 1.2.1.4 $	*/
/*	$Date: 1996/02/27 14:39:18 $	*/

#include <string.h>

#if defined(__9000__)
void * __CDECL __fmemccpy(void *s1,const void *s2, int c, unsigned long n)
{
	unsigned char c0;
	unsigned char *p1 = s1;
const	unsigned char *p2 = s2;

	while (n--) {
		c0 = *p1++ = *p2++;
		if ((unsigned char)c == c0)
			return ((void *)p1);
	}
	return ((void *)NULL);
}

#elif defined(__900__) || (defined(__870X__) && defined(__LARGE__))
void *__fmemccpy(void *s1,const void *s2, int c, unsigned long n) {
	unsigned char *pos;

	pos = (unsigned char *)__fmemchr(s2,c,n);
	if(pos==NULL) {
		__fmemcpy(s1,s2,n);
		}
	else {
		unsigned long nn;
		nn = pos - (unsigned char *)s2 + 1;
		__fmemcpy(s1,s2,nn);
		}
	return s1;
}
#endif
