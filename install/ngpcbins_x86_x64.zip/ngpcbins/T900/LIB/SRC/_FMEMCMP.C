/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMEMCMP.C $	*/
/*	$Revision: 1.2.1.3 $	*/
/*	$Date: 1996/02/27 14:38:32 $	*/

#include <string.h>

#if defined(__9000__)
int __CDECL __fmemcmp(const void *s1, const void *s2, unsigned long n)
{
	char	*cS1,*cS2;

	if(!n)
		return 0;
	cS1 = (char *)s1;
	cS2 = (char *)s2;
	/* odd ? */
	if(n & 1) {
		int diff;

		if((diff=(int)*cS1 - (int)*cS2))
			return diff;
		*cS1++; *cS2++;
	}
	/* div 2 */
	if( (n >>= 1) ) {
		do {
			int diff;

			diff=(int)*cS1 - (int)*cS2;
			if(diff)
				return diff;
			cS1++; cS2++;
			diff=(int)*cS1 - (int)*cS2;
			if(diff)
				return diff;
			cS1++; cS2++;
		}while(--n);
	}
	return (0);
}
#elif defined(__900__)
int __fmemcmp(const void *s1,const void *s2,unsigned long n) {
	__ASM("		;; @(#)fmemcmp.s	1.2 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; int __fmemcmp(const void *s1,const void *s2,unsigned long n)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;; ");
	__ASM("		ld		XBC,(XSP+12)		; n");
	__ASM("		ld		HL,0");
	__ASM("		and		XBC,0x00ffffff");
	__ASM("		ret		z			; check size");
	__ASM("		;; ");
	__ASM("		ld		XIX,(XSP+4)		; s1");
	__ASM("		ld		XIY,(XSP+8)		; s2");
	__ASM("		cp		XIX,XIY");
	__ASM("		ret		eq");
	__ASM("		ld		DE,IX");
	__ASM("		neg		DE");
	__ASM("		and		DE,0x3			; check address");
	__ASM("		jr		z,__MAIN");
	__ASM("		;; ");
	__ASM("__ByteCmp:		");
	__ASM("		ld		L,(XIX+)");
	__ASM("		sub		L,(XIY+)");
	__ASM("		exts	HL");
	__ASM("		ret		nz			; *s1 != *s2");
	__ASM("		sub		XBC,1");
	__ASM("		ret		z			; end ?");
	__ASM("		djnz	DE,__ByteCmp");
	__ASM("__MAIN:");
	__ASM("		ld		DE,BC");
	__ASM("		srl		2,XBC			; / 4");
	__ASM("		jr		z,__SkipLong");
	__ASM("		inc		1,QBC");
	__ASM("__LongCmp:");
	__ASM("		ld		XHL,(XIX+)");
	__ASM("		ld		XWA,(XIY+)");
	__ASM("		sub		HL,WA");
	__ASM("		ret		nz");
	__ASM("		ld		HL,QHL");
	__ASM("		sub		HL,QWA");
	__ASM("		ret		nz");
	__ASM("		djnz	BC,__LongCmp");
	__ASM("		djnz	QBC,__LongCmp");
	__ASM("		;;");
	__ASM("__SkipLong:		");
	__ASM("		and		DE,0x3");
	__ASM("		ret		z		");
	__ASM("__ByteCmp2:");
	__ASM("		ld		L,(XIX+)");
	__ASM("		sub		L,(XIY+)");
	__ASM("		exts	HL");
	__ASM("		ret		nz			; *s1 != *s2");
	__ASM("		djnz	DE,__ByteCmp2");
	__ASM("		;; ret");
	return (int)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
int __fmemcmp(const void *s1,const void *s2,unsigned long n) {
	__ASM("		;; @(#)fmemcmp.s	1.1 95/12/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; int __fmemcmp(const void *s1,const void *s2,unsigned long n)");
	__ASM("		;; RET	:		int");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;; ");
	__ASM("		ld		DE,		(SP+0xa);	");
	__ASM("		ld		HL,		(SP+0xc);	");
	__ASM("		cmp		HL,		0x10	;	");
	__ASM("		j		p,		__End	;	");
	__ASM("		cmp		DE,		0x0		;	");
	__ASM("		j		f,		__Init	;	");
	__ASM("		cmp		HL,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		ld		BC,		0x0		;	");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		ld		IX,		(SP+0x7);	");
	__ASM("		test	E.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("		;						;	");
	__ASM("__ByteCmp:");
	__ASM("		ld		A,		(IX)	;	");
	__ASM("		xor		A,		(IY)	;	");
	__ASM("		j		f,		__Calc	;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		;						;	");
	__ASM("__Div2:");
	__ASM("		shrc	H				;	");
	__ASM("		rorc	L				;	");
	__ASM("		rorc	D				;	");
	__ASM("		rorc	E				;	");
	__ASM("		cmp		DE,		0x0		;	");
	__ASM("		j		f,		__WordCmp;	");
	__ASM("		cmp		HL,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordCmp:");
	__ASM("		ld		WA,		(IX)	;	");
	__ASM("		xor		WA,		(IY)	;	");
	__ASM("		j		f,		__Chk	;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		DE				;	");
	__ASM("		j		nz,		__WordCmp;	");
	__ASM("		;						;	");
	__ASM("		ld		DE,		0xffff	;	");
	__ASM("		dec		HL				;	");
	__ASM("		j		f,		__WordCmp;	");
	__ASM("		j		__End			;	");
	__ASM("		;						;	");
	__ASM("__Chk:");
	__ASM("		cmp		A,		0x0		;	");
	__ASM("		j		f,		__Calc	;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IY				;	");
	__ASM("__Calc:");
	__ASM("		sext	BC,		(IY)	;	");
	__ASM("		sext	WA,		(IX)	;	");
	__ASM("		sub		BC,		WA		;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		;						;ret");
	return (int)__BC;
}
#endif
