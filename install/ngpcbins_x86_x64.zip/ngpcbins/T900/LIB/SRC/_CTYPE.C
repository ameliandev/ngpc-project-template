/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _ctype.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:02:17 $	*/

#include	<ctype.h>

const char _ctype[256] =
{
	__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,
	__CTL,__CTL|__SPC,__CTL|__SPC,__CTL|__SPC,__CTL|__SPC,__CTL|__SPC,__CTL,__CTL,
	__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,
	__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,__CTL,
	__SPC|__BLK,__PNC,__PNC,__PNC,__PNC,__PNC,__PNC,__PNC,
	__PNC,__PNC,__PNC,__PNC,__PNC,__PNC,__PNC,__PNC,
	__DIG|__HEX,__DIG|__HEX,__DIG|__HEX,__DIG|__HEX,__DIG|__HEX,__DIG|__HEX,__DIG|__HEX,__DIG|__HEX,
	__DIG|__HEX,__DIG|__HEX,__PNC,__PNC,__PNC,__PNC,__PNC,__PNC,
	__PNC,__UC|__HEX,__UC|__HEX,__UC|__HEX,__UC|__HEX,__UC|__HEX,__UC|__HEX,__UC,
	__UC,__UC,__UC,__UC,__UC,__UC,__UC,__UC,
	__UC,__UC,__UC,__UC,__UC,__UC,__UC,__UC,
	__UC,__UC,__UC,__PNC,__PNC,__PNC,__PNC,__PNC,
	__PNC,__LC|__HEX,__LC|__HEX,__LC|__HEX,__LC|__HEX,__LC|__HEX,__LC|__HEX,__LC,
	__LC,__LC,__LC,__LC,__LC,__LC,__LC,__LC,
	__LC,__LC,__LC,__LC,__LC,__LC,__LC,__LC,
	__LC,__LC,__LC,__PNC,__PNC,__PNC,__PNC,__CTL
};
