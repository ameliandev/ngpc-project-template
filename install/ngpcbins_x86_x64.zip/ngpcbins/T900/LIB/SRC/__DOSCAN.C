/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: __DOSCAN.C $	*/
/*	$Revision: 1.3 $	*/
/*	$Date: 1996/07/17 16:41:14 $	*/

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

static int __CDECL	_todigit(char ch,int base);

#ifdef FLOAT
char __CDECL	_afcnv(int (*fnc)(), int prec, char *val, int width);
#endif


#define	SHORT		0x1
#define	LONG		0x2
#define	LONG_DBL	0x4
#define	OMIT		0x8
#define	WIDTH		0x10
#define	SIGNED		0x20
#define	MINUS		0x40
#define	CARET		0x80
#define	FARP		0x100

#define EOT	0
#define	FALSE	0

#define	ISSHORT(x)	(x & SHORT)
#define	ISLONG(x)	(x & LONG)
#define	ISLONG_DBL(x)	(x & LONG_DBL)
#define	ISOMIT(x)	(x & OMIT)
#define	ISWIDTH(x)	(x & WIDTH)
#define	ISSIGNED(x)	(x & SIGNED)
#define	ISMINUS(x)	(x & MINUS)
#define	ISCARET(x)	(x & CARET)
#define	ISFARP(x)	(x & FARP)

static char		buffer[256];

int __CDECL	_doscan(const char *fmt,va_list args,int (*fnc)(void),void (*ungetfnc)(int c))
{
	int	cnt;
	int	len;
#if	1	/* '96-7-17 updated for sscanf bug */
	int	beflen;
#endif
	register int	c,ch;
	register int	flag;
	register int	width;
	
	cnt = 0;
	len = 0;
	flag = FALSE;
	while(c = (int)*fmt++) {
	        if (isspace(c)) {
			while (isspace(*fmt))	fmt++;
			ch = (*fnc)();
			while (isspace(ch)) {
				ch = (*fnc)();
				len++;
			}
			if (ch == EOT)	return (EOT);
			(*ungetfnc)(ch);
			len--;
			continue;
		}
		width = flag = 0;
		if (c != '%') {
			if ((ch = (*fnc)()) == c) {
				++len;
				continue;
			}
			else {
				if (ch == EOT)
					return (EOT);
				(*ungetfnc)(ch);
				len--;
				return cnt;
			}
		}
	/* Assign flag set */
		if (*fmt == '*') {
			flag |= OMIT;
			fmt++;
		}
	/* Width set */
		if (isdigit(*fmt)) {
			c = *fmt++;
			flag |= WIDTH;
			while(isdigit(c)) {
				width = width * 10 + (c - '0');
				c = *fmt++;
			}
			fmt--;
		}
		else	width--;
	/* size set */
                if (*fmt == 'l') { /* check for double precision */
                	fmt++;
                	flag |= LONG;
                }
                else if (*fmt == 'h') {
			fmt++;
			flag |= SHORT;
		}
                else if (*fmt == 'L') {
			fmt++;
			flag |= LONG_DBL;
		}
		if (width == 0) {
                	fmt++;
                	continue;
                }
	/* type check */
		switch(c = *fmt++) {
		case	'i':
		case	'd':
		case	'u':
		case	'o':
		case	'x':
		case	'X':
		case	'p':
			{
				register int	base;
				register int	val;
				register union	{
					long	       lg;
					unsigned long ulg;
				} dat;
			
				switch (c) {
				case	'i':
				case	'd':
					flag |= SIGNED;
				case	'u':
					base = 10;
					break;
				case	'o':
					base = 8;
					break;
				case	'x':
				case	'X':
				case	'p':
					base = 16;
#if defined (__9000__) || defined (__900__) || (defined(__870X__) && defined(__LARGE__))
					if (c=='p') {
#if defined (__9000__) || defined (__900__)
						flag |= LONG;		/* pointer size is 32 */
#else
						flag |= FARP;
#endif
						flag &= ~SIGNED;	/* unsign */
					}
#endif
					break;
				}
				ch = (*fnc)();
				while (isspace(ch)) {
					ch = (*fnc)();
					len++;
				}
				++len;
				if (ch == EOT)	return (EOT);
				if (width && (ch == '+' || ch == '-')) {
					if (ch == '-')	flag |= MINUS;
					width--;
					ch = (*fnc)() ,++len;
				}
				if (c != 'u' && c != 'd' && c != 'o') {
					if (ch == '0') {
						if (c == 'i')	base = 8;
						width--;
						ch = (*fnc)(),++len;
						if (width && (ch == 'x' || ch == 'X')){
							if (c == 'i') {
								width--;
								base = 16;
								ch = (*fnc)(),++len;
							}
							else	if (c == 'x' || c == 'X') {
								width--;
								ch = (*fnc)(),++len;
							}
							else	if (c != 'x') {
								(*ungetfnc)(ch);
								len--;
								width++;
								ch = 0;
							}
						}
					}
				}
				dat.lg = 0;
#if	1	/* '96-7-17 updated for sscanf bug */
				beflen = len - 1;
#endif
				while (width--) {
					val = _todigit((char)ch,base);
					if (val == (-1))	break;
					if (ISSIGNED(flag))	dat.lg	= dat.lg * base + val;
					else	dat.ulg = dat.ulg * base + val;
					ch = (*fnc)() ,++len;
				}
				(*ungetfnc)(ch);
				len--;
				if (ISMINUS(flag))	dat.lg = -dat.lg;
				if (!ISOMIT(flag)) {
#ifdef	INT_LONG
					if (ISSHORT(flag)) {
						if (ISSIGNED(flag))	dat.lg = (short)dat.lg;
						else	dat.ulg = (unsigned short)dat.ulg;
						*(va_arg(args, short  *)) = dat.lg;
					}
					else	*(va_arg(args, long  *)) = dat.lg;
#else
					if (ISSHORT(flag))	*(va_arg(args, short *)) = (short)dat.lg;
#if	defined(__870X__) && defined(__LARGE__)
					else if (ISFARP(flag))	*(va_arg(args, void **)) = (void *)dat.lg;
#endif
					else if (ISLONG(flag))	*(va_arg(args, long  *)) = dat.lg;
					else *(va_arg(args, int   *)) = (int)dat.lg;
#endif

#if	0	/* '96-7-17 deleted for sscanf bug */
					cnt++;
#else		/* '96-7-17 updated for sscanf bug */
					if (beflen != len) cnt++;
#endif
				}
			}
			break;
		case	'f':
		case	'e':
		case	'E':
		case	'g':
		case	'G':
#ifdef	FLOAT
			{
				double	vald;
				long double valld;
				float	valf;
			
				ch = (*fnc)();
				while (isspace(ch)) {
					ch = (*fnc)();
					len++;
				}
				++len;
				if (ch == EOT)	return (EOT);
				(*ungetfnc)(ch);
				len--;
				if (ISLONG(flag)) {
					ch = _afcnv(fnc,8,(char*)&vald,width);
					if (!ISOMIT(flag) )	*(va_arg(args, double *)) = vald;
				}
				else if (ISLONG_DBL(flag)) {
					ch = _afcnv(fnc,10,(char*)&valld,width);
					if (!ISOMIT(flag))	*(va_arg(args, long double *)) = valld;
				}
				else 	{
					ch = _afcnv(fnc,4,(char*)&valf,width);
					if (!ISOMIT(flag))	*(va_arg(args, float *)) = valf;
				}
				(*ungetfnc)(ch);
				len--;
				cnt++;
			}
#endif
			break;
		case	's':
			{
				register char	*str;
				
				ch = (*fnc)();
				while (isspace(ch)) {
					ch = (*fnc)();
					len++;
				}
				++len;
				if (ch == EOT)	return (EOT);
				str = va_arg(args, char*);
				while (!isspace(ch) && ch != EOT && width--) {
					if (!ISOMIT(flag))	*str++ = ch;
					ch = (*fnc)();
					++len;
				}
				(*ungetfnc)(ch);
				len--;
				if (!ISOMIT(flag)) {
					*str = '\0';
					cnt++;
				}
			}
			break;
		case	'c':
			{
				register char *str;
				
				if (!ISWIDTH(flag))	width = 1;
				str = va_arg(args, char*);
				while(width--) {
					ch = (*fnc)() ,++len;
					if (ch == EOT)	return (EOT);
					if (!ISOMIT(flag))	*str++ = ch;
				}
				if (!ISOMIT(flag))	cnt++;
			}
			break;
		case	'%':
			ch = (*fnc)() ,++len;
			if (ch == EOT)	return (EOT);
			if (ch != '%')	return (cnt);
			break;
		case	'[':
			{
				register char	*str,*p;
				register int	i;
				register int	s;
				register char	h;
				register char	c;
				
				s=0;
				h=0;
				if (*fmt == '^') {
					flag |= CARET;
					fmt++;
				}
				i = 0;
				while (i < 255) {
					c = *fmt++;
					if (c == ']' && i > 0) {
						buffer[i] = '\0';
						break;
					}
					if (c == '-' && h<*fmt ) {
						while( h!=*fmt && i<255 )	buffer[i++] = ++h;
						c = *fmt;
					}
					buffer[i++] = c;
					h = c;
				}
				str = va_arg(args, char*);
				for(;width;) {
					ch = (*fnc)(),++len;
					if (ch == EOT) break;
					p = strchr(buffer,ch);
					if (ISCARET(flag)) {
						if(p == NULL && !s)	goto PUT_STR;
						else	s=1;
					}
					else {
						if(p != NULL) {
PUT_STR:
							if (!ISOMIT(flag) && !s)	*str++ = ch;
							width--;
						}
						else	s=1;
					}
				}
				(*ungetfnc)(ch);
				len--;
				if (!ISOMIT(flag)) {
					*str = '\0';
					cnt++;
				}
			}
			break ;
		case 'n':
			{
				void *p;

				p = va_arg(args,int*);
				if (ISOMIT(flag))	break;
#ifdef  INT_LONG
				if (ISSHORT(flag))	*(short *)p = len;
				else	*(long *)p = len;
#else
				if (ISLONG(flag))	*(long *)p = len;
				else	*(short *)p = len;
#endif
				++cnt;
			}
			break;
		}
	}
	return (cnt);
}

static int __CDECL	_todigit(char ch,int base)
{
	int	n;
	
	if (isdigit(ch))	n = ch - '0';
	else if (isxdigit(ch))	n = toupper(ch) - 'A' + 10;
	else	return (-1);
	if (n < base)	return n;
	return (-1);
}
