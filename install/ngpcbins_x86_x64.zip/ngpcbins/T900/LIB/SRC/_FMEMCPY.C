/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _FMEMCPY.C $	*/
/*	$Revision: 1.2.1.3 $	*/
/*	$Date: 1996/02/27 14:37:59 $	*/
#include <string.h>

#if defined(__9000__)
void * __CDECL __fmemcpy(void *s1, const void *s2, unsigned long n)
{
	void *s = s1;
	unsigned char	*p1 = s1;
const	unsigned char	*p2 = s2;


	while (n--) {
		*p1++ = *p2++;
	}
	return (s);
}

#elif	defined(__900__)
void *__fmemcpy(void *s1, void *s2, unsigned long n) {
	__ASM("		;; @(#)fmemcpy.s	1.2 95/07/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Tsukahara");
	__ASM("		;; ");
	__ASM("		;; void *__fmemcpy(void *s1, void *s2, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		XSP+4");
	__ASM("		;; s2	:		XSP+8");
	__ASM("		;; n	:		XSP+12");
	__ASM("		;; ");
	__ASM("		ld		XBC,(XSP+12)");
	__ASM("		ld		XHL,(XSP+4)");
	__ASM("		and		XBC,0x00ffffff	; 16M Byte");
	__ASM("		ret		z");
	__ASM("		;;");
	__ASM("		ld		XIX,XHL			; s1");
	__ASM("		ld		XIY,(XSP+8)		; s2");
	__ASM("		cp		XIX,XIY");
	__ASM("		ret		eq");
	__ASM("		;;");
	__ASM("		bit		0,IX			; address check");
	__ASM("		j		z,__Skip");
	__ASM("		ld		A,(XIY+)");
	__ASM("		ld		(XIX+),A");
	__ASM("		sub		XBC,1");
	__ASM("		ret		z			; XBC == 0");
	__ASM("__Skip:");
	__ASM("		srl		1,XBC			; /= 2 & set B0 to C-flag");
	__ASM("		jr		z,__ByteCopy");
	__ASM("		ld		DE,QBC");
	__ASM("		inc		1,DE");
	__ASM("__WordCopy:		");
	__ASM("		ldirw	(XIX+),(XIY+)");
	__ASM("		djnz	DE,__WordCopy");
	__ASM("__ByteCopy:");
	__ASM("		ret		nc");
	__ASM("		ldib	(XIX+),(XIY+)");
	__ASM("		;; ret");
	return (void *)__XHL;
}
#elif (defined(__870X__) && defined(__LARGE__))
void *__fmemcpy(void *s1, void *s2, unsigned long n) {
	__ASM("		;; @(#)fmemcpy.s	1.1 95/12/13");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;; ");
	__ASM("		;; void *__fmemcpy(void *s1, void *s2, unsigned long n)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x4");
	__ASM("		;; s2	:		SP+0x7");
	__ASM("		;; n	:		SP+0xa");
	__ASM("		;; ");
	__ASM("		ld		WA,		(SP+0xa);	");
	__ASM("		ld		BC,		(SP+0xc);	");
	__ASM("		cmp		BC,		0x10	;	");
	__ASM("		j		p,		__End	;	");
	__ASM("		cmp		WA,		0x0		;	");	
	__ASM("		j		f,		__Init	;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__Init:");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("		ld		IY,		(SP+0x7);	");
	__ASM("		test	A.0				;	");
	__ASM("		j		t,		__Div2	;	");
	__ASM("		;						;	");
	__ASM("__ByteCpy:");
	__ASM("		ld		E,		(IY)	;	");
	__ASM("		ld		(IX),	E		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("__Div2:");
	__ASM("		shrc	B				;	");
	__ASM("		rorc	C				;	");
	__ASM("		rorc	W				;	");
	__ASM("		rorc	A				;	");
	__ASM("		cmp		WA,		0x0		;	");
	__ASM("		j		f,		__WordCpy;	");
	__ASM("		cmp		BC,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		;						;	");
	__ASM("__WordCpy:");
	__ASM("		ld		DE,		(IY)	;	");
	__ASM("		ld		(IX),	DE		;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IY				;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IX				;	");
	__ASM("		dec		WA				;	");
	__ASM("		j		nz,		__WordCpy;	");
	__ASM("		;						;	");
	__ASM("		ld		WA,		0xffff	;	");
	__ASM("		dec		BC				;	");
	__ASM("		j		f,		__WordCpy;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return (void *)__IY;
}
#endif
