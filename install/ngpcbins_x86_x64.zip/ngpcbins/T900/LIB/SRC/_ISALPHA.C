/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _isalpha.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:02:47 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL isalpha(int c)
{
	return ((c>='a' && c<='z') ||
		(c>='A' && c<='Z'));
}
