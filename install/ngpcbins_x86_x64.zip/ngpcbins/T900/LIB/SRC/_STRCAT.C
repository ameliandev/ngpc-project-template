/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strcat.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:11:22 $	*/

#include <string.h>

char * __CDECL strcat(char *s1, const char *s2)
{
	char *s = s1;

	while (*s1) s1++;
	while (*s2) *s1++ = *s2++;
	*s1 = (char)0;
	return (s);
}
