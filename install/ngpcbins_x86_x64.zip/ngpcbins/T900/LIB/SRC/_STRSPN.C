/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strspn.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:13:48 $	*/

#include <string.h>

size_t __CDECL strspn(const char *s1, const char *s2)
{
	const char *s;
	size_t len;

	for (len = 0; *s1; ++s1, ++len) {
		for (s = s2; *s; ++s)
			if (*s1 == *s)
				break;
		if (*s == 0)
			break;
	}
	return (len);
}
