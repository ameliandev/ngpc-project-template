/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strnicm.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:12:47 $	*/

#include <ctype.h>
#include <string.h>

int __CDECL strnicmp(const char *s1, const char *s2, size_t n)
{
	char c1, c2;

	c1 = c2 = 0;
	while (n--) {
		c1 = toupper(*s1);
		s1++;
		c2 = toupper(*s2);
		s2++;
		if (!c1 || (c1 != c2))	break;
	}
	return (c1 - c2);
}
