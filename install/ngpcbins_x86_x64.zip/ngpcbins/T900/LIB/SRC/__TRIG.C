/*      Copyright(C) 1995 TOSHIBA Corporation All Rights Reseved        */
/*	$RCSfile: $ */
/*	$Revision: $ */
/*	$Date: $ */

#include <float.h>
#include <math.h>
#include <errno.h>

#ifdef UDE_CC	/* using UDE C compiler floating fixed number convert */

#define S1 1.66666666666666650520E-001
#define S2 8.33333333333316503140E-003
#define S3 1.98412698412018404570E-004
#define S4 2.75573192101527561190E-006
#define S5 2.50521067982745845440E-008
#define S6 1.60589364903715891140E-010
#define S7 7.64291780689104677340E-013
#define S8 2.72047909578888461750E-015
#define D  8.90891020676154224850E-006
#define C1 0.31830988618379067154
#define C2 3.1416015625
#define C3 2.3283E-010

#else		/* floating fixed number bit pattern definition */

#ifndef __FLOAT_H
typedef union {
	unsigned char dat[8];
	double	val;
} DBLBIT;
#endif

static DBLBIT s_trigtbl[]={
	{0x55,0x55,0x55,0x55,0x55,0x55,0xc5,0x3f},	/* S1 */
	{0xb0,0x10,0x11,0x11,0x11,0x11,0x81,0x3f},	/* S2 */
	{0x1a,0x3e,0x01,0x1a,0xa0,0x01,0x2a,0x3f},	/* S3 */
	{0x63,0xf0,0x24,0xa5,0xe3,0x1d,0xc7,0x3e},	/* S4 */
	{0xab,0xc0,0x5d,0x4b,0x45,0xe6,0x5a,0x3e},	/* S5 */
	{0x30,0xd4,0x6a,0x68,0x3c,0x12,0xe6,0x3d},	/* S6 */
	{0x9c,0x49,0x08,0xdc,0x20,0xe4,0x6a,0x3d},	/* S7 */
	{0x95,0xdf,0x93,0x69,0xff,0x80,0xe8,0x3c},	/* S8 */
	{0xa0,0xe5,0x9e,0x4b,0xef,0xae,0xe2,0x3e},	/* D  */
	{0x83,0xc8,0xc9,0x6d,0x30,0x5f,0xd4,0x3f},	/* C1 */
	{0x00,0x00,0x00,0x00,0x00,0x22,0x09,0x40},	/* C2 */
	{0x44,0xd1,0xd5,0x33,0xfa,0xff,0xef,0x3d}	/* C3 */
};

#define	S1	s_trigtbl[0].val
#define S2	s_trigtbl[1].val
#define S3	s_trigtbl[2].val
#define S4	s_trigtbl[3].val
#define S5	s_trigtbl[4].val
#define S6	s_trigtbl[5].val
#define S7	s_trigtbl[6].val
#define S8	s_trigtbl[7].val
#define D	s_trigtbl[8].val
#define C1	s_trigtbl[9].val
#define C2	s_trigtbl[10].val
#define C3	s_trigtbl[11].val

#endif

double __CDECL _trig(double x, double y, int sign)
{
	unsigned short* p ;
	double f, xn, g;

	p=(unsigned short*)&x;
#if defined (__9000__) || defined (__900__) || defined (__870__) || defined (__870X__) || defined (__90__)
	if(LMTPOW<=(p[3]&0x7ff0)) {
#else
	if(LMTPOW<=(p[0]&0x7ff0)) {
#endif
		errno=ERANGE;		/* TLOSS error */
		return(0.0);
	}
	if (modf(y * C1, &xn) >= 0.5)
		++xn;
	if ((int)xn & 1)
		sign = !sign;
	if (fabs(x) != y)
		xn -= 0.5;
	g = modf(fabs(x), &x);
	f = ((x - xn*C2) + g) - xn * -D ;
	if (fabs(f) > C3) {
		g = f*f;
		f = (((((((S8*g-S7)*g+S6)*g-S5)*g+S4)*g-S3)*g+S2)*g-S1)*g*f+f;
	}
	if (sign) {
		f = -f;
	}
	
	return( f );
}
