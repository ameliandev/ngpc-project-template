/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _sprintf.c $	*/
/*	$Revision: 1.1.1.1 $	*/
/*	$Date: 1995/01/24 16:13:20 $	*/

#include <stdio.h>
#include <stdarg.h>

int __CDECL	_doprnt(const char *fmt, va_list *args, void (*fnc)(int c));

static	void	_strOut(int c);

static char *_str;

int __CDECL	sprintf(char *s, const char *format, ...)
{
	va_list		args ;
	
	_str = s ;
	_str[0] = '\0';
	va_start(args, format) ;
	return (_doprnt(format, &args, _strOut)) ;
}

int __CDECL	vsprintf(char *s, const char *format, va_list arg)
{
	_str = s ;
	s[0] = '\0';
	return (_doprnt(format, &arg, _strOut)) ;
}

static	void __CDECL	_strOut(int c)
{
	*_str++ = c ;
	*_str	= '\0' ;
}
