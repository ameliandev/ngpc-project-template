/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strchr.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:11:28 $	*/

#include <string.h>

char * __CDECL strchr(const char *s, int c)
{
	do {
		if (*s == (char)c) return ((char *)s);
	} while (*s++);
	return (NULL);
}
