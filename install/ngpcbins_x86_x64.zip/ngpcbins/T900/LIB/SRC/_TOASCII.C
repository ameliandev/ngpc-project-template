/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _toascii.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:04:27 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL toascii(int c)
{
	return ((isascii(c))?(c):((c) & 0x7f));
}
