/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _fputc.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:05:58 $	*/

#include <stdio.h>

int __CDECL fputc(int c, FILE *stream)
{
	(*stream->out)((char)c);
	return c;
}
