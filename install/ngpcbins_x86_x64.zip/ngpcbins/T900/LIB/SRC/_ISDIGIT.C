/*	Copyright(C) 1994 TOSHIBA CORPORATION All rights reserved	*/
/*	$RCSfile: _isdigit.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:03:05 $	*/

#define	__CTYPE_FNC

#include <ctype.h>

int __CDECL isdigit(int c)
{
	return (c>='0' && c<='9');
}
