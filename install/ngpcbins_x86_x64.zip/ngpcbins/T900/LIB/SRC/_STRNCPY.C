/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _strncpy.c $	*/
/*	$Revision: 1.1 $	*/
/*	$Date: 1994/12/05 12:12:41 $	*/

#include <string.h>

char * __CDECL strncpy(char *s1, const char *s2, size_t n)
{
	void *s = s1;

	while (n > 0 && *s2) {
		*s1++ = *s2++;
		n--;
	}
	while(n > 0) {
		*s1 = (char)0;
		s1++;
		n--;
	}
	return (s);
}
