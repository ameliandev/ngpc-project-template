/*	Copyright(C) 1994 TOSHIBA Corporation All Rights Reseved	*/
/*	$RCSfile: _STRCPY.C $	*/
/*	$Revision: 1.3.1.2 $	*/
/*	$Date: 1996/02/27 14:44:14 $	*/

#include <string.h>

#if defined(__9000__) || defined(__870__)
char * __CDECL strcpy(char *s1, const char *s2)
{
	void *s = s1;

	while (*s2) *s1++ = *s2++;
	*s1 = (char)0;
	return (s);
}
#elif defined(__900__)
char * __CDECL strcpy(char *s1,const char *s2) {
	unsigned char *endPtr;

	endPtr = 
		(unsigned char *)memccpy((void *)s1,(const void *)s2,0x0,0xfffe);
	if(endPtr == NULL)
		*((unsigned char *)(s1)+0xffff)=0x00;
	return s1;
}
#elif defined(__90__)
char * __CDECL strcpy(char *s1,const char *s2) {
	__ASM("		;; @(#)strcpy.s	1.2 95/12/25");
	__ASM("		;; (C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By H.Hokao");
	__ASM("		;; ");
	__ASM("		;; char * __CDECL strcpy(char *s1,const char *s2)");
	__ASM("		;; RET	:		s1");
	__ASM("		;; s1	:		SP+0x2");
	__ASM("		;; s2	:		SP+0x4");
	__ASM("		;; ");
	__ASM("		ld		BC,0xfffe");
	__ASM("		push		BC");
	__ASM("		ld		BC,0");
	__ASM("		push		BC");
	__ASM("		ld		BC,(SP+0x8)		; s2");
	__ASM("		push		BC			; s2");
	__ASM("		ld		BC,(SP+0x8)		; s1");
	__ASM("		push		BC			; s1");
	__ASM("		cal		_memccpy");
	__ASM("		lda		SP,SP+0x8");
	__ASM("		cp		HL,0");
	__ASM("		j		ne,__SCPY		; endPtr != NULL ?");
	__ASM("		ld		HL,(SP+0x2)		; s1");
	__ASM("		add		HL,0xffff		; s1+0xffff");
	__ASM("		ld		(HL),0");
	__ASM("__SCPY:");
	__ASM("		ld		HL,(SP+0x2)		; return s1");
	__ASM("		;; ret");
	return (void *)__HL;
}
#elif (defined(__870X__) && defined(__LARGE__))
char * __CDECL strcpy(char *s1, const char *s2) {
	__ASM("		;;	@(#)strcpy.s 1.1 95/12/19");
	__ASM("		;;	(C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;;	");
	__ASM("		;;	char * __CDECL strcpy(char *s1, const char *s2)");
	__ASM("		;;	RET	:		s1");
	__ASM("		;;	s1	:		SP+0x4");
	__ASM("		;;	s2	:		SP+0x7");
	__ASM("		;;	");
	__ASM("		ld		IX,		(SP+0x4);	");
	__ASM("		ld		IY,		(SP+0x7);	");
	__ASM("__ByteCpy:");
	__ASM("		ld		A,		(IY)	;	");
	__ASM("		ld		(IX),	A		;	");
	__ASM("		cmp		A,		0x0		;	");
	__ASM("		j		t,		__End	;	");
	__ASM("		inc		IX				;	");
	__ASM("		inc		IY				;	");
	__ASM("		j		__ByteCpy		;	");
	__ASM("		;						;	");
	__ASM("__End:");
	__ASM("		ld		IY,		(SP+0x4);	");
	__ASM("		;						;ret");
	return( (char *)__IY );
}
#elif defined(__870X__)
char * __CDECL strcpy(char *s1,const char *s2) {
	__ASM("		;;	@(#)strcpy.s 1.1 95/12/19");
	__ASM("		;;	(C)COPYRIGHT TOSHIBA CORP. 1995-");
	__ASM("		;;		By M.Satoh@TSE");
	__ASM("		;;	");
	__ASM("		;;	char * __CDECL strcpy(char *s1,const char *s2)");
	__ASM("		;;	RET		:	s1");
	__ASM("		;;	s1		:	SP+0x6");
	__ASM("		;;	s2		;	SP+0x8");
	__ASM("		;;	");
	__ASM("		push	HL				;	");
	__ASM("		ld		HL,		(SP+0x6);	");
	__ASM("		ld		DE,		(SP+0x8);	");
	__ASM("__ByteCpy:");
	__ASM("		ld		(HL),	(DE)	;	");
	__ASM("		j		z,		__End	;	");
	__ASM("		inc		HL				;	");
	__ASM("		inc		DE				;	");
	__ASM("		j		__ByteCpy		;	");
	__ASM("__End:");
	__ASM("		ld		BC,		(SP+0x6);	");
	__ASM("		pop		HL				;	");
	return( (char *)__BC );
}
#endif
