/**
 * @file    stdlib.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __STDLIB_H
#define __STDLIB_H

#ifndef __SIZE_T
#define __SIZE_T
typedef unsigned long size_t;
#endif

#define EXIT_FAILURE  1
#define EXIT_SUCCESS  0

void * malloc(size_t);
void * calloc(size_t, size_t);
void * realloc(void *, size_t);
void   free(void *);

#define MB_CUR_MAX    4

int    atoi(const char *);
long   atol(const char *);
double atof(const char *);
double strtod(const char *, char **);
long   strtol(const char *, char **, int);
unsigned long strtoul(const char *, char **, int);

void   qsort(void *, size_t, size_t, int (*)(const void *, const void *));
void * bsearch(const void *, const void *, size_t, size_t, 
               int (*)(const void *, const void *));

#define RAND_MAX    0x7fffU

#ifndef __DIV_T
#define __DIV_T
typedef struct div_t {
    int quot;
    int rem;
} div_t;

typedef struct ldiv_t {
    long quot;
    long rem;
} ldiv_t;
#endif

int abs(int);
long int labs(long int);

div_t  div(int, int);
ldiv_t ldiv(long int, long int);

void srand(unsigned int);
int  rand(void);

void abort();
void exit(int);
int  atexit(void (*)());

#ifdef __900__
#define __DI()      __ASM("DI")
#define __EI()      __ASM("EI")
#define __EI900(x)  __ASM("EI "#x)
#endif

char * itoa(int, char *, int);
char * ltoa(long, char *, int);
char * ultoa(unsigned long, char *, int);
void * lfind(const void *, const void *, size_t *, size_t,
             int (*)(const void *, const void *));
void * lsearch(const void *, void *, size_t *, size_t,
               int (*)(const void *, const void *));

#define max(a,b)   (((a) > (b)) ? (a) : (b))
#define __max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b)   (((a) < (b)) ? (a) : (b))
#define __min(a,b) (((a) < (b)) ? (a) : (b))

#endif
