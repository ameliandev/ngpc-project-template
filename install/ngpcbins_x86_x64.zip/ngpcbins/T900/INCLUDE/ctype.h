/**
 * @file    ctype.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __CTYPE_H
#define __CTYPE_H

extern const char __ctype[];

#define	__UC    0x01      /* upper case        */
#define	__LC    0x02      /* lower case        */
#define	__DIG   0x04      /* digit number      */
#define	__SPC   0x08      /* spacing character */
#define	__PNC   0x10      /* punctuation       */
#define	__CTL   0x20      /* control character */
#define	__BLK   0x40      /* blank             */
#define	__HEX   0x80      /* hexadecimal digit */


#ifndef __CTYPE_FNC
#define isalnum(c)  (__ctype[(unsigned char)(c)] & (__UC|__LC|__DIG))
#define isalpha(c)  (__ctype[(unsigned char)(c)] & (__UC|__LC))
#define iscntrl(c)  (__ctype[(unsigned char)(c)] & __CTL)
#define isdigit(c)  (__ctype[(unsigned char)(c)] & __DIG)
#define isgraph(c)  (__ctype[(unsigned char)(c)] & (__PNC|__UC|__LC|__DIG))
#define islower(c)  (__ctype[(unsigned char)(c)] & __LC)
#define isprint(c)  (__ctype[(unsigned char)(c)] & (__PNC|__UC|__LC|__DIG|__BLK))
#define ispunct(c)  (__ctype[(unsigned char)(c)] & __PNC)
#define isspace(c)  (__ctype[(unsigned char)(c)] & __SPC)
#define isupper(c)  (__ctype[(unsigned char)(c)] & __UC)
#define isxdigit(c) (__ctype[(unsigned char)(c)] & __HEX)
#define tolower(c)  (isupper(c) ? (c)+('a'-'A') : (c))
#define toupper(c)  (islower(c) ? (c)+('A'-'a') : (c))

#define isascii(c)  (!((c) & ~0x7f))
#define toascii(c)  ((c) & 0x7f)
#define _tolower(c) ((c) + ('a'-'A'))
#define _toupper(c) ((c) + ('A'-'a'))
#else
int isalnum(int c);
int isalpha(int c);
int iscntrl(int c);
int isdigit(int c);
int isgraph(int c);
int islower(int c);
int isprint(int c);
int ispunct(int c);
int isspace(int c);
int isupper(int c);
int isxdigit(int c);
int tolower(int c);
int toupper(int c);

int isascii(int c);
int toascii(int c);
int _tolower(int c);
int _toupper(int c);
#endif  /* __CTYPE_FNC */

#endif
