/**
 * @file    math.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __MATH_H
#define __MATH_H

#define	HUGE_VAL	1.79769313486231500e+308

double acos(double);
double asin(double);
double atan(double);
double atan2(double, double);
double ceil(double);
double cos(double);
double cosh(double);
double exp(double);
double fabs(double);
double floor(double);
double fmod(double, double);
double frexp(double, int *);
double ldexp(double, int);
double log(double);
double log10(double);
double modf(double, double *);
double pow(double, double);
double sin(double);
double sinh(double);
double sqrt(double);
double tan(double);
double tanh(double);

#endif
