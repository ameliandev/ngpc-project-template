/**
 * @file    errno.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __ERRNO_H
#define __ERRNO_H

#define errno (errno)
extern int volatile errno;

#define EDOM    33
#define ERANGE  34

#endif
