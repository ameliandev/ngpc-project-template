/**
 * @file    setjmp.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __SETJMP_H
#define __SETJMP_H

typedef struct __jmp_buf {
    unsigned long   xsp;
    unsigned long   xiz;
#ifndef __MIN__
    unsigned long   xhl;
    unsigned long   xwa;
    unsigned long   xbc;
    unsigned long   xde;
    unsigned long   pc;
#else
    unsigned short  hl;
    unsigned short  wa;
    unsigned short  bc;
    unsigned short  de;
    unsigned short  pc;
#endif
    unsigned long   xix;
    unsigned long   xiy;
    unsigned short  sr;
} jmp_buf[1];

int  setjmp(jmp_buf);
void longjmp(jmp_buf, int);

#endif
