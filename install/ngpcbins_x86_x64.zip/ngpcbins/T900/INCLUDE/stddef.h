/**
 * @file    stddef.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __STDDEF_H
#define __STDDEF_H

#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef __PTRDIFF_T
#define __PTRDIFF_T
typedef signed long  ptrdiff_t;
#endif

#ifndef __SIZE_T
#define __SIZE_T
typedef unsigned long  size_t;
#endif

#ifndef offsetof
#define offsetof(s, m)  (size_t)(&((s *)0)->m)
#endif

#endif 
