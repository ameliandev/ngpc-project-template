/**
 * @file    stdio.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __STDIO_H
#define __STDIO_H

#ifndef EOF
#define EOF    (-1)
#endif

#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef __SIZE_T
#define __SIZE_T
typedef unsigned long size_t;
#endif

#ifndef __VA_LIST
#define __VA_LIST
typedef char * va_list;
#endif

typedef struct {
    void          (*out)(unsigned char); /* output routine */
    unsigned char (*in)(void);           /* input routine for device */
    int           unget;
    int           flag;
} FILE;

int    getchar(void);                  /* Reserve */
char * gets(char *);                   /* Reserve */
int    putchar(int);                   /* Reserve */
int    puts(char *);                   /* Reserve */
int    scanf(const char *, ...);       /* Reserve */
int    printf(const char *, ...);      /* Reserve */
int    vprintf(const char *, va_list); /* Reserve */

int    sprintf(char *, const char *, ...);
int    sscanf(const char *, const char *, ...);
int    vsprintf(char *, const char *, va_list);

#endif
