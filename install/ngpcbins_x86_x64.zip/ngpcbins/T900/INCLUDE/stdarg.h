/**
 * @file    stdarg.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __STDARG_H
#define __STDARG_H

#ifndef __VA_LIST
#define __VA_LIST
typedef char * va_list;
#endif

#define va_start(ap,parmN) \
    ((void)((ap) = (va_list)&parmN + sizeof(parmN)))

#define va_arg(ap,type) \
    ((sizeof(type) < sizeof(int)) \
      ? (((type *)((ap) += ((sizeof(type) +1) & ~1)))[-sizeof(int)]) \
      : (((type *)((ap) += ((sizeof(type) +1) & ~1)))[-1]))

#define va_end(ap)  (ap) = (va_list)0

#endif
