/**
 * @file    assert.h
 *
 * @date    $Date: 2008/06/17 07:50:48 $
 * @version $Revision: 1.1 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __ASSERT_H
#define __ASSERT_H

#undef  assert

#ifdef  NDEBUG
#define assert(ignore)  ((void)0)
#else
void _assert(const char *expression, const char *filename, unsigned int line);
#define assert(expression) \
    ((expression) \
      ? (void)0 \
      : _assert(#expression, __FILE__, __LINE__))
#endif  /* NDEBUG */

#endif
