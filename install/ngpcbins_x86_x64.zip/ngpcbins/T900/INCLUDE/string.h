/**
 * @file    string.h
 *
 * @date    $Date: 2008/11/07 05:57:55 $
 * @version $Revision: 1.2 $
 */
/* (C)Copyright TOSHIBA CORPORATION 2008 All rights reserved */

#ifndef __STRING_H
#define __STRING_H


#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef __SIZE_T
#define __SIZE_T
typedef unsigned long size_t;
#endif

void * memchr(const void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void * memcpy(void *, const void *, size_t);
void * memmove(void *, const void *, size_t);
void * memset(void *, int, size_t);

char * strcat(char *, const char *);
char * strchr(const char *, int);
int strcmp(const char *, const char *);
char * strcpy(char *, const char *);
size_t strcspn(const char *, const char *);
size_t strlen(const char *);
char * strncat(char *, const char *, size_t);
int strncmp(const char *, const char *, size_t);
char * strncpy(char *, const char *, size_t);
char * strpbrk(const char *, const char *);
char * strrchr(const char *, int);
size_t strspn(const char *, const char *);
char * strstr(const char *, const char *);
char * strtok(char *, const char *);


void * memccpy(void *, const void *, int, size_t);
int memicmp(void *, void *, size_t);
void * memswap(void *, void *, size_t);

int stricmp(const char *, const char *);
char * strlwr(char *);
int strnicmp(const char *, const char *, size_t);
char * strnset(char *, int, size_t);
char * strrev(char *);
char * strset(char *, int);
char * strupr(char *);

void * __fmemccpy(void *, const void *, int, unsigned long);
void * __fmemchr(const void *, int, unsigned long);
int __fmemcmp(const void *, const void *, unsigned long);
void * __fmemcpy(void *, const void *, unsigned long);
void * __fmemset(void *, int, unsigned long);
void * __fmemmove(void *, const void *, unsigned long);
void * __fmemswap(void *, void *, unsigned long);
#endif
