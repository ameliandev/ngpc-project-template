(C)Copyright TOSHIBA CORPORATION 2009  All rights reserved
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^
=====================
Technical information
---------------------

o Operating environment
  (1) Hos OS (OS)
      Windows(R) 2000, Windows(R) XP, Windows Vista(R)
  (2) Host Machine (PC)
      IBM PC/AT compatible
  (3) CPU
      Pentium4 1GHz class or faster (recommended)
  (4) Main Memory
      1GB or more (recommended) (*1)
  (5) Display
      1024 x 768 or more, 256 colors or more
  (6) Hard Disk Space for Instllation
      50 MB (*2)

(*1): If requested specification of OS is higher than that described  system
      specification, that system environment complies its specification.
(*2): Not including working area.

o Useable file name and path name
  (1)Usable characters
     - The alphabet and number
     - Space
     - ! # $ % & ' ( ) - @ _ { }  ~
  (2)Un-usable characters
     - except for ASCII code 0x20 - 0x7E
     - + , ; = [ ]

o PDF files
  To open PDF files provided with the product, you must use the
  following tool:

    Adobe Reader 
    (Copyright 2009 Adobe Systems Incorporated. All rights reserved.)

  You can download it from the following Web page:

    http://www.adobe.com/

=====================
Program version
---------------------
TLCS-900 Family C Compiler Ver1.10
    cc900     V1.89    C Compiler Driver
    thc1      V1.8r.21 C Compiler (Parser)
    thc2      V1.8s.06 C Compiler (Code Generater)
    tumpp     V2.02    Macro Preprocessor
    asm900    V2.2k    Assembler
    tulink    V2.0p    Linker
    tuconv    V1.2n    Object Converter
    tulib     V1.2o    Librarian

=====================
Manuals
---------------------
The manuals of this product are follows:
 o TLCS-900 Compiler System User's Guide   : 1st Edition
 o TLCS-900 C Compiler Reference           : 1st Edition
 o TLCS-900 Assembler Reference            : 1st Edition

=== END ===
