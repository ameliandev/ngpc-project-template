void SL_SoundInit();
void SL_LoadGroup(const u8*,u16);
void SL_PlayTune(u8);
void SL_PlaySFX(u8);
