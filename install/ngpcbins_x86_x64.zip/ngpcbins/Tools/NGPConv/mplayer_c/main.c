#include "ngpc.h"
#include "carthdr.h"
#include "library.h"
#include "mplayer.h"
#include "hicolor.h"

//#define BLANK // to generate emty rom for movie converter template

#ifdef BLANK
#include "music.h"
const u16 blank_movie[1000002] = {0x2211,0x4433,0x6655,0x8877};
const u8 blank_music[1355] = {0xaa,0xbb,0xcc,0xdd,0xee,0xff};
#else
#include "dream.h"
#endif

extern volatile u8 VBCounter;
volatile u32 moviecnt = 0;
MOVIE curmovie;

void clearPals()
{
	u16 *p1 = SCROLL_1_PALETTE;
	u16 *p2 = SCROLL_2_PALETTE;
	u16 *p3 = SPRITE_PALETTE;
	u16 i;
	for (i=0;i<64;i++)
		p1[i] = p2[i] = p3[i] = 0;
}

void __interrupt myVBL()
{
	WATCHDOG = WATCHDOG_CLEAR;
	if (USR_SHUTDOWN) { SysShutdown(); while (1); }
	VBCounter++;
	moviecnt++;

	if (hc_emu())
		mp_play_emu(&curmovie);
	else
		mp_play_hw(&curmovie);
}

void showMovie()
{
	u8 j;

	clearPals();

	moviecnt = 0;
#ifdef BLANK
	SL_SoundInit();
	SL_LoadGroup(blank_music,sizeof(blank_music));
	SL_PlayTune(0);
	curmovie.data  = ((u16*)blank_movie)+2;
	curmovie.count = blank_movie[0];
	curmovie.delay = blank_movie[1];
#else
	curmovie.data  = (u16*)DREAM_DATA;
	curmovie.count = DREAM_COUNT;
	curmovie.delay = DREAM_DELAY;
#endif

	mp_load(&curmovie);

//	while((moviecnt<DREAM_COUNT*DREAM_DELAY) && (!((j=JOYPAD)&J_A))); // to stop at the end of the movie
	while((j=JOYPAD)&J_A);
	while(!((j=JOYPAD)&J_A));
	while((j=JOYPAD)&J_A);

	mp_stop(&curmovie);
}

void main()
{
	InitNGPC();

	ClearScreen(SCR_1_PLANE);
	ClearScreen(SCR_2_PLANE);
	SetBackgroundColour(RGB(0, 0, 0));
	SCR1_X = SCR1_Y = SCR2_X = SCR2_Y = 0;

	hc_detect();

	__asm(" di");
	VBL_INT = myVBL;
	__asm(" ei");

	showMovie();

	while(1);
}
